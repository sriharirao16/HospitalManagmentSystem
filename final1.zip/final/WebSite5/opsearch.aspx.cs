using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class opsearch : System.Web.UI.Page
{

    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
       

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtopid.Text == "")
        {
            //MessageBox.Show("enter  emp id first");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Employee Id First!!!')</script>");
        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from opreg where opno='" + txtopid.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "op");
                if (ds.Tables["op"].Rows.Count > 0)
                {
                    txtopid.Enabled = false;
                    LinkButton1.Visible = false;
                    Label1.Visible = true;
                    LinkButton2.Visible = true;
                    lbllab.Visible = true;
                    LinkButton3.Visible = true;
                    for (int i = 0; i <= ds.Tables["op"].Rows.Count - 1; i++)
                    {
                        txtname.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[4]);
                        txtdate.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[1]);
                        txtadd.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[7]);
                        txtadhar.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[16]);
                        txtage.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[9]);
                        txtmbl.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[15]);
                        txtdept.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[17]);
                        txtsex.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[10]);
                        txtdoc.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[18]);
                        txtpin.Text = Convert.ToString(ds.Tables["op"].Rows[i].ItemArray[14]);

                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtopid.Text = "";
                    txtopid.Enabled = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }
 
    protected void LinkButton2_Click1(object sender, EventArgs e)
    {
        if (txtopid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Employee Id first!!!')</script>");
            //MessageBox.Show("enter  emp id first");
        }
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select opcare,dob,city,bloodgrp,referal,remark  from opreg where opno='" + txtopid.Text + "'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "emp");

                if (ds.Tables["emp"].Rows.Count >= 0)
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = ds.Tables["emp"];
                    GridView1.DataBind();

                }
                else
                {
                    GridView1.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check Employee Id!!!')</script>");
                    //MessageBox.Show("check emp id");
                    txtopid.Text = "";


                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

        }

    }
    protected void LinkButton3_Click1(object sender, EventArgs e)
    {
        if (txtopid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter employee Id First!!!')</script>");
            //MessageBox.Show("enter  emp id first");
        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from labdetails where pid='" + txtopid.Text + "'and ptype='OP'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    GridView2.Visible = true;
                    GridView2.DataSource = ds.Tables["edit"];
                    GridView2.DataBind();


                }
                else
                {
                    GridView2.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtopid.Text = "";

                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        txtadd.Text = "";
        txtadhar.Text = "";
        txtage.Text = "";
        txtdate.Text = "";
        txtdept.Text = "";
        txtdoc.Text = "";
        txtmbl.Text = "";
        txtname.Text = "";
        txtopid.Text = "";
        txtpin.Text = "";
        txtsex.Text = "";

        Label1.Visible = false;
        LinkButton3.Visible = false;
        lbllab.Visible = false;
        LinkButton2.Visible = false;
        LinkButton1.Visible = true;
        txtopid.Enabled = true;
        GridView1.Visible = false;
        GridView2.Visible = false;

    }
}
