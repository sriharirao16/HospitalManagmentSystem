using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class admltt : System.Web.UI.Page
{

 



    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        DateTime tday = DateTime.Now;
        String td = tday.ToString("d");
        Label1.Text = td.ToString();

        try
        {

            c = new connect();
            c.cmd.CommandText = "select ptype,pid,name,age,sex,mbl,test from labdetails where date='" + td + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lab");
            if (ds.Tables["lab"].Rows.Count > 0)
            {
                c.cmd.CommandText = "select count(date)from labdetails  where date='" + td + "'";
                int d = Convert.ToInt16(c.cmd.ExecuteScalar());
                Label2.Text = d.ToString();
                GridView1.DataSource = ds.Tables["lab"];
                GridView1.DataBind();

            }
            else
            {
                //Label2.Text = "todays No Record Found";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Todays Record Does Not Exist!!!')</script>");
            }

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
       


    }

}
