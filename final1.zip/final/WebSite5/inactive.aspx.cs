using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class inactive : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    string st;
    protected void Page_Load(object sender, EventArgs e)
    {
        MaintainScrollPositionOnPostBack = true;
        txtid.Focus();

    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        c = new connect();

        try
        {
            c = new connect();
            if (txtid.Text == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter emp-Id to Inactive!!!')</script>");
                //MessageBox.Show("Enter Emp-Id to Inactivate!!!");
            }
            else
            {


                c.cmd.CommandText = "select * from empreg where empid='" + txtid.Text + "'and status='active'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "u");
                if (ds.Tables["u"].Rows.Count > 0)
                {
                    c.cmd.CommandText = "update empreg set status=@status where empid='" + txtid.Text + "'";
                    c.cmd.Parameters.Add("@status", SqlDbType.VarChar).Value = "Inactive";
                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Employee Id Inactived!!!')</script>");
                    //MessageBox.Show("Employee-Id is Inactivated");

                    for (int i = 0; i <= ds.Tables["u"].Rows.Count - 1; i++)
                    {
                        st = Convert.ToString(ds.Tables["u"].Rows[i].ItemArray[0]);
                    }
                    if (st.ToString() == "lab")
                    {
                        c.cmd.CommandText = "update lablogin set status1=@status1 where empid='" + txtid.Text + "'";
                        c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Inactive";
                        c.cmd.ExecuteNonQuery();
                    }
                    else if (st.ToString() == "reception")
                    {
                        c.cmd.CommandText = "update userlog set status1=@status1 where empid='" + txtid.Text + "'";
                        c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Inactive";
                        c.cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        txtid.Text = "";
                    }
                    txtid.Text = "";

                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Employee Id Does Not exist!!!')</script>");
                    //MessageBox.Show("Employee-Id doesnot exist");
                    txtid.Text = "";
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }


    }
    protected void btnback_Click(object sender, EventArgs e)
    {

    }
}
