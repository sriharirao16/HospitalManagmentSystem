using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class hrattends : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        MaintainScrollPositionOnPostBack = true;
        txthrid.Focus();
        txtdesig.Enabled = false;
        txtdate.Enabled = false;
        txtmonth.Enabled = false;
        txtyear.Enabled = false;
        txttotdays.Enabled = false;
        txtleavegiven.Enabled = false;
        txtdayswork.Enabled = false;
        txtextraleave.Enabled = false;
        
    }
    protected void btnok_Click(object sender, EventArgs e)
    {
        
        if (txthrid.Text == "")
        {
            //MessageBox.Show("Enter Employee-Id first!!");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Employee-Id First!!!')</script>");
            txthrid.Text = "";
        }
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select * from hrreg where hrid='" + txthrid.Text + "'and status='active'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "emp");
                if (ds.Tables["emp"].Rows.Count > 0)
                {
                    txthrid.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[0]);
                    txtdesig.Text = "hr";


                    txtleavegiven.Text = "4";
                    txtdate.Text = Convert.ToString(DateTime.Today.ToShortDateString());
                    txtyear.Text = Convert.ToString(DateTime.Now.Year);
                    long m;

                    DateTime today = DateTime.Now.Date;
                    decimal d = today.Day;
                    
                    // MessageBox.Show(d.ToString());
                    if (d < 6)
                    {


                        m = Convert.ToInt32(DateTime.Now.Month);
                        switch (m)
                        {
                            case 1:
                                txtmonth.Text = "December";
                                txttotdays.Text = "31";
                                break;
                            case 2:
                                txtmonth.Text = "January";
                                txttotdays.Text = "31";
                                break;
                            case 3:
                                txtmonth.Text = "February";
                                txttotdays.Text = "28";
                                break;
                            case 4:
                                txtmonth.Text = "March";
                                txttotdays.Text = "31";
                                break;
                            case 5:
                                txtmonth.Text = "April";
                                txttotdays.Text = "30";
                                break;
                            case 6:
                                txtmonth.Text = "May";
                                txttotdays.Text = "31";
                                break;
                            case 7:
                                txtmonth.Text = "June";
                                txttotdays.Text = "30";
                                break;
                            case 8:
                                txtmonth.Text = "July";
                                txttotdays.Text = "31";
                                break;
                            case 9:
                                txtmonth.Text = "August";
                                txttotdays.Text = "31";
                                break;
                            case 10:
                                txtmonth.Text = "September";
                                txttotdays.Text = "30";
                                break;
                            case 11:
                                txtmonth.Text = "October";
                                txttotdays.Text = "31";
                                break;
                            case 12:
                                txtmonth.Text = "November";
                                txttotdays.Text = "30";
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Attendence due date is expired");
                        txthrid.Text = "";
                        txthrid.Text = "";
                        txtdate.Text = "";
                        txtdesig.Text = "";
                        txtleavegiven.Text = "";
                        txtleavtaken.Text = "";
                        txtmonth.Text = "";
                        txttotdays.Text = "";
                        txtdayswork.Text = "";
                        txtyear.Text = "";
                        txtextraleave.Text = "";
                        txtleavtaken.Text = "";
                    }





                }
                else
                {
                    //MessageBox.Show("HR-Id Doesnot Exists!!!");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Hr-Id doesnot Exists!!!')</script>");
                    txthrid.Text = "";
                    txthrid.Text = "";
                    txtdate.Text = "";
                    txtdesig.Text = "";
                    txtleavegiven.Text = "";
                    txtleavtaken.Text = "";
                    txtmonth.Text = "";
                    txttotdays.Text = "";
                    txtdayswork.Text = "";
                    txtyear.Text = "";
                    txtextraleave.Text = "";
                    txtleavtaken.Text = "";
                }

            }
            catch
                (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    
    }
    protected void btncal_Click(object sender, EventArgs e)
    {
       
        if (txtleavtaken.Text == "")
        {
            MessageBox.Show("enter leave taken");
        }
        else
        {

            decimal ltt =Convert .ToDecimal(txtleavtaken.Text);
            decimal mn = Convert.ToDecimal(txttotdays.Text);
            if (ltt < mn  )
            {
                //MessageBox.Show(ltt.ToString());
                double lg, lt, exleave;
                lg = Convert.ToDouble(txtleavegiven.Text);
                lt = Convert.ToDouble(txtleavtaken.Text);
                if (lt > 4)
                {
                    exleave = lt - lg;
                    txtextraleave.Text = Convert.ToString(exleave);
                }
                else
                {
                    txtextraleave.Text = "0";
                }
                if (txtleavtaken.Text == "")
                {
                    MessageBox.Show("Please..Enter the leave Taken Field");
                    txtleavtaken.Focus();
                }
                else
                {
                    long d;
                    d = Convert.ToInt32(txttotdays.Text) - Convert.ToInt32(txtleavtaken.Text);
                    txtdayswork.Text = d.ToString();
                }
            }
            else
            {
                MessageBox.Show("check leave Taken");
                txtleavtaken.Text = "";
                txtleavtaken.Focus();

            }
        }
    }
    protected void btnreg_Click(object sender, EventArgs e)
    {
        try
        {
            c = new connect();
            c.cmd.CommandText = "select count(*) from hrattendence where hrid='" + txthrid.Text + "'and year='" + txtyear.Text + "'and month='" + txtmonth.Text + "'";
            int v = Convert.ToInt16(c.cmd.ExecuteScalar());
            if (v > 0)
            {
                //MessageBox.Show("Attendance Already Registered!!");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Attendance Already Registerd!!!')</script>");
                txthrid.Text = "";
                txtdate.Text = "";
                txtdesig.Text = "";
                txtleavegiven.Text = "";
                txtleavtaken.Text = "";
                txtmonth.Text = "";
                txttotdays.Text = "";
                txtdayswork.Text = "";
                txtyear.Text = "";
                txtextraleave.Text = "";
                txtleavtaken.Text = "";
            }
            else
            {
                c.cmd.CommandText = "insert into hrattendence values(@hrid,@desig,@date,@month,@year,@totaldays,@leavegiven,@leavetaken,@extraleave,@nodays)";
                c.cmd.Parameters.Add("@hrid", SqlDbType.NVarChar).Value = txthrid.Text;
                c.cmd.Parameters.Add("@desig", SqlDbType.NVarChar).Value = txtdesig.Text;
                c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = txtdate.Text;
                c.cmd.Parameters.Add("@month", SqlDbType.NVarChar).Value = txtmonth.Text;
                c.cmd.Parameters.Add("@year", SqlDbType.NVarChar).Value = txtyear.Text;
                c.cmd.Parameters.Add("@totaldays", SqlDbType.NVarChar).Value = txttotdays.Text;
                c.cmd.Parameters.Add("@leavegiven", SqlDbType.NVarChar).Value = txtleavegiven.Text;
                c.cmd.Parameters.Add("@leavetaken", SqlDbType.NVarChar).Value = txtleavtaken.Text;
                c.cmd.Parameters.Add("@extraleave", SqlDbType.NVarChar).Value = txtextraleave.Text;
                c.cmd.Parameters.Add("@nodays", SqlDbType.NVarChar).Value = txtdayswork.Text;
                c.cmd.ExecuteNonQuery();
                //MessageBox.Show("Attendance Updated");

                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Attedance Updated!!!')</script>");
                txthrid .Text= "";
                txtdate.Text = "";
                txtdesig.Text = "";
                txtleavtaken.Text = "";
                txtleavtaken.Text = "";
                txtmonth.Text = "";
                txttotdays.Text = "";
                txtdayswork.Text = "";
                txtyear.Text = "";
                txtextraleave.Text = "";
                txtleavtaken.Text = "";
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
    protected void txtreset_Click(object sender, EventArgs e)
    {
        txthrid.Text = "";
        txtdate.Text = "";
        txtdesig.Text = "";
        txtleavegiven.Text = "";
        txtleavtaken.Text = "";
        txtmonth.Text = "";
        txttotdays.Text = "";
        txtdayswork.Text = "";
        txtyear.Text = "";
    }
    protected void txtback_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/hrreg.aspx");
    }
    protected void btncal_Click1(object sender, EventArgs e)
    {

        if (txtleavtaken.Text == "")
        {
            //MessageBox.Show("enter leave taken");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Leave Taken!!!')</script>");
        }
        else
        {

            decimal ltt = Convert.ToDecimal(txtleavtaken.Text);
            decimal mn = Convert.ToDecimal(txttotdays.Text);
            if (ltt < mn)
            {
                //MessageBox.Show(ltt.ToString());
                double lg, lt, exleave;
                lg = Convert.ToDouble(txtleavegiven.Text);
                lt = Convert.ToDouble(txtleavtaken.Text);
                if (lt > 4)
                {
                    exleave = lt - lg;
                    txtextraleave.Text = Convert.ToString(exleave);
                }
                else
                {
                    txtextraleave.Text = "0";
                }
                if (txtleavtaken.Text == "")
                {
                    //MessageBox.Show("Please..Enter the leave Taken Field");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Plz...Enter The Leave Taken Fields!!!')</script>");
                    txtleavtaken.Focus();
                }
                else
                {
                    long d;
                    d = Convert.ToInt32(txttotdays.Text) - Convert.ToInt32(txtleavtaken.Text);
                    txtdayswork.Text = d.ToString();
                }
            }
            else
            {
                //MessageBox.Show("check leave Taken");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check Leave Taken!!!')</script>");
                txtleavtaken.Text = "";
                txtleavtaken.Focus();

            }
        }


    }
}

