using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class repcon : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        txtadd.Text = "";
        txtdoctor.Text = "";
        txtafees.Text = "";
        txtdate.Text = "";
        txtname.Text = "";
        txtopno.Text = "";
        txtdfees.Text = "";
        txtopno.Focus();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
         c = new connect();
            c.cmd.CommandText = "select pid,name,address,doctor,date,charge,admfees from concharges where pid='" + txtopno .Text  + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "print");
            if (ds.Tables["print"].Rows.Count > 0)
            {
                for (int i = 0; i <= ds.Tables["print"].Rows.Count - 1; i++)
                {
                    txtname.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[1]);
                    txtadd.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[2]);
                    txtdoctor.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[3]);
                    DateTime dt = Convert.ToDateTime(ds.Tables["print"].Rows[i].ItemArray[4]);
                    txtdate.Text = dt.ToShortDateString();
                    txtdfees.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[5]);
                    txtafees.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[6]);
                }
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Id Does Not Exist!!!')</script>");
                txtopno.Text = "";
                txtopno.Focus();
            }

                    
    }
}
