using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class opreg : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();


    String empid = "Op";
    string gen;
    protected void Page_Load(object sender, EventArgs e)
    {
        DateTime today = DateTime.Now;

        lbldate.Text = today.ToString("d");
        lbltime.Text = today.ToString("t");

        btnrefresh.Enabled = true;
        MaintainScrollPositionOnPostBack = true;

        if (!IsPostBack)
        {
            GenerateAutoID();
        }
        if (!IsPostBack)
        {
            Calendar1.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;


           
 

            LoadYears();
            LoadMonths();
        }


    }
    private void LoadMonths()
    {

        DataSet dsMonths = new DataSet();
        dsMonths.ReadXml(Server.MapPath("~/Month.xml"));

        DropDownList2.DataTextField = "Name";
        DropDownList2.DataValueField = "Number";


        DropDownList2.DataSource = dsMonths;
        DropDownList2.DataBind();

    }


    private void LoadYears()
    {

        DataSet dsYears = new DataSet();
        dsYears.ReadXml(Server.MapPath("~/Years.xml"));

        DropDownList1.DataTextField = "Number";
        DropDownList1.DataValueField = "Number";


        DropDownList1.DataSource = dsYears;
        DropDownList1.DataBind();
    }

    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(opno)from opreg ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        lblopno .Text  = empid + i.ToString();


    }



    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtdob.Text = Calendar1.SelectedDate.ToString("d");

        DateTime dob = new DateTime();
        dob = Convert.ToDateTime(txtdob.Text);
        DateTime age = DateTime.Now;
        TimeSpan tspan = age - dob;
        double dayss = tspan.TotalDays;

        double ag = dayss / 365;
        if (ag < 0)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check Your Age!!!')</script>");
            //MessageBox.Show("check your age");
            txtdob.Text = "";


        }

        TimeSpan tspan1 = age - dob;
        double days = tspan.TotalDays;
        double age1 = days / 365;

        txtage.Text = age1.ToString("0");



        Calendar1.Visible = false;
        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        Label2.Visible = false;
        Label3.Visible = false;

        
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ddlname.SelectedItem.Text == "select" || txtname.Text == "" || ddlcareof.SelectedItem.Text == "select" || txtcare.Text == "" || txtaddress.Text == "" || txtdob.Text == "" || txtcity.Text == "" || txtpin.Text == "" || txtdist.Text == "" || txtmobile.Text == "" || ddlstate.SelectedItem.Text == "select" || ddldoctor.SelectedItem.Text == "select" || ddldept.SelectedItem.Text == "select" || Radiomale.Checked == false && Radiofemale.Checked == false && Radioother.Checked == false || txtadhar.Text == ""||txtremark .Text =="" )
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All The Fields!!!')</script>");
            //MessageBox.Show("enter all fields");
        }
        else
        {



            c = new connect();
            c.cmd.CommandText = "select * from opreg where opno='" + lblopno .Text  +"'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "del");
            if (ds.Tables["del"].Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already Done!!!')</script>");
                //MessageBox.Show("record already done");
            }
            else
            {

                try
                {
                    c = new connect();
                    c.cmd.CommandText = "insert into opreg values(@opno,@opdate,@optime,@opndrp,@opname,@opcdrp,@opcare,@address,@bloodgrp,@age,@sex,@dob,@city,@dist,@pin,@mob,@adhar,@doctor,@dept,@referal,@remark,@state)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@opno", SqlDbType.NVarChar).Value = lblopno .Text ;
                    c.cmd.Parameters.Add("@opdate", SqlDbType.DateTime).Value = lbldate.Text;
                    c.cmd.Parameters.Add("@optime", SqlDbType.DateTime).Value = lbltime.Text;
                    c.cmd.Parameters.Add("@opndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                    c.cmd.Parameters.Add("@opname", SqlDbType.NVarChar).Value = txtname.Text;
                    c.cmd.Parameters.Add("@opcdrp", SqlDbType.NVarChar).Value = ddlcareof.SelectedItem.Text;
                    c.cmd.Parameters.Add("@opcare", SqlDbType.NVarChar).Value = txtcare.Text;
                    c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                    c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                    c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                    if (Radiomale.Checked == true)
                        gen = Radiomale.Text;
                    else if (Radiofemale.Checked == true)
                        gen = Radiofemale.Text;
                    else
                        gen = Radioother.Text;
                    c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                    c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = txtdob.Text;
                    c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                    c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                    c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                    c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmobile.Text);
                    c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                    c.cmd.Parameters.Add("@doctor", SqlDbType.NVarChar).Value = ddldoctor.SelectedItem.Text;
                    c.cmd.Parameters.Add("@dept", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                    c.cmd.Parameters.Add("@referal", SqlDbType.NVarChar).Value = txtreferal.Text;
                    c.cmd.Parameters.Add("@remark", SqlDbType.NVarChar).Value = txtremark.Text;
                    c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = ddlstate.SelectedItem.Text;
                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Saved!!!')</script>");
                    //MessageBox.Show("Saved");
                    GenerateAutoID();
                    lbldate.Text = DateTime.Now.ToShortDateString();
                    lbltime.Text = DateTime.Now.ToShortTimeString();

        

                    ddlname.ClearSelection();
                    ddlname.SelectedItem.Text = "select";
                    txtname.Text = "";
                    ddlcareof.ClearSelection();
                    ddlcareof.SelectedItem.Text = "select";
                    txtcare.Text = "";
                    txtaddress.Text = "";
                    ddlbg.ClearSelection();
                    ddlbg.SelectedItem.Text = "select";
                    txtage.Text = "";
                    Radiomale.Checked = false;
                    Radiofemale.Checked = false;
                    Radioother.Checked = false;
                    txtdob.Text = "";
                    // ddldoctor.SelectedIndex = 0;
                    txtcity.Text = "";
                    txtdist.Text = "";
                    txtpin.Text = "";
                    txtmobile.Text = "";
                    txtadhar.Text = "";
                    ddldoctor.ClearSelection();
                    ddldoctor.SelectedItem.Text = "select";
                    ddldept.ClearSelection();
                    ddldept.SelectedItem.Text = "select";
                    txtreferal.Text = "";
                    txtremark.Text = "";
                    ddlstate.ClearSelection();
                    ddlstate.SelectedItem.Text = "select";


                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }
        }
    }
    protected void Btnedit_Click(object sender, EventArgs e)
    {
        if (txtopno.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Op No. First!!!')</script>");
            //MessageBox.Show("enter op no.first");
            Panel2.Enabled = true ;
            txtadhar.Enabled = true;
            ddldoctor.Enabled = true;
            ddldept.Enabled = true;
            ImageButton1.Enabled = true;
            ddlname.Enabled = true;
            txtname.Enabled = true;
            ddlbg.Enabled = true;
                       
        }
        else
        {



            try
            {
                string gen;
                DateTime da, ta, dob;
                c = new connect();
                c.cmd.CommandText = "select * from opreg where opno='" + txtopno.Text + "'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        lblopno .Text  = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                        da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[1]);
                        lbldate.Text = da.ToString("d");
                        ta = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[2]);
                        lbltime.Text = ta.ToString("t");
                        ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                        txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                        ddlcareof.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                        txtcare.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);
                        ddlcareof.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                        txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);
                        ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);

                        if (ddlbg.SelectedItem.Text == "select")
                        {
                            ddlbg.Enabled = true ;
                        }
                        else
                        {
                            ddlbg.Enabled = false ;
                        }
                        txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                        gen = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);

                        if (gen == "male")
                        {
                            Radiomale.Checked = true;
                        }
                        else if (gen == "female")
                        {
                            Radiofemale.Checked = true;
                        }
                        else
                        {
                            Radioother.Checked = true;
                        }
                        dob = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[11]);
                        txtdob.Text = dob.ToString("d");
                        txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);
                        txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[13]);
                        txtpin.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                        txtmobile.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                        txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);
                        ddldoctor.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                        ddldept.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);
                        txtreferal.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[19]);
                        txtremark.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                        ddlstate.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);

                        txtopno.Enabled = false;
                        Btnedit.Visible = false;
                        btnupdate.Visible = true;
                        txtopno1.Visible = false;
                        btnsearch.Visible = false;

                        Panel2.Enabled = false;
                        txtadhar.Enabled = false;
                        ddldoctor.Enabled = false;
                        ddldept.Enabled = false;
                        ImageButton1.Enabled = false;
                        ddlname.Enabled = false;
                        txtname.Enabled = false;





                    
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    GenerateAutoID();
                    lbldate.Text = DateTime.Now.ToShortDateString();
                    lbltime.Text = DateTime.Now.ToShortTimeString();

        
                    ddlname.ClearSelection();
                    ddlname.SelectedItem.Text = "select";
                    txtname.Text = "";
                    ddlcareof.ClearSelection();
                    ddlcareof.SelectedItem.Text = "select";
                    txtcare.Text = "";
                    txtaddress.Text = "";
                    ddlbg.ClearSelection();
                    ddlbg.SelectedItem.Text = "select";
                    txtage.Text = "";
                    Radiomale.Checked = false;
                    Radiofemale.Checked = false;
                    Radioother.Checked = false;
                    txtdob.Text = "";
                    txtcity.Text = "";
                    txtdist.Text = "";
                    txtpin.Text = "";
                    txtmobile.Text = "";
                    txtadhar.Text = "";
                    ddldoctor.ClearSelection();
                    ddldoctor.SelectedItem.Text = "select";
                    ddldept.ClearSelection();
                    ddldept.SelectedItem.Text = "select";
                    txtreferal.Text = "";
                    txtremark.Text = "";
                    ddlstate.ClearSelection();
                    ddlstate.SelectedItem.Text = "select";

                    Panel2.Enabled = true;
                    txtadhar.Enabled = true;
                    ddldoctor.Enabled = true;
                    ddldept.Enabled = true;
                    ImageButton1.Enabled = true;
                    ddlname.Enabled = true;
                    txtname.Enabled = true;
                    ddlbg.Enabled = true;
                    txtopno.Text = "";

                    txtopno1.Visible = true ;
                    btnsearch.Visible = true ;
                       
                }
            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }


        }

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        if (ddlcareof.SelectedItem.Text == "select" || txtcare.Text == "" || txtaddress.Text == "" || txtcity.Text == "" || txtdist.Text == "" || txtpin.Text == "" || txtmobile.Text == "" || ddlstate.SelectedItem.Text == "select" || ddlbg.SelectedItem.Text == "select"||txtremark .Text =="")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All The Fields!!!')</script>");
            //MessageBox.Show("enter all fields");
        }
        else
        {


            try
            {

                c = new connect();
                // c.cmd.CommandText = "update opreg set opndrp='" + ddrna.SelectedItem.Text + "'," + "opname='" + txtname.Text + "'," + "opcare='" + txtcareof.Text + "'," + "opcdrp='" + ddrca.SelectedItem.Text + "'," + "opaddress='" + txtaddress.Text + "'," + "state='" + ddlstate.SelectedItem.Text + "'," + "district='" + txtdistrict.Text + "'," + "taluk='" + txttaluk.Text + "'," + "city='" + txtcity.Text + "'," + "mobile='" + txtmoblie.Text + "'," + "phone='" + txtphone.Text + "'," + "dob='" + txtdob.Text + "'," + "age='" + txtage.Text + "'," + "sex=@sex," + "department='" + txtdepartment.Text + "'," + "adhar='" + txtadhar.Text + "'," + "email='" + txtemail.Text + "'," + "referal='" + txtreferal.Text + "'," + "remark='" + txtremark.Text + "'" + " where opno='" + txtopno.Text + "'";
                c.cmd.CommandText = "update opreg set opcdrp=@opcdrp, opcare=@opcare,address=@address,bloodgrp=@bloodgrp,city=@city,dist=@dist,pin=@pin,mob=@mob,state=@state,referal=@referal,remark=@remark where opno='" + txtopno.Text + "'";
                c.cmd.Parameters.Clear();
                
                c.cmd.Parameters.Add("@opcdrp", SqlDbType.NVarChar).Value = ddlcareof.SelectedItem.Text;
                c.cmd.Parameters.Add("@opcare", SqlDbType.NVarChar).Value = txtcare.Text;
                c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg .SelectedItem .Text ;
                c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmobile.Text);
                c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = ddlstate.SelectedItem.Text;
                c.cmd.Parameters.Add("@referal", SqlDbType.NVarChar).Value = txtreferal .Text ;
                c.cmd.Parameters.Add("@remark", SqlDbType.NVarChar).Value =txtremark .Text ;
               
                c.cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Update Sucefully Done!!!')</script>");
                //MessageBox.Show("update successfull");
                GenerateAutoID();
                lbldate.Text = DateTime.Now.ToShortDateString();
                lbltime.Text = DateTime.Now.ToShortTimeString();


                ddlname.ClearSelection();
                ddlname.SelectedItem.Text = "select";
                txtname.Text = "";
                ddlcareof.ClearSelection();
                ddlcareof.SelectedItem.Text = "select";
                txtcare.Text = "";
                txtaddress.Text = "";
                ddlbg.ClearSelection();
                ddlbg.SelectedItem.Text = "select";
                txtage.Text = "";
                Radiomale.Checked = false;
                Radiofemale.Checked = false;
                Radioother.Checked = false;
                txtdob.Text = "";
                txtcity.Text = "";
                txtdist.Text = "";
                txtpin.Text = "";
                txtmobile.Text = "";
                txtadhar.Text = "";
                ddldoctor.ClearSelection();
                ddldoctor.SelectedItem.Text = "select";
                ddldept.ClearSelection();
                ddldept.SelectedItem.Text = "select";
                txtreferal.Text = "";
                txtremark.Text = "";
                ddlstate.ClearSelection();
                ddlstate.SelectedItem.Text = "select";
                txtopno.Text = "";
                txtopno.Enabled = true;
                Btnedit.Visible  = true;
                btnupdate.Visible = false;
                Panel2.Enabled = true;
                txtadhar.Enabled = true;
                ddldoctor.Enabled = true;
                ddldept.Enabled = true;
                ImageButton1.Enabled = true;
                ddlname.Enabled = true;
                txtname.Enabled = true;
                ddlbg.Enabled = true;

                txtopno1.Visible = true;
                btnsearch.Visible = true;
             

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
    }
    }
    protected void btnsearch_Click1(object sender, EventArgs e)
    {
        if (txtopno1.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Op No Firest!!!')</script>");
           //MessageBox.Show("enter op no.first");
            Panel1.Enabled = true;
                
        }
        else
        {
            try
            {
                string gen;
                DateTime da, ta, dob;
                c = new connect();
                c.cmd.CommandText = "select * from opreg where opno='" + txtopno1.Text + "'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        lblopno.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                        da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[1]);
                        lbldate.Text = da.ToString("d");
                        ta = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[2]);
                        lbltime.Text = ta.ToString("t");
                        ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                        txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                        ddlcareof.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                        txtcare.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);
                        txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);
                        ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                        txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                        gen = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);

                        if (gen == "male")
                        {
                            Radiomale.Checked = true;
                        }
                        else if (gen == "female")
                        {
                            Radiofemale.Checked = true;
                        }
                        else
                        {
                            Radioother.Checked = true;
                        }
                        dob = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[11]);
                        txtdob.Text = dob.ToString("d");
                        txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);
                        txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[13]);
                        txtpin.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                        txtmobile.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                        txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);
                        ddldoctor.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                        ddldept.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);
                        txtreferal.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[19]);
                        txtremark.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                        ddlstate.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                        Panel1.Enabled = false;
                        txtopno.Visible = false;
                        Btnedit.Visible = false;
                        btnrefresh.Enabled = true;
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    GenerateAutoID();
                    lbldate.Text = DateTime.Now.ToShortDateString();
                    lbltime.Text = DateTime.Now.ToShortTimeString();
                    ddlname.ClearSelection();
                    ddlname.SelectedItem.Text = "select";
                    txtname.Text = "";
                    ddlcareof.ClearSelection();
                    ddlcareof.SelectedItem.Text = "select";
                    txtcare.Text = "";
                    txtaddress.Text = "";
                    ddlbg.ClearSelection();
                    ddlbg.SelectedItem.Text = "select";
                    txtage.Text = "";
                    Radiomale.Checked = false;
                    Radiofemale.Checked = false;
                    Radioother.Checked = false;
                    txtdob.Text = "";
                    txtcity.Text = "";
                    txtdist.Text = "";
                    txtpin.Text = "";
                    txtmobile.Text = "";
                    txtadhar.Text = "";
                    ddldoctor.ClearSelection();
                    ddldoctor.SelectedItem.Text = "select";
                    ddldept.ClearSelection();
                    ddldept.SelectedItem.Text = "select";
                    txtreferal.Text = "";
                    txtremark.Text = "";
                    ddlstate.ClearSelection();
                    ddlstate.SelectedItem.Text = "select";
                    Panel1.Enabled = true ;
                    txtopno1.Text = "";
                    Panel1.Enabled = true ;
                    txtopno.Visible = true ;
                    Btnedit.Visible = true ;
                    
                }
            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }


        }

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            Label2.Visible = true;
            Label3.Visible = true;

            DropDownList1.ClearSelection();
            DropDownList1.SelectedItem.Text = "1908";
            DropDownList2.ClearSelection();
            DropDownList2.SelectedItem.Text = "Janvary";

            Calendar1.VisibleDate = Convert.ToDateTime("January" + 1908);
        }
    
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int year = Convert.ToInt16(DropDownList1.SelectedValue);
        int month = Convert.ToInt16(DropDownList2.SelectedValue);

        Calendar1.VisibleDate = new DateTime(year, month, 1);
        Calendar1.SelectedDate = new DateTime(year, month, 1);

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        int year = Convert.ToInt16(DropDownList1.SelectedValue);
        int month = Convert.ToInt16(DropDownList2.SelectedValue);

        Calendar1.VisibleDate = new DateTime(year, month, 1);
        Calendar1.SelectedDate = new DateTime(year, month, 1);
 
    }
    protected void btnrefresh_Click(object sender, EventArgs e)
    {
        GenerateAutoID();
        lbldate.Text = DateTime.Now.ToShortDateString();
        lbltime.Text = DateTime.Now.ToShortTimeString();

        ddlname.ClearSelection();
        ddlname.SelectedItem.Text = "select";
        txtname.Text = "";
        ddlcareof.ClearSelection();
        ddlcareof.SelectedItem.Text = "select";
        txtcare.Text = "";
        txtaddress.Text = "";
        ddlbg.ClearSelection();
        ddlbg.SelectedItem.Text = "select";
        txtcity.Text = "";
        txtdob.Text = "";
        txtdist.Text = "";
        txtage.Text = "";
        ddlstate.ClearSelection();
        ddlstate.SelectedItem.Text = "select";
        txtmobile.Text = "";
        txtpin.Text = "";
        Radiofemale.Checked = false;
        Radiomale.Checked = false;
        Radioother.Checked = false;
        ddldept.ClearSelection();
        ddldept.SelectedItem.Text = "select";
        txtadhar.Text = "";
        ddldoctor.ClearSelection();
        ddldoctor.SelectedItem.Text = "select";
        txtreferal.Text = "";
        txtremark.Text = "";


        txtopno.Enabled = true ;
        Btnedit.Visible = true;
        btnupdate.Visible = false;
        Panel2.Enabled = true;
        txtadhar.Enabled = true;
        ddldoctor.Enabled = true;
        ddldept.Enabled = true;
        ImageButton1.Enabled = true;
        ddlname.Enabled = true;
        txtname.Enabled = true;
        ddlbg.Enabled = true;

        Panel1.Enabled = true;
        txtopno.Text = "";
        txtopno1.Text = "";
        txtopno1.Visible = true;
        btnsearch.Visible = true;
        txtopno.Visible = true;     
                
    }
    protected void ddldept_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddldept.SelectedItem.Text == "select")
        {
            ddldoctor.Items.Clear();
            ddldoctor.Items.Add("select");



        }

        else
        {


            string dd;



            c = new connect();
            c.cmd.CommandText = "select * from empreg where department='" + ddldept.SelectedItem.Text + "' and status='active'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;

            adp.Fill(ds, "dept");
            if (ds.Tables["dept"].Rows.Count > 0)
            {
                ddldoctor.Items.Clear();
                ddldoctor.Items.Add("select");


                for (int i = 0; i <= ds.Tables["dept"].Rows.Count - 1; i++)
                {
                    dd = Convert.ToString(ds.Tables["dept"].Rows[i].ItemArray[3]);
                    ddldoctor.Items.Add(dd);
                }


                ;
            }


        }
    }
}
