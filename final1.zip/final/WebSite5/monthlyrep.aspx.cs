using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class monthlyrep : System.Web.UI.Page
{
    connect c, d, g, f;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    double tot, k, l, m;
    protected void Page_Load(object sender, EventArgs e)
    {

 


    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        double wc, lc, dc, tc, sc, ipt, totb,bs;
        g = new connect();
        g.cmd.CommandText = "select * from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
        ds = new DataSet();
        adp.SelectCommand = g.cmd;
        adp.Fill(ds, "e");
        if (ds.Tables["e"].Rows.Count > 0)
        {
            Panel2.Visible = true;

            g.cmd.CommandText = "select sum(tot)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            wc = Convert.ToDouble(g.cmd.ExecuteScalar());
            Label6.Text = wc.ToString();
            g.cmd.CommandText = "select sum(lcharge)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            lc = Convert.ToDouble(g.cmd.ExecuteScalar());
            Label7.Text = lc.ToString();
            g.cmd.CommandText = "select sum(dcharge)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            dc = Convert.ToDouble(g.cmd.ExecuteScalar());
            Label8.Text = dc.ToString();




            g.cmd.CommandText = "select sum(tcharge)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            tc  = Convert.ToDouble(g.cmd.ExecuteScalar());
            Label9.Text = tc.ToString();

            g.cmd.CommandText = "select sum(bedshift)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            bs = Convert.ToDouble(g.cmd.ExecuteScalar());
            lblbshift.Text = bs.ToString();
            
            ipt = wc + lc + dc+tc+bs ;
            Label10.Text = ipt.ToString();

            g.cmd.CommandText = "select sum(samt)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            sc = Convert.ToDouble(g.cmd.ExecuteScalar());
            Label11.Text = sc.ToString();

           
            //sc = 0;








            totb = ipt - sc;
            Label12.Text = totb.ToString();




        }
    }


    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "select" || DropDownList2.SelectedItem.Text == "select")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select First!!!')</script>");
        }
        else
        {
            c = new connect();
            c.cmd.CommandText = "select * from concharges where year(date)='" + DropDownList2.SelectedItem.Text + "' and  month(date)='" + DropDownList1.SelectedValue.ToString() + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;

            adp.Fill(ds, "ac");
            if (ds.Tables["ac"].Rows.Count > 0)
            {
                Panel1.Visible = true;
                LinkButton3.Visible = false;
                DropDownList1.Enabled = false;
                DropDownList2.Enabled = false;


                c.cmd.CommandText = "select sum(charge)from concharges where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";

                double i = Convert.ToDouble(c.cmd.ExecuteScalar());
                c.cmd.CommandText = "select sum(admfees)from concharges where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
                double j = Convert.ToDouble(c.cmd.ExecuteScalar());
                //double tot = i + j;
                tot = i + j;
                Label1.Text = tot.ToString();
                //MessageBox.Show(tot.ToString());

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Record Not Found!!!')</script>");
       
            }

            d = new connect();
            d.cmd.CommandText = "select * from labbtest where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = d.cmd;
            adp.Fill(ds, "e");
            if (ds.Tables["e"].Rows.Count > 0)
            {
                d.cmd.CommandText = "select sum(charge)from labbtest where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";

                //double k = Convert.ToDouble(d.cmd.ExecuteScalar());
                k = Convert.ToDouble(d.cmd.ExecuteScalar());

                Label2.Text = k.ToString();

            }
            g = new connect();
            g.cmd.CommandText = "select * from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = g.cmd;
            adp.Fill(ds, "e");
            if (ds.Tables["e"].Rows.Count > 0)
            {
                g.cmd.CommandText = "select sum(fbill)from ipbill where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";

                // double l = Convert.ToDouble(g.cmd.ExecuteScalar());
                l = Convert.ToDouble(g.cmd.ExecuteScalar());

                Label3.Text = l.ToString();

            }
            f = new connect();
            f.cmd.CommandText = "select * from labopb where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = f.cmd;
            adp.Fill(ds, "e");
            if (ds.Tables["e"].Rows.Count > 0)
            {
                f.cmd.CommandText = "select sum(total)from labopb where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'";

                //double m = Convert.ToDouble(f.cmd.ExecuteScalar());
                m = Convert.ToDouble(f.cmd.ExecuteScalar());

                Label4.Text = m.ToString();




            }
            double total = tot + k + l + m;
            Label5.Text = total.ToString();
            
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "select";
        DropDownList2.ClearSelection();
        DropDownList2.SelectedItem.Text = "select";
        Label1.Text = "-";
        lblbshift.Text = "-";
        Label2.Text = "-";
        Label3.Text = "-";
        Label4.Text = "-";
        Label5.Text = "-";
        Label6.Text = "-";
        Label7.Text = "-";
        Label8.Text = "-";
        Label9.Text = "-";
        Label10.Text = "-";
        Label11.Text = "-";
        Label12.Text = "-";

        LinkButton3.Visible = true ;
        DropDownList1.Enabled = true ;
        DropDownList2.Enabled = true ;
 
    }
}
