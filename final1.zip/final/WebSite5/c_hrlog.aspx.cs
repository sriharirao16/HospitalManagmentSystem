using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class c_hrlog : System.Web.UI.Page
{
    connect c;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (String)Session["id"];
        TextBox1.Text = s.ToString();
        //TextBox1.Text = "105";

        if (IsPostBack)
        {
            String password = txtcpss.Text;
            txtcpss.Attributes.Add("value", password);
        }

    }
    protected void txtpass_TextChanged(object sender, EventArgs e)
    {
        if (txtpass.Text.Length < 4)
        {
            //MessageBox.Show("Minimum 4 characters");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Minimum Sholud be 4 character!!!')</script>");
            txtpass.Text = "";
            txtpass.Focus();

        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if (txtpass.Text == txtcpss.Text)
        {

            if (txtpass.Text.Length >= 4)
            {
                try
                {
                    c = new connect();


                    c.cmd.CommandText = "insert into hrlogin values (@hrid,@password,@status1,@newpass)";
                    c.cmd.Parameters.Add("@hrid", SqlDbType.NVarChar).Value = TextBox1.Text;
                    c.cmd.Parameters.Add("@password", SqlDbType.NVarChar).Value = txtpass.Text;
                    c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "active";
                    c.cmd.Parameters.Add("@newpass", SqlDbType.NVarChar).Value = "";

                    c.cmd.ExecuteNonQuery();
                    //MessageBox.Show("Registration successfull");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Registration Sucefally Done!!!')</script>");
                    Response.Redirect("~/admgirst.aspx");

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }
            else
                //MessageBox.Show("check password");

                  Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check Password!!!')</script>");
        }
        else
        {
            //MessageBox.Show("password and confirm password should be same");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Password and Confirm Password should be same!!!')</script>");
        }
    }

    protected void showpass_CheckedChanged(object sender, EventArgs e)
    {
        if (showpass.Checked == false)
            txtcpss.TextMode = TextBoxMode.Password;
        if (showpass.Checked == true)
            txtcpss.TextMode = TextBoxMode.SingleLine;


    }
    protected void txtcpss_TextChanged(object sender, EventArgs e)
    {
        if (txtcpss.Text.Length < 4)
        {
            //MessageBox.Show("Minimum 4 characters");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Confirm Password Should be 4 Charcters!!!')</script>");
            txtcpss.Text = "";
            txtcpss.Focus();

        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}