using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Drawing ;

public partial class ipsearch : System.Web.UI.Page
{

    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtipid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Emp Id First!!!')</script>");
           // MessageBox.Show("enter  emp id first");
        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from ipreg where ipno='" + txtipid.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "ip");
                if (ds.Tables["ip"].Rows.Count > 0)
                {
                    Label1.Visible = true;
                    LinkButton2.Visible = true;
                    LinkButton1.Visible = false;
                    LinkButton3.Visible = true;
                    lbllab.Visible = true;
                    LinkButton4.Visible = true;
                    Label2.Visible = true;
                    txtipid.Enabled = false;
                    for (int i = 0; i <= ds.Tables["ip"].Rows.Count - 1; i++)
                    {
                        txtname.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[5]);
                        txtdate.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[2]);
                        txtadd.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[8]);
                        txtadhar.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[15]);
                        txtage.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[18]);
                        txtmbl.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[14]);
                        txtdept.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[19]);
                        txtsex.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[17]);
                        txtdoc.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[22]);
                        txtpin.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[12]);

                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record  Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtipid.Text = "";
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }


    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        if (txtipid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Emp Id First!!!')</script>");
            //MessageBox.Show("enter  emp id first");
        }
        else
        {
            WardType.Visible = true;
            WardNumber.Visible = true;
            BedCharge.Visible = true;
            BedNumber.Visible = true;
            txtwno.Visible = true;
            txtward.Visible = true;
            txtbed.Visible = true;
            txtcharge.Visible = true;


            txtward.Enabled = false;
            txtwno.Enabled = false;
            txtbed.Enabled = false;
            txtcharge.Enabled = false;

            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from ipreg where ipno='" + txtipid.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        txtward.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[23]);
                        txtwno.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                        txtbed.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]);
                        txtcharge.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);


                    }
                }
                else
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

        
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {

       



       
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {

        if (txtipid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Emp Id First!!!')</script>");
            //MessageBox.Show("enter  emp id first");
        }
        else
        {


            try
            {
                c = new connect();
                c.cmd.CommandText = "select ipcareof,dob,city,bloodgrp,dist,referal,remark  from ipreg where ipno='" + txtipid.Text + "'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "emp");

                if (ds.Tables["emp"].Rows.Count >= 0)
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = ds.Tables["emp"];
                    GridView1.DataBind();

                }
                else
                {
                    GridView1.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check Emp Id!!!')</script>");
                    //MessageBox.Show("check emp id");

                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

        }

    
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        LinkButton2.Visible = false;
        Label2.Visible = false;
        LinkButton4.Visible = false;
        Label1.Visible = false;
        LinkButton3.Visible = false;
        lbllab.Visible = false;
        LinkButton1.Visible = true;
        GridView1.Visible = false;
        GridView2.Visible = false;
        txtipid.Enabled = true ;
        txtadd.Text = "";
        txtadhar.Text = "";
        txtage.Text = "";
        txtbed.Text = "";
        txtcharge.Text = "";
        txtdate.Text = "";
        txtdept.Text = "";
        txtdoc.Text = "";
        txtipid.Text = "";
        txtmbl.Text = "";
        txtname .Text ="";
        txtpin .Text ="";
        txtsex .Text ="";
        txtward .Text ="";
        txtwno .Text ="";

    }
    protected void LinkButton3_Click1(object sender, EventArgs e)
    {
        if (txtipid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Emp Id First!!!')</script>");
            //MessageBox.Show("enter  emp id first");
        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from labdetails where pid='" + txtipid.Text + "'and ptype='IP'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    GridView2.Visible = true;
                    GridView2.DataSource = ds.Tables["edit"];
                    GridView2.DataBind();
                   

                }
                else
                {
                    GridView2.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

        }

    }
}
