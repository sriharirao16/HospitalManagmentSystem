using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class stafflock : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Linkbtninfo_Click(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        try
        {
            c = new connect();
            c.cmd.CommandText = "select empid,password,status1 from userlog where empid='" + txtempid .Text  + "'";
            adp.SelectCommand = c.cmd;
            ds = new DataSet();
            adp.Fill(ds, "lock");

            if (ds.Tables["lock"].Rows.Count >= 0)
            {

                for (int i = 0; i <= ds.Tables["lock"].Rows.Count - 1; i++)
                {
                    txtpass .Text  = Convert.ToString(ds.Tables["lock"].Rows[i].ItemArray[1]);
                    txtstatus .Text  = Convert.ToString(ds.Tables["lock"].Rows[i].ItemArray[2]);

                    if (txtstatus.Text == "active")
                    {
                        linkbtnunblock.Visible = false;
                    }
                    else
                    {
                        linkbtnunblock.Visible = true;
                    }



                }
            }
            else

                //MessageBox.Show("emp id does not exist");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Employee Id Does Not Exist!!!')</script>");

        }

        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
    protected void linkbtnunblock_Click(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        c = new connect();
        c.cmd.CommandText = "update userlog set status1=@status1 where empid='" + txtempid .Text  + "'";
        c.cmd.Parameters.Clear();
        c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "active";
        c.cmd.ExecuteNonQuery();
        //MessageBox.Show("active");
        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Active!!!')</script>");
        txtstatus.Text = "active";
    }
    protected void btndisplay_Click(object sender, EventArgs e)
    {
      
        try
        {
            c = new connect();
            c.cmd.CommandText = "select empid,password,status1 from  userlog where status1='lock'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lock");
            if (ds.Tables["lock"].Rows.Count > 0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = ds.Tables["lock"];
                GridView1.DataBind();
            }
            else
            {
                //MessageBox.Show("does not exist");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Does Not Exist!!!')</script>");
                GridView1.Visible = false;
            }

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        txtempid.Text = "";
        txtpass.Text = "";
        txtstatus.Text = "";
        GridView1.Visible = false;
    }
}
