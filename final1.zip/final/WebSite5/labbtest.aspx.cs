using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;


public partial class labbtest : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        DateTime today = DateTime.Now;
        Label1.Text = today.ToShortDateString();
        TextBox4.Text = "50";
        if (!IsPostBack)
        {
            GenerateAutoID();
        }
    }
    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(slno)from labbtest ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        Label2.Text = i.ToString();

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        GenerateAutoID();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
      
        TextBox5.Text = "";
        DropDownList1 .ClearSelection ();
        DropDownList1 .SelectedItem .Text ="-------Select--------";

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" || TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "" || TextBox5.Text == "" || DropDownList1.SelectedItem.Text == "-------Select--------")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter The All Fields!!!')</script>");
            //MessageBox.Show("enter All Filelds");
        }
        else 
        {
            decimal age;
            age = Convert.ToDecimal(TextBox3.Text);
            if (age == 0 || age > 103)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check Your Age!!!')</script>");
                //MessageBox.Show("check your age");
                TextBox3.Text = "";

            }
            else
            {

                try
                {
                    c = new connect();
                    c.cmd.CommandText = "insert into labbtest values(@date,@slno,@name,@adress,@age,@sex,@mbl,@charge,@status,@report)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = Label1.Text;
                    c.cmd.Parameters.Add("@slno", SqlDbType.NVarChar).Value = Label2.Text;
                    c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = TextBox1.Text;
                    c.cmd.Parameters.Add("@adress", SqlDbType.NVarChar).Value = TextBox2.Text;
                    c.cmd.Parameters.Add("@age", SqlDbType.Decimal).Value = Convert.ToDecimal(TextBox3.Text);
                    c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = DropDownList1.SelectedItem.Text;
                    c.cmd.Parameters.Add("@mbl", SqlDbType.Decimal).Value = Convert.ToDecimal(TextBox5.Text);
                    c.cmd.Parameters.Add("@charge", SqlDbType.Decimal).Value = Convert.ToDecimal(TextBox4.Text);
                    c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "pending";
                    c.cmd.Parameters.Add("@report", SqlDbType.NVarChar).Value = "Null";
                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Saved!!!')</script>");
                    //MessageBox.Show("Saved");
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox3.Text = "";

                    TextBox5.Text = "";
                    DropDownList1.ClearSelection();
                    DropDownList1.SelectedItem.Text = "-------Select--------";
                    GenerateAutoID();
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }
        }

    }
}
