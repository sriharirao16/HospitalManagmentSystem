using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class labbtestr : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        try
        {

            c = new connect();
            c.cmd.CommandText = "select * from labbtest where slno='" + txtslno .Text  + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lab");
            if (ds.Tables["lab"].Rows.Count > 0)
            {
                LinkButton1.Visible = false;
                Panel1.Visible = true;
                for (int i = 0; i <= ds.Tables["lab"].Rows.Count - 1; i++)
                {
                    DateTime  da = Convert.ToDateTime (ds.Tables["lab"].Rows[i].ItemArray[0]);
                    Labeltd.Text = da.ToShortDateString();
                    Labeln.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[2]);
                    Labelad.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[3]);
                    Labela.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[4]);
                    Labelg.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[5]);
                    Labelm.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[6]);
                    Button2.Visible = true;
                   

                }
            }
            else
            {
                LinkButton1.Visible = true;
                Panel1.Visible = false;
                //MessageBox.Show("record does not found");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Record Does Not Found!!!')</script>");
                txtslno .Text ="";
              
               
            }

        }
        catch (Exception)
        {
            throw;
        }
            finally
            {
                c.cnn.Close();
            }
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "-------Select--------")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('select Blood Group!!!')</script>");
           // MessageBox.Show("select blood Group");
        }

        else
        {
              c = new connect();
            c.cmd.CommandText = "select * from labbtest where slno='" + txtslno .Text  + "'and status='pending'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lab");
            if (ds.Tables["lab"].Rows.Count > 0)
            {

                Button2.Visible = false;
                try
                {


                    c = new connect();
                    c.cmd.CommandText = "update labbtest set status=@status,report=@report where slno='" + txtslno.Text + "'";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "report";
                    c.cmd.Parameters.Add("@report", SqlDbType.NVarChar).Value = DropDownList1.SelectedItem.Text;

                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Saved!!!')</script>");
                    //MessageBox.Show("saved");

                    // GridView1.Visible = true;

                    c = new connect();
                    c.cmd.CommandText = "select name,report from labbtest where slno='" + txtslno.Text + "'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "lab");
                    if (ds.Tables["lab"].Rows.Count > 0)
                    {
                        GridView1.Visible = true;
                        GridView1.DataSource = ds.Tables["lab"];
                        GridView1.DataBind();
                    }

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Report Already Given!!!')</script>");
                //MessageBox.Show("report already Given");
                Button2.Visible = false;
            }

        }
            
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        Button2.Visible = true;
        LinkButton1.Visible = true;
        Panel1.Visible = false;
        txtslno.Text = "";
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "-------Select--------";
        Labela.Text = "-";
        Labelad.Text = "-";
        Labeltd.Text = "-";
        Labelg.Text = "-";
        Labelm.Text = "-";
        Labeln.Text = "-";
        Labeltd.Text = "-";
        

    }
}
