using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class userlog : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txthrid.Text == "")
        {
            //MessageBox.Show("enter Hr Id");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Hr Id!!!')</script>");
        }
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select hrid,password,status1 from hrlogin where hrid='" + txthrid.Text + "'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "lock");

                if (ds.Tables["lock"].Rows.Count > 0)
                {
                    LinkButton1.Visible = false;
                    txthrid.Enabled = false;

                    for (int i = 0; i <= ds.Tables["lock"].Rows.Count - 1; i++)
                    {
                        txtpass.Text = Convert.ToString(ds.Tables["lock"].Rows[i].ItemArray[1]);
                        txtstatus.Text = Convert.ToString(ds.Tables["lock"].Rows[i].ItemArray[2]);

                        if (txtstatus.Text == "active")
                        {
                            Unblock.Visible = false;
                        }
                        else if (txtstatus.Text == "Inactive")
                        {
                            Unblock.Visible = false;
                        }
                        else
                        {
                            Unblock.Visible = true;
                        }
                    }
                }
                else
                {

                    //MessageBox.Show("hr id does not exist");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Hr Id Does Not Exist!!!')</script>");
                    txthrid.Text = "";
                }

            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            c = new connect();
            c.cmd.CommandText = "select hrid,password,status1 from  hrlogin where status1='lock'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lock");
            if (ds.Tables["lock"].Rows.Count > 0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = ds.Tables["lock"];
                GridView1.DataBind();
            }
            else
            {
                //MessageBox.Show("does not exist");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Does Not Exist!!!')</script>");
                GridView1.Visible = false ;
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    protected void Unblock_Click(object sender, EventArgs e)
    {
        c = new connect();
        c.cmd.CommandText = "update hrlogin set status1=@status1 where hrid='" + txthrid.Text + "'";
        c.cmd.Parameters.Clear();
        c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "active";
        c.cmd.ExecuteNonQuery();
        //MessageBox.Show("active");
        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Ative!!!')</script>");
        txtstatus.Text = "active";

    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        txthrid.Text = "";
        txtpass.Text = "";
        txtstatus.Text = "";
        GridView1.Visible = false;
        LinkButton1.Visible = true ;
        txthrid.Enabled =true ;

    }
}

    