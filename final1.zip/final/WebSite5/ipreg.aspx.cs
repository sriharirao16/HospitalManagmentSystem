using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class ipreg : System.Web.UI.Page
{
    connect c;
    DataSet ds1;
    DataSet ds;
       
    SqlDataAdapter adp = new SqlDataAdapter();
    SqlDataAdapter adp1 = new SqlDataAdapter();
    


    String pid = "Ip";
    
   
    protected void Page_Load(object sender, EventArgs e)
    {
        lbldate.Text = DateTime.Now.ToShortDateString();
        lbltime.Text = DateTime.Now.ToShortTimeString();
   
        MaintainScrollPositionOnPostBack = true;
        
        if (!IsPostBack)
        {
            GenerateAutoID();
        }
    }
    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(ipno)from ipreg ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        Label1 .Text  = pid + i.ToString();


    }



    protected void Btnedit_Click(object sender, EventArgs e)
    {
        if (txtipno.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Ip No First!!!')</script>");
            //MessageBox.Show("enter ip no.first");
        }
        else
        {
            try
            {
               
                DateTime da, ta, dob;
                c = new connect();
                c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    txtopno.Enabled = false;
                    txtreferal.Enabled = false;
                    txtremark.Enabled = false;
                    ddlbg.Enabled = false;
                    Btnedit.Visible = false;
                    btnupdate.Visible = true;
                    txtipno.Enabled = false;
                    txtipno1.Visible = false;
                    btnsearch.Visible = false;
                    btnsave.Visible = false;
                    LinkButton1.Visible = false;
                    txtbedc.Enabled = false;
                    ddlbedno.Enabled = false;
                    ddlwardno.Enabled = false;
                    ddlwardtype.Enabled = false;
                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        txtopno.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                        Label1.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[1]);
                        da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[2]);
                        lbldate.Text = da.ToString("d");
                        ta = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[3]);
                        lbltime.Text = ta.ToString("t");
                        ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                        txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                        ddlcareof.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);

                        txtcareof.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);

                        txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                        ddlstate.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                        txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);
                        txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[11]);
                        txtpincode.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);

                        dob = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[13]);
                        txtdob.Text = da.ToString("d");

                        txtmobile.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                        txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                        ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);

                        txtsex.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);



                        txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);


                        ddldept.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[19]);
                        txtreferal.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                        txtremark.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                        ddldoc.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[22]);
                        ddlwardtype.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[23]);
                        ddlwardno.Items.Add(Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]));
                        ddlbedno.Items.Add(Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]));
                        //ddlwardno.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                        //ddlbedno.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]);
                        txtbedc.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);
                        ddlscheme.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[28]);

                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtipno1.Text = "";
                    txtipno.Text = "";
                    txtopno.Text = "";
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }


    }
    protected void btnsearch_Click1(object sender, EventArgs e)
    {
        if (txtipno1.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Ip No. First!!!')</script>");
            //MessageBox.Show("enter ip no.first");
        }
        else
        {
            try
            {

                DateTime da, ta, dob;
                c = new connect();
                c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno1.Text + "'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    Panel3.Visible = false;
                    btnsave.Visible = false;
                    LinkButton1.Visible = false;
                    txtopno.Enabled = false;
                    Panel2.Enabled = false;
                    Panel1.Enabled = false;

                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        txtopno.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                        Label1.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[1]);
                        da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[2]);
                        lbldate.Text = da.ToString("d");
                        ta = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[3]);
                        lbltime.Text = ta.ToString("t");
                        ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                        txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                        ddlcareof.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);

                        txtcareof.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);

                        txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                        ddlstate.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                        txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);
                        txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[11]);
                        txtpincode.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);

                        dob = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[13]);
                        txtdob.Text = da.ToString("d");

                        txtmobile.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                        txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                        ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);

                        txtsex.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);



                        txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);


                        ddldept.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[19]);
                        txtreferal.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                        txtremark.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                        ddldoc.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[22]);
                        ddlwardtype.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[23]);
                        ddlwardno.Items.Add(Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]));
                        ddlbedno.Items.Add(Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]));
                        //ddlwardno.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                        //ddlbedno.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]);
                        txtbedc.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);
                        ddlscheme.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[28]);



                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtipno1.Text = "";
                    txtipno.Text = "";
                    txtopno.Text = "";
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }


    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        if ( ddlcareof.SelectedItem.Text == "select" || txtcareof.Text == "" || txtaddress.Text == "" || txtdist.Text == "" || txtcity.Text == "" || txtpincode.Text == "" || txtmobile.Text == ""  || ddlstate.SelectedItem.Text == "select" )
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All Fielda!!!')</script>");
            //MessageBox.Show("enter all fields");
        }
        else
        {

            try
            {

                c = new connect();
                // c.cmd.CommandText = "update opreg set opndrp='" + ddrna.SelectedItem.Text + "'," + "opname='" + txtname.Text + "'," + "opcare='" + txtcareof.Text + "'," + "opcdrp='" + ddrca.SelectedItem.Text + "'," + "opaddress='" + txtaddress.Text + "'," + "state='" + ddlstate.SelectedItem.Text + "'," + "district='" + txtdistrict.Text + "'," + "taluk='" + txttaluk.Text + "'," + "city='" + txtcity.Text + "'," + "mobile='" + txtmoblie.Text + "'," + "phone='" + txtphone.Text + "'," + "dob='" + txtdob.Text + "'," + "age='" + txtage.Text + "'," + "sex=@sex," + "department='" + txtdepartment.Text + "'," + "adhar='" + txtadhar.Text + "'," + "email='" + txtemail.Text + "'," + "referal='" + txtreferal.Text + "'," + "remark='" + txtremark.Text + "'" + " where opno='" + txtopno.Text + "'";
                c.cmd.CommandText = "update ipreg set ipcdrp=@ipcdrp, ipcareof=@ipcareof,address=@address,state=@state,dist=@dist,city=@city,pin=@pin,mob=@mob,scheme=@scheme where ipno='" + txtipno.Text + "'";
                c.cmd.Parameters.Clear();
                c.cmd.Parameters.Add("@ipcdrp", SqlDbType.NVarChar).Value = ddlcareof.SelectedItem.Text;
                c.cmd.Parameters.Add("@ipcareof", SqlDbType.NVarChar).Value = txtcareof.Text;
                c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = ddlstate.SelectedItem.Text;
                c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpincode.Text);
                c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmobile.Text);
                c.cmd.Parameters.Add("@scheme", SqlDbType.NVarChar).Value = ddlscheme .SelectedItem .Text ;

                c.cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Update Sucefully done!!!')</script>");
                //MessageBox.Show("update successfull");
                GenerateAutoID();
                lbldate.Text = DateTime.Now.ToShortDateString();
                lbltime.Text = DateTime.Now.ToShortTimeString();

                txtopno.Text = "";
                txtipno.Text = "";
                txtipno1.Text = "";
                ddlname.ClearSelection();
                ddlname.SelectedItem.Text = "select";
                txtname.Text = "";
                ddlcareof.ClearSelection();
                ddlcareof.SelectedItem.Text = "select";
                txtcareof.Text = "";
                txtaddress.Text = ""; 
                ddldoc.ClearSelection();
                ddldoc.SelectedItem.Text = "select";
        

                txtdist.Text = "";
                txtcity.Text = "";
                txtpincode.Text = "";
                txtdob.Text = "";
                txtmobile.Text = "";
                txtadhar.Text = "";
                ddlbg.ClearSelection();
                ddlbg.SelectedItem.Text = "select";
                txtsex.Text = "";
                txtage.Text = "";
                ddldept.ClearSelection();
                ddldept.SelectedItem.Text = "select";
                txtreferal.Text = "";
                txtremark.Text = "";
                ddlstate.ClearSelection();
                ddlstate.SelectedItem.Text = "select";
                ddlwardtype.ClearSelection();
                ddlwardtype.SelectedItem.Text = "select";
                ddlwardno.Items.Clear();
                ddlbedno.Items.Clear();
                ddlscheme.ClearSelection();
                ddlscheme.SelectedItem.Text = "select";

                txtbedc.Text = "";
                txtopno.Enabled = true ;
                txtreferal.Enabled = true;
                txtremark.Enabled = true;
                ddlbg.Enabled = true;
                Btnedit.Visible = true;
                btnupdate.Visible = false ;
                txtipno.Enabled = true;
                txtipno1.Visible = true ;
                btnsearch.Visible = true ;
                btnsave.Visible = true ;

                LinkButton1.Visible = true ;
                txtbedc.Enabled = true ;
                ddlbedno.Enabled = true ;
                ddlwardno.Enabled = true ;
                ddlwardtype.Enabled = true ;



            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (txtopno.Text == "" || ddlcareof.SelectedItem.Text == "select" || txtcareof.Text == "" || txtaddress.Text == "" || txtdist.Text == "" || txtcity.Text == "" || txtpincode.Text == "" || txtmobile.Text == "" || ddlbg.SelectedItem.Text == "select" || ddldept.SelectedItem.Text == "select" || txtremark.Text == "" || ddlstate.SelectedItem.Text == "select" || ddldoc.SelectedItem.Text == "select" || ddlwardtype.SelectedItem.Text == "select" || ddlwardno.SelectedItem.Text == "select" || ddlbedno.SelectedItem.Text == "select"  || txtbedc.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All The Fields!!!')</script>");
            //MessageBox.Show("enter all fields");
        }
        else
        {


            c = new connect();
            c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "del");
            if (ds.Tables["del"].Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already Done!!!')</script>");
                //MessageBox.Show("record already done");
                GenerateAutoID();
                lbldate.Text = DateTime.Now.ToShortDateString();
                lbltime.Text = DateTime.Now.ToShortTimeString();

                txtopno.Text = "";
                txtipno.Text = "";
                txtipno1.Text = "";
                ddlname.ClearSelection();
                ddlname.SelectedItem.Text = "select";
                txtname.Text = "";
                ddlcareof.ClearSelection();
                ddlcareof.SelectedItem.Text = "select";
                txtcareof.Text = "";
                txtaddress.Text = "";
                ddldoc.ClearSelection();
                ddldoc.SelectedItem.Text = "select";
        
                txtdist.Text = "";
                txtcity.Text = "";
                txtpincode.Text = "";
                txtdob.Text = "";
                txtmobile.Text = "";
                txtadhar.Text = "";
                ddlbg.ClearSelection();
                ddlbg.SelectedItem.Text = "select";
                txtsex.Text = "";
                txtage.Text = "";
                ddldept.ClearSelection();
                ddldept.SelectedItem.Text = "select";
                txtreferal.Text = "";
                txtremark.Text = "";
                ddlstate.ClearSelection();
                ddlstate.SelectedItem.Text = "select";
                ddlwardtype.ClearSelection();
                ddlwardtype.SelectedItem.Text = "select";
                ddlwardno.Items.Clear();
                ddlbedno.Items.Clear();
                ddlscheme.ClearSelection();
                ddlscheme.SelectedItem.Text = "select";

                txtbedc.Text = "";
                LinkButton1.Visible = true;
                txtopno.Enabled = true;
                Panel3.Visible = true;
            }
            else
            {

                try
                {

                    c = new connect();
                    c.cmd.CommandText = "insert into ipreg values(@opno,@ipno,@ipdate,@iptime,@ipndrp,@ipname,@ipcdrp,@ipcareof,@address,@state,@dist,@city,@pin,@dob,@mob,@adhar,@bloodgrp,@sex,@age,@dept,@referal,@remark,@doc,@wardtype,@wardno,@bedno,@bedcharges,@status,@scheme)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@opno", SqlDbType.NVarChar).Value = txtopno.Text;
                    c.cmd.Parameters.Add("@ipno", SqlDbType.NVarChar).Value = Label1.Text;
                    c.cmd.Parameters.Add("@ipdate", SqlDbType.DateTime).Value = lbldate.Text;
                    c.cmd.Parameters.Add("@iptime", SqlDbType.DateTime).Value = lbltime.Text;
                    c.cmd.Parameters.Add("@ipndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                    c.cmd.Parameters.Add("@ipname", SqlDbType.NVarChar).Value = txtname.Text;
                    c.cmd.Parameters.Add("@ipcdrp", SqlDbType.NVarChar).Value = ddlcareof.SelectedItem.Text;
                    c.cmd.Parameters.Add("@ipcareof", SqlDbType.NVarChar).Value = txtcareof.Text;


                    c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                    c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = ddlstate.SelectedItem.Text;
                    c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                    c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                    c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpincode.Text);

                    c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = txtdob.Text;
                    c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmobile.Text);
                    c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                    c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                    
                    c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = txtsex .Text ;
                    c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                    //c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                    c.cmd.Parameters.Add("@dept", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                    c.cmd.Parameters.Add("@referal", SqlDbType.NVarChar).Value = txtreferal.Text;
                    c.cmd.Parameters.Add("@remark", SqlDbType.NVarChar).Value = txtremark.Text;
                    c.cmd.Parameters.Add("@doc", SqlDbType.NVarChar).Value = ddldoc.SelectedItem.Text;
                    c.cmd.Parameters.Add("@wardtype", SqlDbType.NVarChar).Value = ddlwardtype.SelectedItem.Text;
                    c.cmd.Parameters.Add("@wardno", SqlDbType.NVarChar).Value = ddlwardno.SelectedItem.Text;
                    c.cmd.Parameters.Add("@bedno", SqlDbType.NVarChar).Value = ddlbedno.SelectedItem.Text;
                    c.cmd.Parameters.Add("@bedcharges", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbedc.Text); ;
                    c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "book";
                    c.cmd.Parameters.Add("@scheme", SqlDbType.NVarChar).Value = ddlscheme.SelectedItem.Text;

                    c.cmd.ExecuteNonQuery();
                    String s = ddlbedno.SelectedItem.Text.ToString();
                    c.cmd.CommandText = "update ward set status1=@status1 where bedno='" + s + "'";
                    c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "book";

                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                    //MessageBox.Show("Saved");
                    GenerateAutoID();
                    lbldate.Text = DateTime.Now.ToShortDateString();
                    lbltime.Text = DateTime.Now.ToShortTimeString();

                    txtopno.Text = "";
                    txtipno.Text = "";
                    txtipno1.Text = "";
                    ddlname.ClearSelection();
                    ddlname.SelectedItem.Text = "select";
                    txtname.Text = "";
                    ddlcareof.ClearSelection();
                    ddlcareof.SelectedItem.Text = "select";
                    txtcareof.Text = "";
                    txtaddress.Text = "";
                    ddldoc.ClearSelection();
                    ddldoc.SelectedItem.Text = "select";
        
                    txtdist.Text = "";
                    txtcity.Text = "";
                    txtpincode.Text = "";
                    txtdob.Text = "";
                    txtmobile.Text = "";
                    txtadhar.Text = "";
                    ddlbg.ClearSelection();
                    ddlbg.SelectedItem.Text = "select";
                    txtsex.Text = "";
                    txtage.Text = "";
                    ddldept.ClearSelection();
                    ddldept.SelectedItem.Text = "select";
                    txtreferal.Text = "";
                    txtremark.Text = "";
                    ddlstate.ClearSelection();
                    ddlstate.SelectedItem.Text = "select";
                    ddlwardtype.ClearSelection();
                    ddlwardtype.SelectedItem.Text = "select";
                    ddlwardno.Items.Clear();
                    ddlbedno.Items.Clear();
                    ddlscheme.ClearSelection();
                    ddlscheme.SelectedItem.Text = "select";

                    txtbedc.Text = "";
                    LinkButton1.Visible = true;
                    txtopno.Enabled = true;
                    Panel3.Visible = true;
       
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }

        }

  
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        // Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Employee-Id Doesnot Exists!!!')</script>");

        if (txtopno.Text == "")
        {
            //MessageBox.Show("enter op no.first");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Op No First!!!')</script>");

        }
        else
        {
            try
            {
                string gen;
                c = new connect();
                c.cmd.CommandText = "select * from opreg where opno='" + txtopno.Text + "'";

                ds1 = new DataSet();
                adp1.SelectCommand = c.cmd;
                adp1.Fill(ds1, "edit");
                if (ds1.Tables["edit"].Rows.Count > 0)
                {
                    GenerateAutoID();
                    LinkButton1.Visible = false;
                    txtopno.Enabled = false;
                    Panel3.Visible = false;

                    for (int i = 0; i <= ds1.Tables["edit"].Rows.Count - 1; i++)
                    {

                        txtopno.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[0]);
                        lbldate.Text = DateTime.Now.ToShortDateString();
                        lbltime.Text = DateTime.Now.ToShortTimeString();
                        ddlname.SelectedItem.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[3]);
                        txtname.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[4]);
                        ddlcareof.SelectedItem.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[5]);
                        txtcareof.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[6]);
                        txtaddress.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[7]);
                        ddlbg.SelectedItem.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[8]);
                        txtage.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[9]);
                        txtsex.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[10]);

                        //if (gen == "male")
                        //{
                        //    Radiomale.Checked = true;
                        //}
                        //else if (gen == "female")
                        //{
                        //    Radiofemale.Checked = true;
                        //}
                        //else
                        //{
                        //    Radioothers.Checked = true;
                        //}
                        DateTime dob = Convert.ToDateTime(ds1.Tables["edit"].Rows[i].ItemArray[11]);
                        txtdob.Text = dob.ToString("d");
                        txtcity.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[12]);
                        txtdist.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[13]);
                        txtpincode.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[14]);
                        txtmobile.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[15]);
                        txtadhar.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[16]);
                        ddldoc.SelectedItem.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[17]);
                        ddldept.SelectedItem.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[18]);
                        txtreferal.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[19]);
                        txtremark.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[20]);
                        ddlstate.SelectedItem.Text = Convert.ToString(ds1.Tables["edit"].Rows[i].ItemArray[21]);

                        // Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Employee-Id Doesnot Exists!!!')</script>");


                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtipno1.Text = "";
                    txtipno.Text = "";
                    txtopno.Text = "";

                    // Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Employee-Id Doesnot Exists!!!')</script>");
                }

            
                }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        GenerateAutoID();
        lbldate.Text = DateTime.Now.ToShortDateString();
        lbltime.Text = DateTime.Now.ToShortTimeString();

        txtopno.Text = "";
        txtipno.Text = "";
        txtipno1.Text = "";
        ddlname.ClearSelection();
        ddlname.SelectedItem.Text = "select";
        txtname.Text = "";
        ddlcareof.ClearSelection();
        ddlcareof.SelectedItem.Text = "select";
        txtcareof.Text = "";
        txtaddress.Text = "";

        txtdist.Text = "";
        txtcity.Text = "";
        txtpincode.Text = "";
        txtdob.Text = "";
        txtmobile.Text = "";
        txtadhar.Text = "";
        ddlbg.ClearSelection();
        ddlbg.SelectedItem.Text = "select";
        txtsex.Text = "";
        txtage.Text = "";
        ddldept.ClearSelection();
        ddldept.SelectedItem.Text = "select";
        ddldoc.ClearSelection();
        ddldoc.SelectedItem.Text = "select";
        txtreferal.Text = "";
        txtremark.Text = "";
        ddlstate.ClearSelection();
        ddlstate.SelectedItem.Text = "select";
        ddlwardtype.ClearSelection();
        ddlwardtype.SelectedItem.Text = "select";
        //ddlwardno.ClearSelection();
        //ddlwardno.SelectedItem.Text = "select";
        ddlwardno.Items.Clear();
        ddlbedno.Items.Clear();
        //ddlbedno.ClearSelection();
        //ddlbedno.SelectedItem.Text = "select";
        ddlscheme.ClearSelection();
        ddlscheme.SelectedItem.Text = "select";
        ddldoc.ClearSelection();
        ddldoc.SelectedItem.Text = "select";
        
        txtbedc.Text = "";
        LinkButton1.Visible = true ;
        txtopno.Enabled = true;
        Panel3.Visible = true;


        txtopno.Enabled = true;
        txtreferal.Enabled = true;
        txtremark.Enabled = true;
        ddlbg.Enabled = true;
        Btnedit.Visible = true;
        btnupdate.Visible = false;
        txtipno.Enabled = true;
        txtipno1.Visible = true;
        btnsearch.Visible = true;
        btnsave.Visible = true;
        Panel2.Enabled = true;
        Panel1.Enabled = true;
        txtbedc.Enabled = true;
        ddlbedno.Enabled = true;
        ddlwardno.Enabled = true;
        ddlwardtype.Enabled = true;
       
    }
    protected void ddlwardtype_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtbedc.Text = ddlwardtype.SelectedValue.ToString();
        string dd;
        c = new connect();
        c.cmd.CommandText = "select distinct wardtype,wardno from ward where wardtype='" + ddlwardtype.SelectedItem.Text + "'";

        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "wards");
        if (ds.Tables["wards"].Rows.Count > 0)
        {
            ddlwardno.Items.Clear();
            ddlwardno.Items.Add("select");



            for (int i = 0; i <= ds.Tables["wards"].Rows.Count - 1; i++)
            {
                dd = Convert.ToString(ds.Tables["wards"].Rows[i].ItemArray[1]);
                ddlwardno.Items.Add(dd);

            }


        }

    }
    protected void ddlwardno_SelectedIndexChanged(object sender, EventArgs e)
    {
        string dd;
        c = new connect();
        // c.cmd.CommandText = "select * from aab where name='" + DropDownList1.SelectedItem.Text + "'";

        c.cmd.CommandText = "select * from ward where wardno='" + ddlwardno.SelectedItem.Text + "'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "wards");
        if (ds.Tables["wards"].Rows.Count > 0)
        {
            ddlbedno.Items.Clear();
            ddlbedno.Items.Add("select");

            for (int i = 0; i <= ds.Tables["wards"].Rows.Count - 1; i++)
            {
                string st;
                st = Convert.ToString(ds.Tables["wards"].Rows[i].ItemArray[4]);
                //MessageBox.Show(st);
                dd = Convert.ToString(ds.Tables["wards"].Rows[i].ItemArray[2]);
                if (st == "Open")
                    ddlbedno.Items.Add(dd);

            }


        }
    }



 
}
