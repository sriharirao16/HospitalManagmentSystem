using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
public partial class _Default : System.Web.UI.Page 
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            String password = txtpassword.Text;
            txtpassword.Attributes.Add("value",password);
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/c_passadmin.aspx");
    }
    protected void btnsub_Click(object sender, EventArgs e)
    {
        if (txtpassword.Text == "")
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Password!!!')</script>");
            //MessageBox.Show("Enter Password");
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select username,password from changepass where username='" + txtuser.Text + "'" + "and password='" + txtpassword.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "ad");
                if (ds.Tables["ad"].Rows.Count > 0)
                {
                    //MessageBox.Show("Welcome....You are succesfully logged in..");
                    Response.Redirect("~/admgirst.aspx");
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Incorrect Password!!!')</script>");
                    //MessageBox.Show("incorrect password");
                    txtpassword.Text = "";
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
    }
    protected void txtpassword_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/first.aspx");
    }
    protected void checkshowpass_CheckedChanged(object sender, EventArgs e)
    {
        if (checkshowpass.Checked == false)
            txtpassword.TextMode = TextBoxMode.Password;
        if (checkshowpass.Checked == true )
            txtpassword.TextMode = TextBoxMode.SingleLine;
    }
}
