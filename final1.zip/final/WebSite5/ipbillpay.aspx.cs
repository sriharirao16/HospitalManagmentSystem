using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class ipbillpay : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtdate.Enabled = false;
        txtage.Enabled = false;
        txtadd.Enabled = false;
        txtname.Enabled = false;
        txtsex.Enabled = false;

        btndis.Visible = false;


    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
                        c = new connect();
                        c.cmd.CommandText = "select * from ipbill where ipno='" +txtipid .Text  + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "bill");
                        if (ds.Tables["bill"].Rows.Count > 0)
                        {
                            btndis.Visible = true;
                            for (int i = 0; i <= ds.Tables["bill"].Rows.Count - 1; i++)
                            {
                                txtname.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[4]);
                                DateTime dt = Convert.ToDateTime(ds.Tables["bill"].Rows[i].ItemArray[3]);
                                txtdate.Text = dt.ToString("d");
                                txtadd.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[7]);
                                txtage.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[5]);
                                txtsex.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[6]);
                                Session["bn"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[13]);

                            }
                        }
                        else
                        {
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Ip no. Doesnot Found in IpBill!!!')</script>");
                            //MessageBox.Show("IP no.doesnot  found in IPbill");
                            txtsex.Text = "";
                            txtname.Text = "";
                            txtipid.Text = "";
                            txtdate.Text = "";
                            txtage.Text = "";
                            txtadd.Text = "";

                        }


                                
    }
    protected void btndis_Click(object sender, EventArgs e)
    {
        try
        {

            c = new connect();
            c.cmd.CommandText = "select * from ipreg where status='book'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "bill");
            if (ds.Tables["bill"].Rows.Count > 0)
            {
                string bedno = (String)Session["bn"];
                 // MessageBox.Show(bedno);

                c = new connect();
                c.cmd.CommandText = "update ward set status1=@status1 where bedno='" + bedno +"'";
                c.cmd.Parameters.Clear();
                c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Open";
                c.cmd.ExecuteNonQuery();

           
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
}
