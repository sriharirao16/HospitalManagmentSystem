using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class inactivehr : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
   


    protected void Page_Load(object sender, EventArgs e)
    {
        MaintainScrollPositionOnPostBack = true;
        txtid.Focus();

    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        c = new connect();

        try
        {
            c = new connect();
            if (txtid.Text == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Hr Id To Inactive!!!')</script>");
                //MessageBox.Show("Enter Hr-Id to Inactivate!!!");
            }
            else
            {


                c.cmd.CommandText = "select * from hrreg where hrid='" + txtid.Text + "'and status='Inactive'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "hr");
                if (ds.Tables["hr"].Rows.Count > 0)
                {
                    txtid.Text = "";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Employee Id Already Inactived!!!')</script>");
                    //MessageBox.Show("empployee already Inactive");

                }
                else
                {




                    c.cmd.CommandText = "select * from hrreg where hrid='" + txtid.Text + "'and status='active'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "hr");
                    if (ds.Tables["hr"].Rows.Count > 0)
                    {
                        c.cmd.CommandText = "update hrreg set status=@status where hrid='" + txtid.Text + "'";
                        c.cmd.Parameters.Add("@status", SqlDbType.VarChar).Value = "Inactive";
                        c.cmd.ExecuteNonQuery();
                        c.cmd.CommandText = "update hrlogin set status1=@status1 where hrid='" + txtid.Text + "'";
                        c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Inactive";
                        c.cmd.ExecuteNonQuery();
                        txtid.Text = "";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Hr Id Is Inactived!!!')</script>");
                        //MessageBox.Show("HR-Id is Inactivated");

                        //for (int i = 0; i <= ds.Tables["u"].Rows.Count - 1; i++)
                        //{
                        //    c.cmd.CommandText = "update hrlogin set status1=@status1 where hrid='" + txtid.Text + "'";
                        //    c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Inactive";
                        //    c.cmd.ExecuteNonQuery();
                        //    txtid.Text = "";
                        //}


                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Employee Id Does Not Exist!!!')</script>");
                        //MessageBox.Show("Employee-Id doesnot exist");
                        txtid.Text = "";
                    }
                }
             
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }

    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        txtid.Text = "";
    }
}
