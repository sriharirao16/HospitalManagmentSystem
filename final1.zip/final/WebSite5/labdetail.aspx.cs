using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class labdetail : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
 

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GenerateAutoID();
        }
        DateTime today = DateTime.Now;
        Txttdate.Text = today.ToString("d");
        
    }
    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(slno)from labdetails ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        Label1.Text = i.ToString();

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ddltype.SelectedItem.Text == "-----select------" || ddltestname.SelectedItem.Text == "SELECT")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select DDl!!!')</script>");
            //MessageBox.Show("select ddl");

        }
        else
        {       c = new connect();
                c.cmd.CommandText = "select * from labdetails where pid='" + txtpid.Text + "' and date='"+Txttdate .Text +"'and test='"+ddltestname .SelectedItem .Text +"'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "lab");
                if (ds.Tables["lab"].Rows.Count > 0)
                {
                    //MessageBox.Show("record already there");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already There!!!')</script>");
                    txtage.Text = "";
                    txtcharge.Text = "";
                    txtname.Text = "";
                    txtphno.Text = "";
                    txtpid.Text = "";
                    txtsex.Text = "";
                    Txttdate.Text = "";
                    ddltestname.ClearSelection();
                    ddltestname.SelectedItem.Text = "select";

                    ddltype.ClearSelection();
                    ddltype.SelectedItem.Text = "-----select------";



                }

                else
                {

                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into labdetails values(@slno,@tdate,@ptype,@pid,@name,@sex,@age,@mbl,@test,@charge,@result,@status)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@slno", SqlDbType.NVarChar).Value = Label1.Text;
                        c.cmd.Parameters.Add("@tdate", SqlDbType.DateTime).Value = Txttdate.Text;
                        c.cmd.Parameters.Add("@ptype", SqlDbType.NVarChar).Value = ddltype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@pid", SqlDbType.NVarChar).Value = txtpid.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = txtsex.Text;
                        c.cmd.Parameters.Add("@age", SqlDbType.NVarChar).Value = txtage.Text;
                        c.cmd.Parameters.Add("@mbl", SqlDbType.Decimal).Value = Convert.ToDecimal(txtphno.Text);
                        c.cmd.Parameters.Add("@test", SqlDbType.NVarChar).Value = ddltestname.SelectedItem.Text;
                        c.cmd.Parameters.Add("@charge", SqlDbType.Decimal).Value = Convert.ToDecimal(txtcharge.Text);
                        c.cmd.Parameters.Add("@result", SqlDbType.NVarChar).Value = "pen";
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "reg";
                        c.cmd.ExecuteNonQuery();
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Saved!!!')</script>");
                        //MessageBox.Show("saved");
                        btnsave.Visible = false;
                        GridView1.Visible = true ;

                c = new connect();
                c.cmd.CommandText = "select date,pid,name,sex,age,mbl,test from labdetails where pid='" + txtpid.Text + "' and date='"+Txttdate .Text +"'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "lab");
                if (ds.Tables["lab"].Rows.Count > 0)
                {
                    GridView2.Visible = true ;
                    GridView2.DataSource = ds.Tables["lab"];
                    GridView2.DataBind();
                }
                        txtage.Text = "";
                        txtcharge.Text = "";
                        txtname.Text = "";
                        txtphno.Text = "";
                        txtpid.Text = "";
                        txtsex.Text = "";
                        Txttdate.Text = "";
                        ddltestname.ClearSelection();
                        ddltestname.SelectedItem.Text = "select";

                        ddltype.ClearSelection();
                        ddltype.SelectedItem.Text = "-----select------";


                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }

        }


    }
    protected void Btnnew_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        txted.Visible = false;
        LinkButton2.Visible = false;

        txtage.Text = "";
        txtcharge.Text = "";
        txtname.Text = "";
        txtphno.Text = "";
        txtpid.Text = "";
        txtsex.Text = "";
        Txttdate.Text = "";
        ddltestname.ClearSelection();
        ddltestname.SelectedItem.Text = "select";
        
        ddltype.ClearSelection();
        ddltype.SelectedItem.Text = "-----select------";

        GenerateAutoID();
        btnsave.Visible = false;
        GridView1.Visible = false;
        GridView2.Visible = false;
        Panel2.Visible = false;

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        btnsave.Visible = false;
        GridView1.Visible = false;
        if (ddltype.SelectedItem.Text == "-----select------" || txtpid.Text == "")
        {
            //MessageBox.Show("Plz...check patient id or patye not selected");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Plz..check the Patient Id Or Patient Type Does not Select!!!')</script>");
            txtage.Text = "";
            txtcharge.Text = "";
            txtname.Text = "";
            txtphno.Text = "";
            txtpid.Text = "";
            txtsex.Text = "";
            Txttdate.Text = "";
            ddltestname.ClearSelection();
            ddltestname.SelectedItem.Text = "select";

            ddltype.ClearSelection();
            ddltype.SelectedItem.Text = "-----select------";

        }
        else if (ddltype.SelectedItem.Text == "IP")
        {

            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from ipbill where ipno='" + txtpid.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "lab");
                if (ds.Tables["lab"].Rows.Count > 0)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Patient Already Bill Paid!!!')</script>");
                    //MessageBox.Show("The patient already Bill Paid ");
                    ddltype.ClearSelection();
                    ddltype.SelectedItem.Text = "-----select------";
                    txtpid.Text = "";
                 


                }
                else
                {






                    c = new connect();
                    c.cmd.CommandText = "select * from ipreg where ipno='" + txtpid.Text + "'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "lab");
                    if (ds.Tables["lab"].Rows.Count > 0)
                    {
                        for (int i = 0; i <= ds.Tables["lab"].Rows.Count - 1; i++)
                        {
                            txtname.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[5]);
                            txtsex.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[17]);
                            txtage.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[18]);
                            txtphno.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[14]);
                            btnsave.Visible = true;

                        }
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                        //MessageBox.Show("record not found");
                        txtage.Text = "";
                        txtcharge.Text = "";
                        txtname.Text = "";
                        txtphno.Text = "";
                        txtpid.Text = "";
                        txtsex.Text = "";
                        Txttdate.Text = "";
                        ddltestname.ClearSelection();
                        ddltestname.SelectedItem.Text = "select";

                        ddltype.ClearSelection();
                        ddltype.SelectedItem.Text = "-----select------";

                    }
                }


            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
        else
        {
            

                c = new connect();
                c.cmd.CommandText = "select * from ipreg where opno='" + txtpid.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "lab");
                if (ds.Tables["lab"].Rows.Count > 0)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Plz..select Ip and Ipid!!!')</script>");
                    //MessageBox.Show("plz...slect ip and ipid");
                    txtage.Text = "";
                    txtcharge.Text = "";
                    txtname.Text = "";
                    txtphno.Text = "";
                    txtpid.Text = "";
                    txtsex.Text = "";
                    Txttdate.Text = "";
                    ddltestname.ClearSelection();
                    ddltestname.SelectedItem.Text = "select";

                    ddltype.ClearSelection();
                    ddltype.SelectedItem.Text = "-----select------";


                }

                else
                {


                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "select * from opreg where opno='" + txtpid.Text + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "lab");
                        if (ds.Tables["lab"].Rows.Count > 0)
                        {
                            for (int i = 0; i <= ds.Tables["lab"].Rows.Count - 1; i++)
                            {
                                
                                txtname.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[4]);
                                txtsex.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[10]);
                                txtage.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[9]);
                                txtphno.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[15]);
                                btnsave.Visible = true;
                            }
                        }
                        else
                        {
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                            //MessageBox.Show("record not found");
                            txtage.Text = "";
                            txtcharge.Text = "";
                            txtname.Text = "";
                            txtphno.Text = "";
                            txtpid.Text = "";
                            txtsex.Text = "";
                            Txttdate.Text = "";
                            ddltestname.ClearSelection();
                            ddltestname.SelectedItem.Text = "select";

                            ddltype.ClearSelection();
                            ddltype.SelectedItem.Text = "-----select------";

                        }

                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }

        }
     

    }
    protected void ddltestname_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtcharge.Text = ddltestname.SelectedValue.ToString();
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        if (txted.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Pid!!!')</script>");
            //MessageBox.Show("enter pid");
        }
    
        //DateTime tday = DateTime.Now;
        //String td = tday.ToString("d");

        //try
        //{

        //    c = new connect();
        //    c.cmd.CommandText = "select * from labdetails where pid='" + txted .Text  + "'and date='"+td+"'" ;
        //    ds = new DataSet();
        //    adp.SelectCommand = c.cmd;
        //    adp.Fill(ds, "lab");
        //    if (ds.Tables["lab"].Rows.Count > 0)
        //    {
        //        GridView1.Visible = true;
        //        GridView1.DataSource = ds.Tables["lab"];
        //        GridView1.DataBind();

        //        //for (int i = 0; i <= ds.Tables["lab"].Rows.Count - 1; i++)
        //        //{
        //        //    txtname.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[5]);
        //        //    txtsex.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[17]);
        //        //    txtage.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[18]);
        //        //    txtphno.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[14]);
        //        //    btnsave.Visible = true;

        //        //}
        //    }
        //    else
        //    {
        //        MessageBox.Show("record not found");
        //        txtage.Text = "";
        //        txtcharge.Text = "";
        //        txtname.Text = "";
        //        txtphno.Text = "";
        //        txtpid.Text = "";
        //        txtsex.Text = "";
        //        Txttdate.Text = "";
        //        ddltestname.ClearSelection();
        //        ddltestname.SelectedItem.Text = "select";

        //        ddltype.ClearSelection();
        //        ddltype.SelectedItem.Text = "-----select------";

        //    }

        //}
        //catch (Exception)
        //{
        //    throw;
        //}
        //finally
        //{
        //    c.cnn.Close();
        //}
        





    }
    protected void btned_Click(object sender, EventArgs e)
    {
        txted.Visible = true;
        LinkButton2.Visible = true;
        
        Panel1.Visible = false;
        Panel2.Visible = true;

    }
  
    protected void GridView1_RowUpdated1(object sender, GridViewUpdatedEventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Row Updated!!!')</script>");
        //MessageBox.Show("row updated ");
        GridView1.DataBind();
    }
}
