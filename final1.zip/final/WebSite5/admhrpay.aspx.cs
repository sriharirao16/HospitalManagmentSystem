using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class admhrpay : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "select" || DropDownList2.SelectedItem.Text == "select" || DropDownList3.SelectedItem.Text == "select")
        {
            //MessageBox.Show("select First");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select First!!!')</script>");
               
        }
        else
        {

            c = new connect();
            c.cmd.CommandText = "select * from hrpayslip where year='" + DropDownList2.SelectedItem.Text + "' and  month(date)='" + DropDownList1.SelectedValue.ToString() + "'and name='" + DropDownList3.SelectedItem.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;

            adp.Fill(ds, "emp");
            if (ds.Tables["emp"].Rows.Count > 0)
            {
                Panel1.Visible = true;

                for (int i = 0; i <= ds.Tables["emp"].Rows.Count - 1; i++)
                {

                    txtipid.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[1]);
                    DateTime dt = Convert.ToDateTime(ds.Tables["emp"].Rows[i].ItemArray[8]);
                    txtdate.Text = dt.ToShortDateString();
                    txtdes.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[3]);
                    txtsal.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[15]);
                    txtadrs.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[6]);
                    txtplid.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[0]);



                }


            }
        }

    }
    protected void btndis_Click(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string dd;
        //c = new connect();
        //c.cmd.CommandText = "select distinct year,date from hrpayslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "'";

        //ds = new DataSet();
        //adp.SelectCommand = c.cmd;
        //adp.Fill(ds, "emp");
        //if (ds.Tables["emp"].Rows.Count > 0)
        //{
        //    DropDownList2.Items.Clear();
        //    DropDownList2.Items.Add("select");

        //    for (int i = 0; i <= ds.Tables["emp"].Rows.Count - 1; i++)
        //    {
        //        dd = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[0]);
        //        DropDownList2.Items.Add(dd);

        //    }
        //}
    }
  
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        txtadrs.Text = "";
        txtdate.Text = "";
        txtdes.Text = "";
        txtipid.Text = "";
        txtplid.Text = "";
        txtsal.Text = "";
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "select";
        DropDownList2.ClearSelection();
        DropDownList2.SelectedItem.Text = "select";
        DropDownList3.Items.Clear();
        DropDownList3.Items.Add("select");
    }
    protected void DropDownList2_SelectedIndexChanged1(object sender, EventArgs e)
    {

        string dd;
        c = new connect();
        c.cmd.CommandText = "select * from hrpayslip where year='" + DropDownList2.SelectedItem .Text  + "' and  month(date)='" + DropDownList1.SelectedValue.ToString() + "'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "emp");
        if (ds.Tables["emp"].Rows.Count > 0)
        {
            DropDownList3.Items.Clear();
            DropDownList3.Items.Add("select");

            for (int i = 0; i <= ds.Tables["emp"].Rows.Count - 1; i++)
            {

                dd = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[2]);
                DropDownList3.Items.Add(dd);


            }


        }

    }
}
