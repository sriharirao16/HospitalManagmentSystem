using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class hrdocd : System.Web.UI.Page
{

    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {
       

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtempid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('enter  emp id first')</script>");

            //MessageBox.Show("enter  emp id first");
        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from empreg where empid='" + txtempid.Text + "'and status='active'and emptype='Doctor' ";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    LinkButton1.Visible = false;
                    LinkButton2.Visible = true;
                    Label1.Visible = true;
                    txtempid.Enabled = false;

                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                        txttype.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                        txtadd.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);
                        txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);
                        txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                        txtmbl.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                        txtms.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                        txtsex.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                        
                        
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('record not found')</script>");

                    //MessageBox.Show("record not found");
                    txtadd.Text = "";
                    txtadhar.Text = "";
                    txtage.Text = "";
                    txtmbl.Text = "";
                    txtms.Text = "";
                    txtname.Text = "";
                    txtsex.Text = "";
                    txttype.Text = "";
                    txtempid.Text = "";

                }

            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        if (txtempid.Text == "")
        {
            //MessageBox.Show("enter  emp id first");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('enter  emp id first')</script>");

        }
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select care,dob,city,doj,email,bloodgrp,basic  from empreg where  status='active' and emptype='Doctor' and empid='" + txtempid.Text + "'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "emp");

                if (ds.Tables["emp"].Rows.Count >= 0)
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = ds.Tables["emp"];
                    GridView1.DataBind();

                }
                else
                {
                    GridView1.Visible = false;
                    //MessageBox.Show("check emp id");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('check emp id')</script>");


                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        txtadd.Text = "";
        txtadhar.Text = "";
        txtage.Text = "";
        txtempid.Text = "";
        txtmbl.Text = "";
        txtms.Text = "";
        txtname.Text = "";
        txtsex.Text = "";
        txttype.Text = "";
        GridView1.Visible = false;
        LinkButton1.Visible = true;
        txtempid.Enabled = true;
        LinkButton2.Visible = false;
        Label1.Visible = false;

    }
}
