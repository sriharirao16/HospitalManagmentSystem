using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

public partial class rwarddis : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();


    protected void Page_Load(object sender, EventArgs e)
    {
        GridView1.CellPadding = 10;
        // GridView1.CellSpacing = 50;

    }
    protected void display_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "General")
        {
            GridView1.Visible = true;


            try
            {
                c = new connect();
                c.cmd.CommandText = "select * from ward where wardtype='General'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "ward");

                if (ds.Tables["ward"].Rows.Count >= 0)
                {

                    GridView1.DataSource = ds.Tables["ward"];
                    GridView1.DataBind();

                    for (int i = 0; i < GridView1.Rows.Count; i++)
                    {
                        if (GridView1.Rows[i].Cells[4].Text == "Open")
                        {
                            //   GridView1.Rows[i].Cells[4].ForeColor = Color.Blue    ;
                            GridView1.Rows[i].Cells[4].BackColor = Color.Green;
                            GridView1.Rows[i].ForeColor = Color.Blue;
                        }

                        else
                        {
                            GridView1.Rows[i].Cells[4].BackColor = Color.Red;
                            GridView1.Rows[i].ForeColor = Color.Maroon;

                            // GridView1.Rows[i].Cells[2 ].ForeColor = Color.Red;

                            // Response.Write(GridView1.Rows[i].Cells[4].Text);

                        }
                    }
                }
                else
                {
                    GridView1.Visible = false;

                    //MessageBox.Show("wrong");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Wrong!!!')</script>");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }



        }

        else if (DropDownList1.SelectedItem.Text == "SemiSpecial Ward")
        {
            GridView1.Visible = true;


            try
            {
                c = new connect();
                c.cmd.CommandText = "select * from ward where wardtype='SemiSpecial Ward'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "semi");

                if (ds.Tables["semi"].Rows.Count >= 0)
                {

                    GridView1.DataSource = ds.Tables["semi"];
                    GridView1.DataBind();
                    for (int i = 0; i < GridView1.Rows.Count; i++)
                    {
                        if (GridView1.Rows[i].Cells[4].Text == "Open")
                        {
                            GridView1.Rows[i].Cells[4].BackColor = Color.Green;
                            GridView1.Rows[i].ForeColor = Color.Blue;
                        }

                        else
                        {
                            GridView1.Rows[i].Cells[4].BackColor = Color.Red;
                            GridView1.Rows[i].ForeColor = Color.Maroon;
                        }
                    }
                }
                else
                {
                    GridView1.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Wrong!!!')</script>");
                    //MessageBox.Show("wrong");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }



        }

        else if (DropDownList1.SelectedItem.Text == "SpecialWard")
        {
            GridView1.Visible = true;


            try
            {
                c = new connect();
                c.cmd.CommandText = "select * from ward where wardtype='SpecialWard'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "semi");

                if (ds.Tables["semi"].Rows.Count >= 0)
                {

                    GridView1.DataSource = ds.Tables["semi"];
                    GridView1.DataBind();
                    for (int i = 0; i < GridView1.Rows.Count; i++)
                    {
                        if (GridView1.Rows[i].Cells[4].Text == "Open")
                        {
                            GridView1.Rows[i].Cells[4].BackColor = Color.Green;
                            GridView1.Rows[i].ForeColor = Color.Blue;
                        }

                        else
                        {
                            GridView1.Rows[i].Cells[4].BackColor = Color.Red;
                            GridView1.Rows[i].ForeColor = Color.Maroon;
                        }
                    }
                }
                else
                {
                    GridView1.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Wrong!!!')</script>");
                    //MessageBox.Show("wrong");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }



        }
        else
        {
            GridView1.Visible = false;
            //MessageBox.Show("select first");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select First!!!')</script>");
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
