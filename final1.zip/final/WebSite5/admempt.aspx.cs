using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class admempt : System.Web.UI.Page
{

    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime da = DateTime.Now;
            string d = da.ToString("d");
            Label1.Text = d;




            c = new connect();
            c.cmd.CommandText = "select empid,emptype,name,address,age,sex,mob,adhar from empreg where doj='" + d + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "pdate");
            if (ds.Tables["pdate"].Rows.Count > 0)
            {
                c.cmd.CommandText = "select count(empid)from empreg where doj='" + d + "'";
                int doj = Convert.ToInt16(c.cmd.ExecuteScalar());
                Label2.Text = doj.ToString();
                GridView1.DataSource = ds.Tables["pdate"];
                GridView1.DataBind();

                //c = new connect();

                //c.cmd.CommandText = "select count(name)from empreg ";


                //int ii = Convert.ToInt32(c.cmd.ExecuteScalar());
                //c.cnn.Close();
                //Label2.Text = ii.ToString();
                


            }
            else
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('todays no record')</script>");
            //MessageBox.Show("todays no record");
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }


    }
   
}
