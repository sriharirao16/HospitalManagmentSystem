using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class bedshift : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        DateTime dt = DateTime.Now.Date;
        Label1.Text = dt.ToShortDateString();
    }
    protected void ddlwardtype_SelectedIndexChanged(object sender, EventArgs e)
    {

        txtbedcharge .Text  = ddlwardtype.SelectedValue.ToString();
        string dd;
        c = new connect();
        c.cmd.CommandText = "select distinct wardtype,wardno from ward where wardtype='" + ddlwardtype.SelectedItem.Text + "'";

        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "wards");
        if (ds.Tables["wards"].Rows.Count > 0)
        {
            ddlwardno.Items.Clear();
            ddlwardno.Items.Add("select");

            for (int i = 0; i <= ds.Tables["wards"].Rows.Count - 1; i++)
            {
                dd = Convert.ToString(ds.Tables["wards"].Rows[i].ItemArray[1]);
                ddlwardno.Items.Add(dd);

            }
        }
}
    protected void ddlwardno_SelectedIndexChanged(object sender, EventArgs e)
    {
        string dd;
        c = new connect();
        // c.cmd.CommandText = "select * from aab where name='" + DropDownList1.SelectedItem.Text + "'";

        c.cmd.CommandText = "select * from ward where wardno='" + ddlwardno.SelectedItem.Text + "'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "wards");
        if (ds.Tables["wards"].Rows.Count > 0)
        {
            ddlbedno.Items.Clear();
            ddlbedno.Items.Add("select");

            for (int i = 0; i <= ds.Tables["wards"].Rows.Count - 1; i++)
            {
                string st;
                st = Convert.ToString(ds.Tables["wards"].Rows[i].ItemArray[4]);
                //MessageBox.Show(st);
                dd = Convert.ToString(ds.Tables["wards"].Rows[i].ItemArray[2]);
                if (st == "Open")
                    ddlbedno.Items.Add(dd);

            }


        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtipno.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Ip No')</script>");

        }
        else
        {
             c = new connect();
                c.cmd.CommandText = "select * from ipbill where ipno='" + txtipno.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "bed");
                if (ds.Tables["bed"].Rows.Count > 0)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Already Bill is Paid ')</script>");
                    txtipno.Text = "";
                    txtipno.Focus();
                }
                else
                {

                    try
                    {
                        c = new connect();
                        c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "bed");
                        if (ds.Tables["bed"].Rows.Count > 0)
                        {
                            txtipno.Enabled = false ;
                            LinkButton1.Visible = false;
                            Panel1.Visible = true;
                            for (int i = 0; i <= ds.Tables["bed"].Rows.Count - 1; i++)
                            {
                                txtname.Text = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[5]);
                                txtcare.Text = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[7]);
                                txtaddress.Text = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[8]);
                                txtward.Text = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[23]);
                                txtwardno.Text = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[24]);
                                txtbedno.Text = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[25]);
                            }
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }

        }




        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        txtipno.Text = "";
        txtipno.Focus();
        txtname.Text = "";
        txtward.Text = "";
        txtwardno.Text = "";
        txtcare.Text = "";
        txtaddress.Text = "";
        txtbedno.Text = "";
        txtbedcharge.Text = "";
        ddlbedno.Items.Clear();
        ddlbedno.Items.Add("select");
        ddlwardtype.ClearSelection();
        ddlwardtype.SelectedItem.Text = "select";
        ddlwardno.Items.Clear();
        ddlwardno.Items.Add("select");
        txtipno.Enabled = true;
        LinkButton1.Visible = true ;
        Panel1.Visible = false;
        
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (txtipno.Text == "" || txtname.Text == "" || ddlbedno.SelectedItem.Text == "select" || ddlwardtype.SelectedItem.Text == "select" || ddlwardno.SelectedItem.Text == "select")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Check All Fields  ')</script>");
        }
        else
        {

            c = new connect();
            c.cmd.CommandText = "select * from bedcharges where ipno='" + txtipno.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "bed");
            if (ds.Tables["bed"].Rows.Count > 0)
            {


                c = new connect();
                c.cmd.CommandText = "select * from bedshift where ipno='" + txtipno.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "bed");
                if (ds.Tables["bed"].Rows.Count > 0)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Already done ')</script>");
                    txtipno.Text = "";
                    txtipno.Focus();
                    txtname.Text = "";
                    txtward.Text = "";
                    txtwardno.Text = "";
                    txtcare.Text = "";
                    txtaddress.Text = "";
                    txtbedno.Text = "";
                    txtbedcharge.Text = "";
                    ddlbedno.Items.Clear();
                    ddlbedno.Items.Add("select");
                    ddlwardtype.ClearSelection();
                    ddlwardtype.SelectedItem.Text = "select";
                    ddlwardno.Items.Clear();
                    ddlwardno.Items.Add("select");
                    txtipno.Enabled = true;
                    LinkButton1.Visible = true;
                    Panel1.Visible = false;
                }

                else
                {
                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into bedshift values(@ipno,@ipname,@wt,@wn,@bn,@bcharge,@adate,@edate,@totdays,@tot)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@ipno", SqlDbType.NVarChar).Value = txtipno.Text;
                        c.cmd.Parameters.Add("@ipname", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@wt", SqlDbType.NVarChar).Value = ddlwardtype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@wn", SqlDbType.NVarChar).Value = ddlwardno.SelectedItem.Text;
                        c.cmd.Parameters.Add("@bn", SqlDbType.NVarChar).Value = ddlbedno.SelectedItem.Text;
                        c.cmd.Parameters.Add("@bcharge", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbedcharge.Text);
                        c.cmd.Parameters.Add("@adate", SqlDbType.DateTime).Value = Label1.Text;
                        c.cmd.Parameters.Add("@edate", SqlDbType.DateTime).Value = Label1.Text;
                        c.cmd.Parameters.Add("@totdays", SqlDbType.Decimal).Value = 0.0;
                        c.cmd.Parameters.Add("@tot", SqlDbType.Decimal).Value = 0.0;                       
                        c.cmd.ExecuteNonQuery();
                       
                        c = new connect();
                        c.cmd.CommandText = "update ipreg set wardtype=@wardtype,wardno=@wardno,bedno=@bedno,bedcharge=@bedcharge where ipno='" + txtipno.Text + "'";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@wardtype", SqlDbType.NVarChar).Value = ddlwardtype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@wardno", SqlDbType.NVarChar).Value = ddlwardno.SelectedItem.Text;
                        c.cmd.Parameters.Add("@bedno", SqlDbType.NVarChar).Value = ddlbedno.SelectedItem.Text;
                        c.cmd.Parameters.Add("@bedcharge", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbedcharge.Text);
                        c.cmd.ExecuteNonQuery();
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved ')</script>");

                        txtipno.Text = "";
                        txtipno.Focus();
                        txtname.Text = "";
                        txtward.Text = "";
                        txtwardno.Text = "";
                        txtcare.Text = "";
                        txtaddress.Text = "";
                        txtbedno.Text = "";
                        txtbedcharge.Text = "";
                        ddlbedno.Items.Clear();
                        ddlbedno.Items.Add("select");
                        ddlwardtype.ClearSelection();
                        ddlwardtype.SelectedItem.Text = "select";
                        ddlwardno.Items.Clear();
                        ddlwardno.Items.Add("select");
                        txtipno.Enabled = true;
                        LinkButton1.Visible = true;
                        Panel1.Visible = false;
        

                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('First Fill The Bedcharge')</script>");

                txtipno.Text = "";
                txtipno.Focus();
                txtname.Text = "";
                txtward.Text = "";
                txtwardno.Text = "";
                txtcare.Text = "";
                txtaddress.Text = "";
                txtbedno.Text = "";
                txtbedcharge.Text = "";
                ddlbedno.Items.Clear();
                ddlbedno.Items.Add("select");
                ddlwardtype.ClearSelection();
                ddlwardtype.SelectedItem.Text = "select";
                ddlwardno.Items.Clear();
                ddlwardno.Items.Add("select");
                txtipno.Enabled = true;
                LinkButton1.Visible = true;
                Panel1.Visible = false;
            }

        }

    }
}
