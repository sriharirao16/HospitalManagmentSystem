using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class hracsal : System.Web.UI.Page
{
    connect c, d, g, f;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    double tot=0, k=0, l=0, m=0,n=0,i=0,j=0;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {



        if (DropDownList1.SelectedItem.Text == "select" || DropDownList2.SelectedItem.Text == "select")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select First!!!')</script>");
        }
        else
        {
            c = new connect();
            c.cmd.CommandText = "select * from payslip where year(date)='" + DropDownList2.SelectedItem.Text + "' and  month(date)='" + DropDownList1.SelectedValue.ToString() + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;

            adp.Fill(ds, "ac");
            if (ds.Tables["ac"].Rows.Count > 0)
            {
                Panel1.Visible = true;
                LinkButton3.Visible = false;
                DropDownList1.Enabled = false;
                DropDownList2.Enabled = false;


                c = new connect();
                c.cmd.CommandText = "select * from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='doctor'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "e");
                if (ds.Tables["e"].Rows.Count > 0)
                {
                    c.cmd.CommandText = "select sum(totalsalary)from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='doctor'";
                    i = Convert.ToDouble(c.cmd.ExecuteScalar());
                    c.cnn.Close();
                    Label1.Text = i.ToString();
                }


                d = new connect();
                d.cmd.CommandText = "select * from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Reception'";
                ds = new DataSet();
                adp.SelectCommand = d.cmd;
                adp.Fill(ds, "e");
                if (ds.Tables["e"].Rows.Count > 0)
                {
                    d.cmd.CommandText = "select sum(totalsalary)from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Reception'";
                    k = Convert.ToDouble(d.cmd.ExecuteScalar());
                    Label2.Text = k.ToString();

                }

                g = new connect();
                g.cmd.CommandText = "select * from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Lab'";
                ds = new DataSet();
                adp.SelectCommand = g.cmd;
                adp.Fill(ds, "e");
                if (ds.Tables["e"].Rows.Count > 0)
                {


                    g.cmd.CommandText = "select sum(totalsalary)from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Lab'";
                    l = Convert.ToDouble(g.cmd.ExecuteScalar());
                    Label3.Text = l.ToString();

                }
                f = new connect();
                f.cmd.CommandText = "select * from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Nurse'";
                ds = new DataSet();
                adp.SelectCommand = f.cmd;
                adp.Fill(ds, "e");
                if (ds.Tables["e"].Rows.Count > 0)
                {

                    f.cmd.CommandText = "select sum(totalsalary)from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Nurse'";
                    m = Convert.ToDouble(f.cmd.ExecuteScalar());
                    Label4.Text = m.ToString();


                }

                f = new connect();
                f.cmd.CommandText = "select * from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Others'";
                ds = new DataSet();
                adp.SelectCommand = f.cmd;
                adp.Fill(ds, "e");
                if (ds.Tables["e"].Rows.Count > 0)
                {

                    f.cmd.CommandText = "select sum(totalsalary)from payslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='Others'";
                    n = Convert.ToDouble(f.cmd.ExecuteScalar());
                    Label6.Text = n.ToString();


                }

                f = new connect();
                f.cmd.CommandText = "select * from hrpayslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='hr'";
                ds = new DataSet();
                adp.SelectCommand = f.cmd;
                adp.Fill(ds, "e");
                if (ds.Tables["e"].Rows.Count > 0)
                {

                    f.cmd.CommandText = "select sum(totalsalary)from hrpayslip where month(date)='" + DropDownList1.SelectedValue.ToString() + "' and year(date)='" + DropDownList2.SelectedItem.Text + "'and desig='hr'";
                    j  = Convert.ToDouble(f.cmd.ExecuteScalar());
                    Label7.Text = j.ToString();


                }
                double total = i+j + k + l + m + n;
                Label5.Text = total.ToString();

            }

            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Record Not Found!!!')</script>");

            }
        }





    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        Panel1.Visible = false;
       
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "select";
        DropDownList2.ClearSelection();
        DropDownList2.SelectedItem.Text = "select";
        Label1.Text = "-";
        Label2.Text = "-";
        Label3.Text = "-";
        Label4.Text = "-";
        Label5.Text = "-";
        Label6.Text = "-";
        Label7.Text = "-";

        LinkButton3.Visible = true  ;
        DropDownList1.Enabled = true ;
        DropDownList2.Enabled = true ;
    }
}
