using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class labrep : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtpid.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Pid!!!')</script>");
            //MessageBox.Show("plz...enter pid");
            Panel1.Visible = false;
            GridView2.Visible = false ;

        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from labdetails where pid='" + txtpid.Text + "'and result='pen'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "lab");
                if (ds.Tables["lab"].Rows.Count > 0)
                {
                    btnsave.Visible = true;
                    LinkButton1.Visible = false;
                    Panel1.Visible = true;
                    txtresult.Enabled = true;
                    txtresult.Text = "";
                    GridView2.Visible = false ;
                    for (int i = 0; i <= ds.Tables["lab"].Rows.Count - 1; i++)
                    {
                        DateTime dt = Convert.ToDateTime(ds.Tables["lab"].Rows[i].ItemArray[1]);
                        Labeltd.Text = dt.ToShortDateString();
                        Labelpt.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[2]);
                        Labeln.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[4]);
                        Labels.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[5]);
                        Labela.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[6]);
                        Labelm.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[7]);
                        Labelt.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[8]);
                        Labelc.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[9]);
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtpid.Text = "";
                    txtresult.Text = "";
                    Panel1.Visible = false;
                    GridView2.Visible = false ;
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
    }
    protected void btnclr_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        txtresult.Enabled = true;
        txtpid.Text = "";
        txtresult.Text = "";
        GridView2.Visible = false ;
        LinkButton1.Visible = true;
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {

            c = new connect();
            c.cmd.CommandText = "update labdetails set result=@result where pid='" + txtpid.Text + "'and test='" + Labelt.Text + "'";
            c.cmd.Parameters.Clear();
            
           c.cmd.Parameters.Add("@result", SqlDbType.NVarChar).Value = txtresult .Text ;
           
            c.cmd.ExecuteNonQuery();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Saved!!!')</script>");
            //MessageBox.Show("saved");
            txtresult.Enabled = false;
            btnsave.Visible = false;
            GridView2.Visible = true;

            c = new connect();
            c.cmd.CommandText = "select date,pid,name,sex,age,mbl,test,result from labdetails where pid='" + txtpid.Text + "' and test='" + Labelt .Text  + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lab");
            if (ds.Tables["lab"].Rows.Count > 0)
            {
                GridView2.Visible = true;
                GridView2.DataSource = ds.Tables["lab"];
                GridView2.DataBind();
            }
           
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
           



    }
}
