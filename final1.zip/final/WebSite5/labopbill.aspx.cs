using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class labopbill : System.Web.UI.Page
{

    connect c,c1;
    DataSet ds,ds1;
    SqlDataAdapter adp = new SqlDataAdapter();
      protected void Page_Load(object sender, EventArgs e)
    {
        DateTime today = DateTime.Now;
        Label1.Text = today.ToShortDateString();
        if (!IsPostBack)
        {
            GenerateAutoID();
        }
    }
     private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(billno)from labopb ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        lblb .Text = i.ToString();

}
    protected void LinkButton1_Click(object sender, EventArgs e)
    {       
            //c1 = new connect();
            //c1.cmd.CommandText = "select * from labopb where opno='"+txtpid .Text +"'";
            //ds1 = new DataSet();
            //adp.SelectCommand = c1.cmd; 
            //adp.Fill(ds1, "l");
            //if (ds1.Tables["l"].Rows.Count > 0)
            //{
            //    MessageBox.Show("payment already done");
            //    txtpid.Text = "";
            //    txtpid.Focus();
            //}
            //else
            //{

                try
                {

                    c = new connect();
                    c.cmd.CommandText = "select * from labdetails where pid='" + txtpid.Text + "'and ptype='OP' and status='reg'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "lab");
                    if (ds.Tables["lab"].Rows.Count > 0)
                    {
                        GenerateAutoID();
                        LinkButton1.Visible = false;
                        Panel1.Visible = true;
                        txtpid.Enabled = false;

                        for (int i = 0; i <= ds.Tables["lab"].Rows.Count - 1; i++)
                        {
                            //DateTime da = Convert.ToDateTime(ds.Tables["lab"].Rows[i].ItemArray[1]);
                            //Label1 .Text  = da.ToShortDateString();
                            lbln.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[4]);
                            lbls.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[5]);
                            lblpt.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[2]);
                            lblm.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[7]);
                            lbla.Text = Convert.ToString(ds.Tables["lab"].Rows[i].ItemArray[6]);

                        }
                        c.cmd.CommandText = "select pid,name,test,charge from labdetails where pid='" + txtpid.Text + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "lab");
                        if (ds.Tables["lab"].Rows.Count > 0)
                        {
                            GridView1.Visible = true;
                            GridView1.DataSource = ds.Tables["lab"];
                            GridView1.DataBind();
                        }
                        c = new connect();
                        c.cmd.CommandText = "select sum(charge)from labdetails where  pid='" + txtpid.Text + "'";
                        int j = Convert.ToInt32(c.cmd.ExecuteScalar());
                        c.cnn.Close();
                        txttot.Text = j.ToString();

                    }
                    else
                    {
                        LinkButton1.Visible = true;
                        Panel1.Visible = false;
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Does Not Found!!!')</script>");
                        //MessageBox.Show("record does not found");
                        txtpid.Text = "";


                    }

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
           // }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "-------Select--------")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select Payment Type!!!')</script>");
            //MessageBox.Show("select payment Type");
            DropDownList1.Focus();
        }
        else
        {

            c = new connect();
            c.cmd.CommandText = "select * from labopb where opno='" + txtpid.Text + "' and date='" + Label1.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "lab");
            if (ds.Tables["lab"].Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already There!!!')</script>");
                //MessageBox.Show("record already there");
            }
            else
            {

                c = new connect();
                c.cmd.CommandText = "select * from labdetails where pid='" + txtpid.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "lab");
                if (ds.Tables["lab"].Rows.Count > 0)
                {

                    c = new connect();
                    c.cmd.CommandText = "update labdetails set status=@status where pid='" + txtpid.Text + "'";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "paid";

                    c.cmd.ExecuteNonQuery();



                }


                try
                {
                    c = new connect();
                    c.cmd.CommandText = "insert into labopb values(@date,@opno,@billno,@name,@ptype,@age,@sex,@mbl,@testname,@total,@pay)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = Label1.Text;
                    c.cmd.Parameters.Add("@opno", SqlDbType.NVarChar).Value = txtpid.Text;
                    c.cmd.Parameters.Add("@billno", SqlDbType.Decimal).Value = Convert.ToDecimal(lblb.Text);
                    c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = lbln.Text;
                    c.cmd.Parameters.Add("@ptype", SqlDbType.NVarChar).Value = lblpt.Text;
                    c.cmd.Parameters.Add("@age", SqlDbType.Decimal).Value = Convert.ToDecimal(lbla.Text);
                    c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = lbls.Text;
                    c.cmd.Parameters.Add("@mbl", SqlDbType.Decimal).Value = Convert.ToDecimal(lblm.Text);
                    c.cmd.Parameters.Add("@testname", SqlDbType.NVarChar).Value = "labTest";
                    c.cmd.Parameters.Add("@total", SqlDbType.Decimal).Value = Convert.ToDecimal(txttot.Text);
                    c.cmd.Parameters.Add("@pay", SqlDbType.NVarChar).Value = DropDownList1.SelectedItem.Text;
                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                    //MessageBox.Show("Saved");
                    lbla.Text = "-";
                    lblb.Text = "-";
                    lblm.Text = "-";
                    lbln.Text = "-";
                    lblpt.Text = "-";
                    lbls.Text = "-";
                    txtpid.Text = "";
                    DropDownList1.ClearSelection();
                    DropDownList1.SelectedItem.Text = "-------Select--------";
                    LinkButton1.Visible = true;
                    txtpid.Enabled = true;
                    Panel1.Visible = false;
                    txttot.Text = "";
                    txtpid.Text = "";
                    GenerateAutoID();
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }

            }
        }
    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        txtpid.Enabled = true ;
        LinkButton1.Visible = true;
        Panel1.Visible = false;
        txttot.Text = "";
        txtpid.Text = "";
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "-------Select--------";
    }
}
  
   
