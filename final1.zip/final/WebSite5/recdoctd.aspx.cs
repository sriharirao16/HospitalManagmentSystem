using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class recenq : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string dd;
         c = new connect();
        c.cmd.CommandText = "select * from empreg where department='" + DropDownList1 .SelectedItem .Text  + "' and status ='active'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "doc");
        if (ds.Tables["doc"].Rows.Count > 0)
        {
           
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("select");

            for (int i = 0; i <= ds.Tables["doc"].Rows.Count - 1; i++)
            {
                string st;
                st = Convert.ToString(ds.Tables["doc"].Rows[i].ItemArray[25]);
                //MessageBox.Show(st);
                dd = Convert.ToString(ds.Tables["doc"].Rows[i].ItemArray[3]);
                if (st == "active")
                {
                    DropDownList2.Items.Add(dd);

                }
            }
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        txtadrs.Text = "";
        txtage.Text = "";
        txtcare.Text = "";
        txtemail .Text ="";
        txtipid .Text ="";
        txtmbl .Text  ="";
        txtquli.Text = "";
        txtsex.Text = "";
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "select";
        DropDownList2.Items.Clear();
        DropDownList2.Items.Add("select");
        Panel1.Visible = false;
        //LinkButton1.Visible = true;
    }
    protected void btndis_Click(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {


        if (DropDownList1.SelectedItem.Text == "select" || DropDownList2.SelectedItem.Text == "select" )
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select First!!!')</script>");
            //MessageBox.Show("select First");
        }
        else
        {

            c = new connect();
            c.cmd.CommandText = "select * from empreg where department='" + DropDownList1.SelectedItem.Text + "' and  name='"+ DropDownList2.SelectedItem.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;

            adp.Fill(ds, "emp");
            if (ds.Tables["emp"].Rows.Count > 0)
            {
                Panel1.Visible = true;

                for (int i = 0; i <= ds.Tables["emp"].Rows.Count - 1; i++)
                {

                    txtipid.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[1]);
                    txtcare.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[5]);
                    txtsex.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[14]);
                    txtquli.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[21]);
                    txtadrs.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[6]);
                    txtage.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[8]);
                    txtmbl.Text = Convert.ToString(ds.Tables["emp"].Rows[i].ItemArray[17]);
                    txtemail .Text  = Convert.ToString (ds.Tables["emp"].Rows[i].ItemArray[23]);
                 
                }


            }
        }


    }
}
