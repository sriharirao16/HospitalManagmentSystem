using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class wardc : System.Web.UI.Page
{
    connect c; 
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    DateTime pda;
    decimal bcharge, total;
    protected void Page_Load(object sender, EventArgs e)
    {
        txtage.Enabled = false;
        txtbcharge.Enabled = false;
        txtbed.Enabled = false;
        txtdate.Enabled = false;
        txtname.Enabled = false;
        txtwardtype.Enabled = false;
        txtwno.Enabled = false;
        
       

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
     
        try
        {
            
           c = new connect();
            c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno .Text  + "'";

            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "get");
            if (ds.Tables["get"].Rows.Count > 0)
            {
                for (int i = 0; i <= ds.Tables["get"].Rows.Count - 1; i++)
                {
                    DateTime today = DateTime.Now;
                    txtdate.Text = today.ToString("d");
                    txtname.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[5]);
                    txtage.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[18]);
                    txtwardtype.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[23]);
                    txtwno.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[24]);
                    txtbed.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[25]);
                    txtbcharge.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[26]);

                }
            }
            else
            {
                //MessageBox.Show("record not found");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record  Not Found!!!')</script>");
           
                txtipno.Text = "";
            }

        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }


    }
    protected void btncal_Click(object sender, EventArgs e)
    {
        c = new connect();



        c.cmd.CommandText = "select * from bedcharges where ipno='" + txtipno .Text  + "'";

        ds = new DataSet();
        adp.SelectCommand = c.cmd;
        adp.Fill(ds, "edit");
        if (ds.Tables["edit"].Rows.Count > 0)
        {
           
                //MessageBox.Show("already inserted");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Already Inserted!!!')</script>");
           
                txtage.Text = "";
                txtbcharge.Text = "";
                txtbed.Text = "";
                txtdate.Text = "";
                txtipno.Text = "";
                txtname.Text = "";
                txtwardtype.Text = "";
                txtwno.Text = "";

            
        }
            else
            {


                try
                {

                    c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno .Text  + "'";

                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "edit");
                    if (ds.Tables["edit"].Rows.Count > 0)
                    {
                        for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                        {
                         
                            pda = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[2]);

                        }
                    }
                    else
                    {
                        //MessageBox.Show("record not found");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                        txtipno.Text = "";
                    }

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }



                try
                {
                    c = new connect();
                    c.cmd.CommandText = "insert into bedcharges values(@ipno,@ipname,@wt,@wn,@bn,@bcharge,@pdate,@edate,@totdays,@tot)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@ipno", SqlDbType.NVarChar).Value = txtipno  .Text ;
                    c.cmd.Parameters.Add("@ipname", SqlDbType.NVarChar).Value = txtname .Text ;
                    c.cmd.Parameters.Add("@wt", SqlDbType.NVarChar).Value = txtwardtype .Text ;
                    c.cmd.Parameters.Add("@wn", SqlDbType.NVarChar).Value = txtwno .Text ;
                    c.cmd.Parameters.Add("@bn", SqlDbType.NVarChar).Value = txtbed .Text ;
                    c.cmd.Parameters.Add("@bcharge", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbcharge .Text );
                    c.cmd.Parameters.Add("@pdate", SqlDbType.NVarChar).Value = pda ;
                    c.cmd.Parameters.Add("@edate", SqlDbType.NVarChar).Value = txtdate .Text ;
                   
                    DateTime admit = new DateTime();
                    admit = Convert.ToDateTime(pda);
                    DateTime disch = DateTime.Now;
                    TimeSpan tspan = disch - admit;
                    double dayss = tspan.TotalDays;
                    c.cmd.Parameters.Add("@totdays", SqlDbType.Decimal ).Value =Convert .ToDecimal ( dayss.ToString("0"));
                    decimal day = Convert.ToDecimal(dayss.ToString("0"));
                    bcharge = Convert.ToDecimal(txtbcharge.Text);
                    total = bcharge * day;
                    c.cmd.Parameters.Add("@tot", SqlDbType.Decimal).Value = Convert.ToDecimal(total);

                    c.cmd.ExecuteNonQuery();

                    c.cmd.CommandText = "update ward set status1=@status1 where bedno='" + txtbed .Text  + "'";
                    c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Open";

                    c.cmd.ExecuteNonQuery();
                    
                    //MessageBox.Show("inserted");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('REcord Inserted!!!')</script>");
                    txtage.Text = "";
                    txtbcharge.Text = "";
                    txtbed.Text = "";
                    txtdate.Text = "";
                    txtipno.Text = "";
                    txtname.Text = "";
                    txtwardtype.Text = "";
                    txtwno.Text = "";



                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }

            

        
        }

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        txtage.Text = "";
        txtbcharge.Text = "";
        txtbed.Text = "";
        txtdate.Text = "";
        txtipno.Text = "";
        txtname.Text = "";
        txtwardtype.Text = "";
        txtwno.Text = "";
        
    }
}
