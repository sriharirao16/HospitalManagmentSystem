using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class ipbills : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    DateTime dt;
    long s=0;
    decimal tot=0, lcharge=0, dcharge=0, scharge=0, totdays=0,treat=0,bedsh=0;
    double amount=0;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        txtbillno.Enabled = false;
        if (!IsPostBack)
        {
            GenerateAutoID();
        }

       
    }

    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(billno)from ipbill ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        txtbillno.Text = i.ToString();


    }

    private static string[] units ={ "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
    private static string[] tens ={ " ", " ", "twenty", "thirty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninety" };

    public static string convertamount(double amount)
    {
        try
        {
            Int64 amount_int = (Int64)amount;
            Int64 amount_dec = (Int64)Math.Round((amount - (double)(amount_int)) * 100);
            if (amount_dec == 0)
            {
                return convert(amount_int) + " only.";
            }
            else
            {
                return convert(amount_int) + " point " + convert(amount_dec) + " only.";
            }
        }
        catch (Exception)
        {
            throw;
        }

        //return "";

    }
    public static string convert(Int64 i)
    {
        if (i < 20)
        {
            return units[i];
        }
        if (i < 100)
        {
            return tens[i / 10] + ((i % 10 > 0) ? " " + convert(i % 10) : " ");
        }
        if (i < 1000)
        {
            return units[i / 100] + " hundred " + ((i % 100 > 0) ? " And " + convert(i % 100) : " ");
        }
        if (i < 100000)
        {
            return convert(i / 1000) + " thousand " + ((i % 1000 > 0) ? " " + convert(i % 1000) : " ");
        }
        if (i < 10000000)
        {
            return convert(i / 100000) + " lakh " + ((i % 100000 > 0) ? " " + convert(i % 1000) : " ");
        }
        return "";
    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtipno.Text == "")
        {
            MessageBox.Show("enter ImPatient Id ");
            txtipno.Focus();
        }


        else
        {
            c = new connect();
            c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "l");
            if (ds.Tables["l"].Rows.Count > 0)
            {
                

                c = new connect();
                c.cmd.CommandText = "select * from discharge where ipno='" + txtipno.Text + "'"; 
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "b");
                if (ds.Tables["b"].Rows.Count > 0)

                {
                    c = new connect();
                    c.cmd.CommandText = "select * from bedcharges where ipno='" + txtipno.Text + "'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "bill");
                    if (ds.Tables["bill"].Rows.Count > 0)
                    {
                        for (int i = 0; i <= ds.Tables["bill"].Rows.Count - 1; i++)
                        {

                            Session["wt"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[2]);
                            Session["wn"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[3]);
                            Session["bn"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[4]);
                            Session["bedcharge"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[5]);
                            Session["totdays"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[8]);
                            Session["tot"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[9]);

                        }
                        
                    }

                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Pending Of BedCharge Calculation!!!')</script>");
                        //MessageBox.Show("Pending of bedcharge Calculation");
                        txtipno.Text = "";

                    }

                    c = new connect();
                    c.cmd.CommandText = "select * from ipdoc where ipno='" + txtipno.Text + "'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "bill");
                    if (ds.Tables["bill"].Rows.Count > 0)
                    {
                        for (int i = 0; i <= ds.Tables["bill"].Rows.Count - 1; i++)
                        {
                            Session["doc"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[4]);
                            Session["dept"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[5]);
                            Session["dcharge"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[9]);
                            Session["treat"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[11]);
                            Session["t"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[10]);
                            treat = Convert.ToDecimal((String)Session["dcharge"]) + Convert.ToDecimal((String)Session["treat"]);
                        }


                    }

                    c = new connect();
                    c.cmd.CommandText = "select * from bedshift where ipno='" + txtipno.Text + "'";
                    ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "bill");
                    if (ds.Tables["bill"].Rows.Count > 0)
                    {
                        for (int i = 0; i <= ds.Tables["bill"].Rows.Count - 1; i++)
                        {
                            Session["bedshift"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[9]);
                            
                        }
                    }




                    //else
                    //{
                    //    MessageBox.Show("pending of Calculation of Treatment");
                    //    txtipno.Text = "";

                    //}

                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "bill");
                        if (ds.Tables["bill"].Rows.Count > 0)
                        {
                            GenerateAutoID();
                            LinkButton1.Visible = false;
                            txtipno.Enabled = false;
                            btndis.Visible = true;
                            btnsave.Visible = false;

                            for (int i = 0; i <= ds.Tables["bill"].Rows.Count - 1; i++)
                            {
                                txtipno.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[1]);
                                txtname.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[5]);
                                dt = Convert.ToDateTime(ds.Tables["bill"].Rows[i].ItemArray[2]);
                                txtdoa.Text = dt.ToString("d");
                                txtopno.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[0]);
                                txtaddress.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[8]);
                                //txtdod .Text =
                                //txtdate .Text =
                                txtage.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[18]);
                                txtsex.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[17]);
                                txtscheme.Text = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[28]);
                                if (txtscheme.Text == "select")
                                {
                                    Label1.Visible = false;
                                    Label2.Visible = false;
                                    txtscheme.Visible  = false;
                                    txtsid.Visible = false;

                                }
                                else
                                {
                                    Label1.Visible = true ;
                                    Label2.Visible = true;
                                    txtscheme.Visible = true;
                                    txtsid.Visible = true;
                                    txtsid.Text = "-";
                                    txtsid.Focus();
                                }


                                DateTime today = DateTime.Now;
                                txtdate.Text = today.ToString("d");


                            }
                            c = new connect();
                            c.cmd.CommandText = "select * from labdetails where pid='" + txtipno.Text + "'and ptype='IP' and status='reg'";
                            ds = new DataSet();
                            adp.SelectCommand = c.cmd;
                            adp.Fill(ds, "bill");
                            if (ds.Tables["bill"].Rows.Count > 0)
                            {
                                for (int i = 0; i <= ds.Tables["bill"].Rows.Count - 1; i++)
                                {
                                    Session["test"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[8]);
                                    Session["lcharge"] = Convert.ToString(ds.Tables["bill"].Rows[i].ItemArray[9]);
                                }
                                c.cmd.CommandText = "select sum(charge)from labdetails where pid='" + txtipno.Text + "'and ptype='IP' and status='reg'";
                                int j = Convert.ToInt32(c.cmd.ExecuteScalar());
                                c.cnn.Close();
                                Session["j"] = j.ToString();

                            }

                            tot = Convert.ToDecimal((String)Session["tot"]);
                            bedsh = Convert.ToDecimal((String)Session["bedshift"]);
                            
                            lcharge = Convert.ToDecimal((String)Session["j"]);
                            //dcharge = Convert.ToDecimal((String)Session["dcharge"]);

                            txtamt.Text = Convert.ToString(tot + lcharge + treat+bedsh ) + ".0";
                            dcharge = tot + lcharge + treat+bedsh ;


                            if (txtscheme.Text == "select")
                            {
                                txtsamt.Text = "0.0";
                                txtgtot.Text = Convert.ToString(tot + lcharge + treat+bedsh ) + ".0";
                                double aamoun = Convert.ToDouble(tot + lcharge + treat+bedsh );
                                amount = aamoun;
                                lblword.Text = convertamount(amount);

                            }
                            else
                            {




                                //long sscharge,srm,erm,stot;
                                //c.cmd.CommandText = "select sum(samt)from ipbill where sid='" + txtsid .Text + "'";
                                //s  = Convert.ToInt32(c.cmd.ExecuteScalar());
                                //c.cnn.Close();
                                //Session["sm"] = s.ToString();

                                //if (s > 0)
                                //{
                                //    sscharge = Convert .ToInt64 ((dcharge * 20) / 100);
                                   
                                //    if (50000 < s)
                                //    {

                                //        srm = 50000 - s;

                                //        if (srm <= sscharge)
                                //        {

                                //            scharge = (dcharge * 20) / 100;
                                //            txtsamt.Text = scharge.ToString();
                                //            txtgtot.Text = Convert.ToString(dcharge - scharge) + ".0";

                                //        }
                                //        else
                                //        {
                                //            erm = sscharge - srm;
                                //            txtsamt.Text  =Convert .ToString ( srm);
                                //            stot=Convert .ToInt64 ( txtamt .Text) ;
                                //            txtamt .Text ="";
                                //            txtamt .Text =Convert .ToString ( stot +erm );
                                //            txtgtot.Text =Convert .ToString ( (stot+erm )-srm  );



                                //        }


                                //    }
                                //    else
                                //    {
                                //        txtsamt.Text = "0.0";
                                //        txtgtot.Text = Convert.ToString(tot + lcharge + treat) + ".0";
                                //    }

                                //}
                                //else
                                //{

                                //    scharge = (dcharge * 20) / 100;
                                //    txtsamt.Text = scharge.ToString();
                                //    txtgtot.Text = Convert.ToString(dcharge - scharge) + ".0";
                            
                                //}







                                scharge = (dcharge * 20) / 100;
                                txtsamt.Text = scharge.ToString();
                                txtgtot.Text = Convert.ToString(dcharge - scharge) + ".0";
                                double aamoun = Convert.ToDouble(dcharge - scharge);
                                amount = aamoun;
                                lblword.Text = convertamount(amount);
                                
                            }



                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }




                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('First You Fill the ...Discharge Summary!!!')</script>");
                    //MessageBox.Show("first You fill the.....discharge summary");
                    txtipno.Text = "";

                }


            }

            else
                        
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Correct Ip Number!!!')</script>");          
                //MessageBox.Show("Enter Correct Ip No");
                txtipno.Text = "";

                        
            }



        }
    }

    
    protected void btnnew_Click1(object sender, EventArgs e)
    {
        GridView4.Visible = false;
        bedshift.Visible = false;
        lblword.Text = "-";

        txtaddress.Text = "";
        txtage.Text = "";
        txtamt.Text = "";
        txtbillno.Text = "";
        txtdate.Text = "";
        txtdoa.Text = "";
        txtipno.Text = "";
        txtname.Text = "";
        txtopno.Text = "";
        txtsex.Text = "";
        DropDownList1.ClearSelection();
        DropDownList1.SelectedItem.Text = "-------Select--------";
        txtscheme.Text = "";
        txtsid.Text = "";
        txtsamt.Text = "";
        txtgtot.Text = "";

        GridView1.Visible = false;
        lblward.Visible = false;
        GridView2.Visible = false;
        lbltreat.Visible = false;
        GridView3.Visible = false;
        lbllab.Visible = false;

        lbltotamt.Visible = false;
        txtamt.Visible = false;
        lblpay.Visible = false;
        DropDownList1.Visible = false;
        lblscheme.Visible = false;
        txtsamt.Visible = false;
        lblgtot.Visible = false;
        txtgtot.Visible = false;
        Label3.Visible = false;
        lblword.Visible = false;

        GenerateAutoID();
        LinkButton1.Visible = true ;
        txtipno.Enabled = true ;
        btndis.Visible = false ;
        btnsave.Visible = false;

    
    
    }

    protected void btndis_Click(object sender, EventArgs e)
    {
        if (Convert .ToInt16 ((String)Session["bedshift"])==0)
        {
            bedshift.Visible = false ;
            GridView4.Visible = false ;
        }
        else
        {
            bedshift.Visible = true;
            GridView4.Visible = true;
        }

        GridView1.Visible = true;
        lblward.Visible = true;
        GridView2.Visible = true;
        lbltreat.Visible = true;
        GridView3.Visible = true;
        lbllab.Visible = true;

        lbltotamt.Visible = true;
        txtamt.Visible = true;
        lblpay.Visible = true;
        DropDownList1.Visible = true;
        lblscheme.Visible = true;
        txtsamt.Visible = true;
        lblgtot.Visible = true;
        txtgtot.Visible = true;
        Label3.Visible = true ;
        lblword.Visible = true;
        btnsave.Visible = true;
        btndis.Visible = false;
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "-------Select--------" ||txtipno .Text =="" )
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Select Payment Type or Enter Ip Number!!!')</script>");
            //MessageBox.Show("select payment type or enter Ip Number");
        }
        else
        {

            c = new connect();



            c.cmd.CommandText = "select * from ipbill where ipno='" + txtipno.Text + "'";

            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "ip");
            if (ds.Tables["ip"].Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Alread Inserted!!!')</script>");
                //MessageBox.Show("already inserted");
                lblword.Text = "-";

                txtaddress.Text = "";
                txtage.Text = "";
                txtamt.Text = "";
                txtbillno.Text = "";
                txtdate.Text = "";
                txtdoa.Text = "";
                txtipno.Text = "";
                txtname.Text = "";
                txtopno.Text = "";
                txtsex.Text = "";
                DropDownList1.ClearSelection();
                DropDownList1.SelectedItem.Text = "-------Select--------";
                txtscheme.Text = "";
                txtsid.Text = "";
                txtsamt.Text = "";
                txtgtot.Text = "";

                
                    GridView1.Visible = false ;
                    lblward.Visible = false;
                    GridView2.Visible = false;
                    lbltreat.Visible = false;
                    GridView3.Visible = false;
                    lbllab.Visible = false;

                    lbltotamt.Visible = false;
                    txtamt.Visible = false;
                    lblpay.Visible = false;
                    DropDownList1.Visible = false;
                    lblscheme.Visible = false;
                    txtsamt.Visible = false;
                    lblgtot.Visible = false;
                    txtgtot.Visible = false;
                    Label3.Visible = false;
                    lblword.Visible = false;

                     GenerateAutoID();

                    LinkButton1.Visible = true;
                    txtipno.Enabled = true;
                    btndis.Visible = false;
                    btnsave.Visible = false;
               

    
            }
            else
            {

                try
                {
                    c = new connect();
                    c.cmd.CommandText = "insert into ipbill values(@billno,@ipno,@opno,@date,@name,@age,@sex,@address,@doa,@doctor,@department,@wardtype,@wardno,@bedno,@bedcharge,@totaldays,@tot,@dcharge,@test,@lcharge,@totamt,@pay,@shme,@sid,@samt,@fbill,@bword,@treat,@tcharge,@bedshift)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@billno", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbillno.Text);//Convert.ToDecimal(txtbillno.Text);
                    c.cmd.Parameters.Add("@ipno", SqlDbType.NVarChar).Value = txtipno.Text;
                    c.cmd.Parameters.Add("@opno", SqlDbType.NVarChar).Value = txtopno.Text;
                    c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = txtdate.Text;
                    c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                    c.cmd.Parameters.Add("@age", SqlDbType.Decimal).Value = Convert.ToDecimal(txtage.Text);
                    c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = txtsex.Text;
                    c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                    c.cmd.Parameters.Add("@doa", SqlDbType.DateTime).Value = txtdoa.Text;
                    c.cmd.Parameters.Add("@doctor", SqlDbType.NVarChar).Value = (String)Session["doc"];
                    c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = (String)Session["dept"];
                    c.cmd.Parameters.Add("@wardtype", SqlDbType.NVarChar).Value = (String)Session["wt"];
                    c.cmd.Parameters.Add("@wardno", SqlDbType.NVarChar).Value = (String)Session["wn"];
                    c.cmd.Parameters.Add("@bedno", SqlDbType.NVarChar).Value = (String)Session["bn"];
                    decimal  bedcharge = Convert.ToDecimal((String)Session["bedcharge"]);

                    c.cmd.Parameters.Add("@bedcharge", SqlDbType.Decimal).Value = bedcharge;
                    totdays = Convert.ToDecimal((String)Session["totdays"]);
                    c.cmd.Parameters.Add("@totaldays", SqlDbType.Decimal).Value = totdays;
                    tot = Convert.ToDecimal((String)Session["tot"]);
                    c.cmd.Parameters.Add("@tot", SqlDbType.Decimal).Value = tot;
                    dcharge = Convert.ToDecimal((String)Session["dcharge"]);
                    c.cmd.Parameters.Add("@dcharge", SqlDbType.Decimal).Value = dcharge;
                    c.cmd.Parameters.Add("@test", SqlDbType.NVarChar).Value = "labtest"; //(String)Session["test"];
                    lcharge = Convert.ToDecimal((String)Session["lcharge"]);
                    c.cmd.Parameters.Add("@lcharge", SqlDbType.Decimal).Value = lcharge;
                    c.cmd.Parameters.Add("@totamt", SqlDbType.Decimal).Value = Convert.ToDecimal(txtamt.Text);
                    c.cmd.Parameters.Add("@pay", SqlDbType.NVarChar).Value = DropDownList1.SelectedItem.Text;
                    c.cmd.Parameters.Add("@shme", SqlDbType.NVarChar).Value = txtscheme.Text;
                    c.cmd.Parameters.Add("@sid", SqlDbType.NVarChar).Value = txtsid.Text;
                    c.cmd.Parameters.Add("@samt", SqlDbType.Decimal).Value = Convert.ToDecimal(txtsamt.Text);
                    c.cmd.Parameters.Add("@fbill", SqlDbType.NVarChar).Value = Convert.ToDecimal(txtgtot.Text);
                    c.cmd.Parameters.Add("@bword", SqlDbType.NVarChar).Value = lblword.Text;
                    c.cmd.Parameters.Add("@treat", SqlDbType.NVarChar).Value = (String)Session["t"];
                    c.cmd.Parameters.Add("@tcharge", SqlDbType.NVarChar).Value = (String)Session["treat"];
                    c.cmd.Parameters.Add("@bedshift", SqlDbType.Decimal).Value = (String)Session["bedshift"];
                    
                    
                    
                   
                    
                    

                    
                    c.cmd.ExecuteNonQuery();
                    //String s = (String)Session["bn"]
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved...Niw Ypu Can Get The Bill!!!')</script>");
                    //MessageBox.Show("Record Saved ..You can Get the Bill");
                    lblword.Text = "-";

                    txtaddress.Text = "";
                    txtage.Text = "";
                    txtamt.Text = "";
                    txtbillno.Text = "";
                    txtdate.Text = "";
                    txtdoa.Text = "";
                    txtipno.Text = "";
                    txtname.Text = "";
                    txtopno.Text = "";
                    txtsex.Text = "";
                    DropDownList1.ClearSelection();
                    DropDownList1.SelectedItem.Text = "-------Select--------";
                    txtscheme.Text = "";
                    txtsid.Text = "";
                    txtsamt.Text = "";
                    txtgtot.Text = "";


                    GridView1.Visible = false ;
                    lblward.Visible = false;
                    GridView2.Visible = false;
                    lbltreat.Visible = false;
                    GridView3.Visible = false;
                    lbllab.Visible = false;

                    lbltotamt.Visible = false;
                    txtamt.Visible = false;
                    lblpay.Visible = false;
                    DropDownList1.Visible = false;
                    lblscheme.Visible = false;
                    txtsamt.Visible = false;
                    lblgtot.Visible = false;
                    txtgtot.Visible = false;
                    Label3.Visible = false;
                    lblword.Visible = false;
                    GenerateAutoID();

                    LinkButton1.Visible = true;
                    txtipno.Enabled = true;
                    btndis.Visible = false;
                    btnsave.Visible = false;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }
        }
    }
}
