using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class inactivedisplay : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            c = new connect();
            c.cmd.CommandText = "select * from empreg where status='Inactive'";
            adp.SelectCommand = c.cmd;
            ds = new DataSet();
            adp.Fill(ds, "ward");

            if (ds.Tables["ward"].Rows.Count >= 0)
            {

                

                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    if (GridView1.Rows[i].Cells[0].Text == "lab")
                    {
                        //   GridView1.Rows[i].Cells[4].ForeColor = Color.Blue    ;
                        GridView1.Rows[i].Cells[0].BackColor = Color.Green;
                        GridView1.Rows[i].ForeColor = Color.Blue;
                    }

                    else
                    {
                        GridView1.Rows[i].Cells[0].BackColor = Color.Red;
                        GridView1.Rows[i].ForeColor = Color.Maroon;

                        // GridView1.Rows[i].Cells[2 ].ForeColor = Color.Red;

                        // Response.Write(GridView1.Rows[i].Cells[4].Text);

                    }
                }
            }
            else
            {
                GridView1.Visible = false;
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Wrong!!!')</script>");
                //MessageBox.Show("wrong");
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }

    }
}
