using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class ipdoc : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    DateTime pda;
    decimal bcharge, total;
 
    DateTime dt;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {

        txtipno.Text = "";
        txtname.Text = "";
        txtdoc.Text = "";
        txtadmdate.Text = "";
        txtdate.Text = "";
        txtage.Text = "";
        txtdept.Text = "";
        txtdischargdate.Text = "";
        txttcharges.Text = "";
        txttname.Text = "";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtipno.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Ip No!!!')</script>");
            //MessageBox.Show("first enter IPno");
        }
        else
        {
            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "get");
                if (ds.Tables["get"].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables["get"].Rows.Count - 1; i++)
                    {
                        txtname.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[5]);
                        txtage.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[18]);
                        txtdoc.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[22]);
                        txtdept.Text = Convert.ToString(ds.Tables["get"].Rows[i].ItemArray[19]);

                        dt = Convert.ToDateTime(ds.Tables["get"].Rows[i].ItemArray[3]);
                        txtadmdate.Text = dt.ToString("d");
                        DateTime today = DateTime.Now;
                        txtdate.Text = today.ToString("d");
                        txtdischargdate.Text = today.ToString("d");
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    txtipno.Text = "";
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }


    }
    protected void btncalc_Click(object sender, EventArgs e)
    {
        if (txtipno.Text == "" || txttname.Text == "" || txttcharges.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Plz...Enter All The Fields!!!')</script>");
            //MessageBox.Show("plz ...Enter all Fields");
        }
        else
        {

            c = new connect();



            c.cmd.CommandText = "select * from ipdoc where ipno='" + txtipno.Text + "'";

            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "edit");
            if (ds.Tables["edit"].Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Already Inserted!!!')</script>");
                //MessageBox.Show("already inserted");
                txtipno.Text = "";
                txtname.Text = "";
                txtdoc.Text = "";
                txtadmdate.Text = "";
                txtdate.Text = "";
                txtage.Text = "";
                txtdept.Text = "";
                txtdischargdate.Text = "";
                txttcharges.Text = "";
                txttname.Text = "";

            }
            else
            {


                //try
                //{

                //c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";

                //ds = new DataSet();
                //adp.SelectCommand = c.cmd;
                //adp.Fill(ds, "edit");
                //if (ds.Tables["edit"].Rows.Count > 0)
                //{
                //    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                //    {

                //        pda = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[2]);

                //    }
                //}
                //else
                //    {
                //        MessageBox.Show("record not found");
                //        txtipno.Text = "";
                //    }

                //}
                //catch (Exception)
                //{
                //    throw;
                //}
                //finally
                //{
                //    c.cnn.Close();
                //}



                try
                {
                    c = new connect();
                    c.cmd.CommandText = "insert into ipdoc values(@ipno,@date,@name,@age,@doctor,@dept,@admdate,@disdate,@totdays,@tot,@tname,@tcharge)";
                    c.cmd.Parameters.Clear();
                    c.cmd.Parameters.Add("@ipno", SqlDbType.NVarChar).Value = txtipno.Text;
                    c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = txtdate.Text;
                    c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                    c.cmd.Parameters.Add("@age", SqlDbType.Decimal).Value = Convert.ToDecimal(txtage.Text);
                    c.cmd.Parameters.Add("@doctor", SqlDbType.NVarChar).Value = txtdoc.Text;
                    c.cmd.Parameters.Add("@dept", SqlDbType.NVarChar).Value = txtdept.Text;
                    c.cmd.Parameters.Add("@admdate", SqlDbType.DateTime).Value = txtadmdate.Text;
                    c.cmd.Parameters.Add("@disdate", SqlDbType.DateTime).Value = txtdischargdate.Text;
                    
                    DateTime admit = new DateTime();
                    admit = Convert.ToDateTime(txtadmdate.Text);
                    DateTime disch = DateTime.Now;
                    TimeSpan tspan = disch - admit;
                    double dayss = tspan.TotalDays;
                    c.cmd.Parameters.Add("@totdays", SqlDbType.Decimal).Value = Convert.ToDecimal(dayss.ToString("0"));
                    decimal day = Convert.ToDecimal(dayss.ToString("0"));
                    total = 250 * day;
                    c.cmd.Parameters.Add("@tot", SqlDbType.Decimal).Value = Convert.ToDecimal(total);
                    c.cmd.Parameters.Add("@tname", SqlDbType.NVarChar).Value = txttname.Text;
                    c.cmd.Parameters.Add("@tcharge", SqlDbType.Decimal).Value = Convert.ToDecimal(txttcharges.Text);
                    

                    c.cmd.ExecuteNonQuery();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Inserted!!!')</script>");
                    //MessageBox.Show("inserted");
                    txtipno.Text = "";
                    txtname.Text = "";
                    txtdoc.Text = "";
                    txtadmdate.Text = "";
                    txtdate.Text = "";
                    txtage.Text = "";
                    txtdept.Text = "";
                    txtdischargdate.Text = "";
                    txttcharges.Text = "";
                    txttname.Text = "";





                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }




            }
        }


    }
}
