using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class empreg : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    String empid = "EMP";
    String empno = "DOC";
    String labno = "LAB";
    String nurse = "NURSE";
    String others = "OTHERS";
    DateTime today = DateTime.Now;
    protected void Page_Load(object sender, EventArgs e)
    {
        MaintainScrollPositionOnPostBack = true;


        Label3 . Text = today.ToString("d");
        lbltime.Text = today.ToString("t");
        if (!IsPostBack)
        {
            GenerateAutoID();
        }

        if (!IsPostBack)
        {
            Calendar1.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            Label1.Visible = false;
            Label2.Visible = false;

            LoadYears();
            LoadMonths();
        }

    }
    private void LoadMonths()
    {

        DataSet dsMonths = new DataSet();
        dsMonths.ReadXml(Server.MapPath("~/Month.xml"));

        DropDownList2.DataTextField = "Name";
        DropDownList2.DataValueField = "Number";


        DropDownList2.DataSource = dsMonths;
        DropDownList2.DataBind();

    }


    private void LoadYears()
    {

        DataSet dsYears = new DataSet();
        dsYears.ReadXml(Server.MapPath("~/Years.xml"));

        DropDownList1.DataTextField = "Number";
        DropDownList1.DataValueField = "Number";


        DropDownList1.DataSource = dsYears;
        DropDownList1.DataBind();
    }

    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(empid)from empreg ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        Session["no"] = i.ToString();

    }
    protected void ddlemptype_SelectedIndexChanged(object sender, EventArgs e)
    {
       
            if (ddlemptype.SelectedItem.Text == "Doctor")
            {
                GenerateAutoID();
                Label4 . Text = empno + (String)Session["no"];
                ddldept.Visible = true;
                labeldept.Visible = true;

                GenerateAutoID();
            }
            else if (ddlemptype.SelectedItem.Text == "Reception")
            {
                 Label4 . Text = empid + (String)Session["no"];
                ddldept.Visible = false;
                labeldept.Visible = false;
                GenerateAutoID();
            }
            else if (ddlemptype.SelectedItem.Text == "Lab")
            {
                Label4.Text = labno + (String)Session["no"];
                ddldept.Visible = false;
                labeldept.Visible = false;
                GenerateAutoID();
            }
            else if (ddlemptype.SelectedItem.Text == "Nurse")
            {
                Label4.Text = nurse + (String)Session["no"];
                ddldept.Visible = false;
                labeldept.Visible = false;
                GenerateAutoID();
            }
            else if (ddlemptype.SelectedItem.Text == "Others")
            {
                Label4.Text = others + (String)Session["no"];
                ddldept.Visible = false;
                labeldept.Visible = false;
                GenerateAutoID();
            }
            else
                Label4.Text = "";

       
    }
    protected void btnnew_Click1(object sender, EventArgs e)
    {
        ddlemptype.ClearSelection();
        Label4.Text = "";
        ddlname.ClearSelection();
        ddlname.SelectedItem.Text = "select";
        txtname.Text = "";
        ddlcare.SelectedItem.Text = "select";
        ddlcare.ClearSelection();
        txtcareof.Text = "";
        txtaddress.Text = "";
        txtdob.Text = "";
        txtage.Text = "";
        txtcity.Text = "";
        txtstate.Text = "";
        ddlbg.ClearSelection();
        ddlbg.SelectedItem.Text = "select";
        txtreli.Text = "";
        radiofemale.Checked = false;
        Radiomale.Checked = false;
        Radioothers.Checked = false;
        ddlms.ClearSelection();
        ddlms.SelectedItem.Text = "select";
        txtpin.Text = "";
        txtmob.Text = "";
        txtadhar.Text = "";
        txtdoj.Text = "";
        ddldept.ClearSelection();
        ddldept.SelectedItem.Text = "select";
        txtquli.Text = "";
        txtcountry.Text = "";
        txtbasic.Text = "";
        txtda.Text = "";
        txthra.Text = "";
        txtpf.Text = "";
        TextBox1.Text = "";
        TextBox2.Text = "";
        txtmob.Text = "";
        txtemail.Text = "";
        txtdist.Text = "";


        labeldept.Visible = true;
        ddldept.Visible = true;
        ddldept.Enabled = true ;
        ddlbg.Enabled = true;
        ddlemptype.Enabled =true ;
        ddlname.Enabled = true ;
        txtname.Enabled = true ;
        ImageButton2.Enabled = true ;
        Panel3.Enabled = true ;
        txtquli.Enabled = true ;
        txtcountry.Enabled = true ;
        txtreli.Enabled = true ;
        txtbasic.Enabled = true ;

        btnupdate.Visible = false;
        btnsave.Visible = true;
        btnsearch.Visible = true;
        btnedit.Visible = true;
        TextBox1.Enabled = true;
        TextBox2.Visible = true;

        Panel1.Enabled = true ;
        TextBox1.Visible = true;
                      
        
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        string gen;
        if (ddlemptype .SelectedItem .Text =="select"|| ddlname.SelectedItem.Text == "select" || txtname.Text == "" || ddlcare.SelectedItem.Text == "select" || txtcareof.Text == "" || txtaddress.Text == "" || txtdob.Text == "" || txtcity.Text == "" || txtstate.Text == ""  || txtreli.Text == "" || radiofemale.Checked == false && Radiomale.Checked == false && Radioothers.Checked == false || ddlms.SelectedItem.Text == "select" || txtpin.Text == "" || txtmob.Text == "" || txtadhar.Text == "" || txtquli.Text == "" || txtcountry.Text == "" || txtbasic.Text == ""||txtdist .Text ==""||txtemail .Text ==""||txtda .Text =="")
        {
            //MessageBox.Show("enter all fields");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All The Fields !!!')</script>");
        }
        else
        {
            c = new connect();
            c.cmd.CommandText = "select * from empreg where empid='" + Label4.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "edit");
            if (ds.Tables["edit"].Rows.Count > 0)
            {
                // MessageBox.Show("id already there");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Already Done!!!')</script>");
            }
            else
            {
                if (ddlemptype.SelectedItem.Text == "doctor")
                {
                    try
                    {
                        c = new connect();
                        c.cmd.CommandText = "insert into empreg values(@emptype,@empid,@empndrp,@name,@empcdrp,@care,@address,@dob,@age,@city,@country,@state,@bloodgrp,@relig,@sex,@ms,@pin,@mob,@adhar,@doj,@department,@quali,@altmob,@email,@basic,@status,@da,@hra,@pf,@dist)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@emptype", SqlDbType.NVarChar).Value = ddlemptype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@empid", SqlDbType.NVarChar).Value = Label4.Text;
                        c.cmd.Parameters.Add("@empndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@empcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                        c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                        c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                        c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdob.Text);
                        c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                        c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                        c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
                        c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                        c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                        c.cmd.Parameters.Add("@relig", SqlDbType.NVarChar).Value = txtreli.Text;

                        if (Radiomale.Checked == true)
                            gen = Radiomale.Text;
                        else
                            gen = radiofemale.Text;

                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                        c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                        c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                        c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                        c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                        c.cmd.Parameters.Add("@doj", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdoj.Text);
                        c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                        c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                        c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                        c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                        c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "active";
                        c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(txtda.Text);
                        c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(txthra.Text);
                        c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpf.Text);
                        c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;

                        c.cmd.ExecuteNonQuery();
                        Session["id"] = Label4.Text;
                        //MessageBox.Show("Saved");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Saved!!!')</script>");
                        //  Response.Redirect("~/docpass.aspx");
                        ddlemptype.ClearSelection();
                        Label4.Text = "";
                        ddlname.ClearSelection();
                        ddlname.SelectedItem.Text = "select";
                        txtname.Text = "";
                        ddlcare.SelectedItem.Text = "select";
                        ddlcare.ClearSelection();
                        txtcareof.Text = "";
                        txtaddress.Text = "";
                        txtdob.Text = "";
                        txtage.Text = "";
                        txtcity.Text = "";
                        txtstate.Text = "";
                        ddlbg.ClearSelection();
                        ddlbg.SelectedItem.Text = "select";
                        txtreli.Text = "";
                        radiofemale.Checked = false;
                        Radiomale.Checked = false;
                        Radioothers.Checked = false;
                        ddlms.ClearSelection();
                        ddlms.SelectedItem.Text = "select";
                        txtpin.Text = "";
                        txtmob.Text = "";
                        txtadhar.Text = "";
                        txtdoj.Text = "";
                        ddldept.ClearSelection();
                        ddldept.SelectedItem.Text = "select";
                        txtquli.Text = "";
                        txtcountry.Text = "";
                        txtbasic.Text = "";
                        txtda.Text = "";
                        txthra.Text = "";
                        txtpf.Text = "";

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        txtmob.Text = "";
                        txtemail.Text = "";
                        txtdist.Text = "";
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
                else if (ddlemptype.SelectedItem.Text == "lab")
                {
                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into empreg values(@emptype,@empid,@empndrp,@name,@empcdrp,@care,@address,@dob,@age,@city,@country,@state,@bloodgrp,@relig,@sex,@ms,@pin,@mob,@adhar,@doj,@department,@quali,@altmob,@email,@basic,@status,@da,@hra,@pf,@dist)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@emptype", SqlDbType.NVarChar).Value = ddlemptype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@empid", SqlDbType.NVarChar).Value = Label4.Text;
                        c.cmd.Parameters.Add("@empndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@empcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                        c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                        c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                        c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdob.Text);
                        c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                        c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                        c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
                        c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                        c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                        c.cmd.Parameters.Add("@relig", SqlDbType.NVarChar).Value = txtreli.Text;

                        if (Radiomale.Checked == true)
                            gen = Radiomale.Text;
                        else
                            gen = radiofemale.Text;

                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                        c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                        c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                        c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                        c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                        c.cmd.Parameters.Add("@doj", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdoj.Text);
                        c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                        c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                        c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                        c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                        c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "active";
                        c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(txtda.Text);
                        c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(txthra.Text);
                        c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpf.Text);
                        c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                        c.cmd.ExecuteNonQuery();
                        Session["id"] = Label4.Text;
                        //MessageBox.Show("Saved");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                        //   btnsave.Enabled = false;

                        Response.Redirect("~/c_lablog.aspx");

                        ddlemptype.ClearSelection();
                        Label4.Text = "";
                        ddlname.ClearSelection();
                        ddlname.SelectedItem.Text = "select";
                        txtname.Text = "";
                        ddlcare.SelectedItem.Text = "select";
                        ddlcare.ClearSelection();
                        txtcareof.Text = "";
                        txtaddress.Text = "";
                        txtdob.Text = "";
                        txtage.Text = "";
                        txtcity.Text = "";
                        txtstate.Text = "";
                        ddlbg.ClearSelection();
                        ddlbg.SelectedItem.Text = "select";
                        txtreli.Text = "";
                        radiofemale.Checked = false;
                        Radiomale.Checked = false;
                        Radioothers.Checked = false;
                        ddlms.ClearSelection();
                        ddlms.SelectedItem.Text = "select";
                        txtpin.Text = "";
                        txtmob.Text = "";
                        txtadhar.Text = "";
                        txtdoj.Text = "";
                        ddldept.ClearSelection();
                        ddldept.SelectedItem.Text = "select";
                        txtquli.Text = "";
                        txtcountry.Text = "";
                        txtbasic.Text = "";
                        txtda.Text = "";
                        txthra.Text = "";
                        txtpf.Text = "";

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        txtmob.Text = "";
                        txtemail.Text = "";
                        txtdist.Text = "";
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
                else if (ddlemptype.SelectedItem.Text == "Nurse")
                {
                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into empreg values(@emptype,@empid,@empndrp,@name,@empcdrp,@care,@address,@dob,@age,@city,@country,@state,@bloodgrp,@relig,@sex,@ms,@pin,@mob,@adhar,@doj,@department,@quali,@altmob,@email,@basic,@status,@da,@hra,@pf,@dist)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@emptype", SqlDbType.NVarChar).Value = ddlemptype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@empid", SqlDbType.NVarChar).Value = Label4.Text;
                        c.cmd.Parameters.Add("@empndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@empcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                        c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                        c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                        c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdob.Text);
                        c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                        c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                        c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
                        c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                        c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                        c.cmd.Parameters.Add("@relig", SqlDbType.NVarChar).Value = txtreli.Text;

                        if (Radiomale.Checked == true)
                            gen = Radiomale.Text;
                        else
                            gen = radiofemale.Text;

                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                        c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                        c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                        c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                        c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                        c.cmd.Parameters.Add("@doj", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdoj.Text);
                        c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                        c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                        c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                        c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                        c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "active";
                        c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(txtda.Text);
                        c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(txthra.Text);
                        c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpf.Text);
                        c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                        c.cmd.ExecuteNonQuery();
                        Session["id"] = Label4.Text;
                        //MessageBox.Show("Saved");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                        //   btnsave.Enabled = false;

                        //Response.Redirect("~/c_lablog.aspx");

                        ddlemptype.ClearSelection();
                        Label4.Text = "";
                        ddlname.ClearSelection();
                        ddlname.SelectedItem.Text = "select";
                        txtname.Text = "";
                        ddlcare.SelectedItem.Text = "select";
                        ddlcare.ClearSelection();
                        txtcareof.Text = "";
                        txtaddress.Text = "";
                        txtdob.Text = "";
                        txtage.Text = "";
                        txtcity.Text = "";
                        txtstate.Text = "";
                        ddlbg.ClearSelection();
                        ddlbg.SelectedItem.Text = "select";
                        txtreli.Text = "";
                        radiofemale.Checked = false;
                        Radiomale.Checked = false;
                        Radioothers.Checked = false;
                        ddlms.ClearSelection();
                        ddlms.SelectedItem.Text = "select";
                        txtpin.Text = "";
                        txtmob.Text = "";
                        txtadhar.Text = "";
                        txtdoj.Text = "";
                        ddldept.ClearSelection();
                        ddldept.SelectedItem.Text = "select";
                        txtquli.Text = "";
                        txtcountry.Text = "";
                        txtbasic.Text = "";
                        txtda.Text = "";
                        txthra.Text = "";
                        txtpf.Text = "";

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        txtmob.Text = "";
                        txtemail.Text = "";
                        txtdist.Text = "";
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
                else if (ddlemptype.SelectedItem.Text == "Others")
                {
                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into empreg values(@emptype,@empid,@empndrp,@name,@empcdrp,@care,@address,@dob,@age,@city,@country,@state,@bloodgrp,@relig,@sex,@ms,@pin,@mob,@adhar,@doj,@department,@quali,@altmob,@email,@basic,@status,@da,@hra,@pf,@dist)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@emptype", SqlDbType.NVarChar).Value = ddlemptype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@empid", SqlDbType.NVarChar).Value = Label4.Text;
                        c.cmd.Parameters.Add("@empndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@empcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                        c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                        c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                        c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdob.Text);
                        c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                        c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                        c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
                        c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                        c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                        c.cmd.Parameters.Add("@relig", SqlDbType.NVarChar).Value = txtreli.Text;

                        if (Radiomale.Checked == true)
                            gen = Radiomale.Text;
                        else
                            gen = radiofemale.Text;

                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                        c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                        c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                        c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                        c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                        c.cmd.Parameters.Add("@doj", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdoj.Text);
                        c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                        c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                        c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                        c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                        c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "active";
                        c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(txtda.Text);
                        c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(txthra.Text);
                        c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpf.Text);
                        c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                        c.cmd.ExecuteNonQuery();
                        Session["id"] = Label4.Text;
                        //MessageBox.Show("Saved");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                        //   btnsave.Enabled = false;

                        //Response.Redirect("~/c_lablog.aspx");

                        ddlemptype.ClearSelection();
                        Label4.Text = "";
                        ddlname.ClearSelection();
                        ddlname.SelectedItem.Text = "select";
                        txtname.Text = "";
                        ddlcare.SelectedItem.Text = "select";
                        ddlcare.ClearSelection();
                        txtcareof.Text = "";
                        txtaddress.Text = "";
                        txtdob.Text = "";
                        txtage.Text = "";
                        txtcity.Text = "";
                        txtstate.Text = "";
                        ddlbg.ClearSelection();
                        ddlbg.SelectedItem.Text = "select";
                        txtreli.Text = "";
                        radiofemale.Checked = false;
                        Radiomale.Checked = false;
                        Radioothers.Checked = false;
                        ddlms.ClearSelection();
                        ddlms.SelectedItem.Text = "select";
                        txtpin.Text = "";
                        txtmob.Text = "";
                        txtadhar.Text = "";
                        txtdoj.Text = "";
                        ddldept.ClearSelection();
                        ddldept.SelectedItem.Text = "select";
                        txtquli.Text = "";
                        txtcountry.Text = "";
                        txtbasic.Text = "";
                        txtda.Text = "";
                        txthra.Text = "";
                        txtpf.Text = "";

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        txtmob.Text = "";
                        txtemail.Text = "";
                        txtdist.Text = "";

                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
                else
                {
                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into empreg values(@emptype,@empid,@empndrp,@name,@empcdrp,@care,@address,@dob,@age,@city,@country,@state,@bloodgrp,@relig,@sex,@ms,@pin,@mob,@adhar,@doj,@department,@quali,@altmob,@email,@basic,@status,@da,@hra,@pf,@dist)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@emptype", SqlDbType.NVarChar).Value = ddlemptype.SelectedItem.Text;
                        c.cmd.Parameters.Add("@empid", SqlDbType.NVarChar).Value = Label4.Text;
                        c.cmd.Parameters.Add("@empndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                        c.cmd.Parameters.Add("@empcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                        c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                        c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                        c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdob.Text);
                        c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                        c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                        c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
                        c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                        c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                        c.cmd.Parameters.Add("@relig", SqlDbType.NVarChar).Value = txtreli.Text;

                        if (Radiomale.Checked == true)
                            gen = Radiomale.Text;
                        else
                            gen = radiofemale.Text;

                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                        c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                        c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                        c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                        c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                        c.cmd.Parameters.Add("@doj", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdoj.Text);
                        c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
                        c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                        c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                        c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                        c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "active";
                        c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(txtda.Text);
                        c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(txthra.Text);
                        c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpf.Text);
                        c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;
                        c.cmd.ExecuteNonQuery();
                        Session["id"] = Label4.Text;
                        //MessageBox.Show("Saved");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                        //   btnsave.Enabled = false;

                        Response.Redirect("~/c_userlog.aspx");

                        ddlemptype.ClearSelection();
                        Label4.Text = "";
                        ddlname.ClearSelection();
                        ddlname.SelectedItem.Text = "select";
                        txtname.Text = "";
                        ddlcare.SelectedItem.Text = "select";
                        ddlcare.ClearSelection();
                        txtcareof.Text = "";
                        txtaddress.Text = "";
                        txtdob.Text = "";
                        txtage.Text = "";
                        txtcity.Text = "";
                        txtstate.Text = "";
                        ddlbg.ClearSelection();
                        ddlbg.SelectedItem.Text = "select";
                        txtreli.Text = "";
                        radiofemale.Checked = false;
                        Radiomale.Checked = false;
                        Radioothers.Checked = false;
                        ddlms.ClearSelection();
                        ddlms.SelectedItem.Text = "select";
                        txtpin.Text = "";
                        txtmob.Text = "";
                        txtadhar.Text = "";
                        txtdoj.Text = "";
                        ddldept.ClearSelection();
                        ddldept.SelectedItem.Text = "select";
                        txtquli.Text = "";
                        txtcountry.Text = "";
                        txtbasic.Text = "";
                        txtda.Text = "";
                        txthra.Text = "";
                        txtpf.Text = "";

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        txtmob.Text = "";
                        txtemail.Text = "";
                        txtdist.Text = "";
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
            }
        }
    }
    protected void Calendar2_SelectionChanged(object sender, EventArgs e)
    {
        txtdoj.Text = Calendar2.SelectedDate.ToString("d");
        Calendar2.Visible = false;

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar2.Visible)
        {
            Calendar2.Visible = false;
        }
        else
        {
            Calendar2.Visible = true;
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtdob.Text = Calendar1.SelectedDate.ToString("d");

        DateTime dob = new DateTime();
        dob = Convert.ToDateTime(txtdob.Text);
        DateTime age = DateTime.Now;
        TimeSpan tspan = age - dob;
        double dayss = tspan.TotalDays;

        double ag = dayss / 365;
        if (ag < 18 || ag > 80)
        {
            //MessageBox.Show(" age should be btween 18-80");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Age Should Be Between 18-80!!!')</script>");
            txtdob.Text = "";
            txtage.Text = "";
            txtdoj.Text = "";


        }

        TimeSpan tspan1 = age - dob;
        double days = tspan.TotalDays;
        double age1 = days / 365;

        txtage.Text = age1.ToString("0");
        txtdoj.Text = today.ToString("d");




        Calendar1.Visible = false;
        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        Label1.Visible = false;
        Label2.Visible = false;


    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
        btnupdate.Enabled = true;
        try
        {
            string gen;
            DateTime da, db;
            c = new connect();
            c.cmd.CommandText = "select * from empreg where empid='" + TextBox1 .Text  + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "edit");
            if (ds.Tables["edit"].Rows.Count > 0)
            {
                Label4.Text = TextBox1.Text;
                btnupdate.Visible = true;
                btnsave.Visible = false;
                btnsearch.Visible = false;
                btnedit.Visible = false;
                TextBox2.Visible = false;
                TextBox1.Enabled = false ;
                for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                {
                    ddlemptype.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                    Label4.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[1]);

                    ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[2]);
                    txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                    ddlcare.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                    txtcareof.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                    txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);

                    da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[7]);
                    txtdob.Text = da.ToString("d");
                    txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                    txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                    txtcountry.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);
                    txtstate.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[11]);
                    ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);
                    string bg = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);
                    if (bg == "select")
                    {
                        ddlbg.Enabled = true;
                    }
                    else
                    {
                        ddlbg.Enabled = false;
                    }


                    txtreli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[13]);

                    gen = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);

                    if (gen == "male")
                    {
                        Radiomale.Checked = true;
                    }

                    else
                    {
                        radiofemale.Checked = true;
                    }

                    ddlms.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                    txtpin.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);
                    txtmob.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                    txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);
                    db = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[19]);
                    txtdoj.Text = db.ToString("d");
                    ddldept.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                    string dept = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                    if (dept == "select")
                    {

                        labeldept.Visible = false;
                        ddldept.Visible = false;
                       

                    }
                    else
                    {
                        labeldept.Visible = true;
                        ddldept.Visible = true;
                        ddldept.Enabled = false;


                    }
                    txtquli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                    altrnumber.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[22]);
                    txtemail.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[23]);
                    txtbasic.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                    txtda.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);
                    txthra.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[27]);
                    txtpf.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[28]);
                    txtdist .Text  = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[29]);

                }

                ddlemptype.Enabled = false;
                ddlname.Enabled = false;
                txtname.Enabled = false;
                ImageButton2.Enabled = false;
                Panel3.Enabled = false;
                txtquli.Enabled = false;
                txtcountry.Enabled = false;
                txtreli.Enabled = false;
                txtbasic.Enabled = false;
                

            }
            else
                //MessageBox.Show("record not found");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }

    }
    protected void btnupdate_Click1(object sender, EventArgs e)
    {
        try
        {
            c = new connect();
            c.cmd.CommandText = "update empreg set empcdrp=@empcdrp,care=@care,address=@address,city=@city,pin=@pin,state=@state,country=@country,mob=@mob,ms=@ms,quali=@quali,altmob=@altmob,email=@email where empid='" + TextBox1 .Text  + "'";
            c.cmd.Parameters.Clear();
            c.cmd.Parameters.Add("@empcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
            c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
            c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
            c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
            c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
            c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
            c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
            c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
            c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
            c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
            c.cmd.Parameters.Add("@department", SqlDbType.NVarChar).Value = ddldept.SelectedItem.Text;
            c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
            c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
            c.cmd.ExecuteNonQuery();
            //MessageBox.Show("record updated");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Updated!!!')</script>");

            ddlemptype.ClearSelection();
            Label4.Text = "";
            ddlname.ClearSelection();
            ddlname.SelectedItem.Text = "select";
            txtname.Text = "";
            ddlcare.SelectedItem.Text = "select";
            ddlcare.ClearSelection();
            txtcareof.Text = "";
            txtaddress.Text = "";
            txtdob.Text = "";
            txtage.Text = "";
            txtcity.Text = "";
            txtstate.Text = "";
            ddlbg.ClearSelection();
            ddlbg.SelectedItem.Text = "select";
            txtreli.Text = "";
            radiofemale.Checked = false;
            Radiomale.Checked = false;
            Radioothers.Checked = false;
            ddlms.ClearSelection();
            ddlms.SelectedItem.Text = "select";
            txtpin.Text = "";
            txtmob.Text = "";
            txtadhar.Text = "";
            txtdoj.Text = "";
            ddldept.ClearSelection();
            ddldept.SelectedItem.Text = "select";
            txtquli.Text = "";
            txtcountry.Text = "";
            txtbasic.Text = "";
            txtda.Text = "";
            txthra.Text = "";
            txtpf.Text = "";
            TextBox1.Text = "";
            TextBox2.Text = "";
            txtmob.Text = "";
            txtemail.Text = "";
            txtdist.Text = "";
            labeldept.Visible = true;
            ddldept.Visible = true;
            ddldept.Enabled = true;
            ddlbg.Enabled = true;
            ddlemptype.Enabled = true;
            ddlname.Enabled = true;
            txtname.Enabled = true;
            ImageButton2.Enabled = true;
            Panel3.Enabled = true;
            txtquli.Enabled = true;
            txtcountry.Enabled = true;
            txtreli.Enabled = true;
            txtbasic.Enabled = true;

            btnupdate.Visible = false ;
            btnsave.Visible = true ;
            btnsearch.Visible = true ;
            btnedit.Visible = true ;
            TextBox1.Enabled = true;
            TextBox2.Visible = true ;
                

            
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            string gen;
            DateTime da, db;
            c = new connect();
            c.cmd.CommandText = "select * from empreg where empid='" + TextBox2 .Text  + "'";

            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "edit");
            if (ds.Tables["edit"].Rows.Count > 0)
            {
                Label4.Text = TextBox2.Text;

                for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                {

                    ddlemptype.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);
                    Label4.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[1]);

                    ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[2]);
                    txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                    ddlcare.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                    txtcareof.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                    txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);

                    da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[7]);
                    txtdob.Text = da.ToString("d");
                    txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                    txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                    txtcountry.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);
                    txtstate.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[11]);
                    ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);
                    txtreli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[13]);

                    gen = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);

                    if (gen == "male")
                    {
                        Radiomale.Checked = true;
                    }

                    else
                    {
                        radiofemale.Checked = true;
                    }

                    ddlms.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                    txtpin.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);
                    txtmob.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                    txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[18]);
                    db = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[19]);
                    txtdoj.Text = db.ToString("d");
                    ddldept.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                    string dept1 = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                    if (dept1 == "select")
                    {

                        ddldept.Visible = false;
                        labeldept.Visible = false;
                       
                    }
                    else
                    {
                        ddldept.Visible = true;
                        labeldept.Visible = true;
                    }
                    txtquli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                    altrnumber.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[22]);
                    txtemail.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[23]);
                    txtbasic.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                    txtda.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]);
                    txthra.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);
                    txtpf.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[27]);
                    txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[29]);

                    
                }
                Panel1.Enabled = false;
                btnedit.Visible = false;
                btnsave.Visible = false;
                btnsearch.Visible = false;
                btnupdate.Visible = false;
                TextBox1.Visible =false ;
                TextBox2.Visible = false;
       
               
            }
            else
            {
                //MessageBox.Show("record not found");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                // Panel1.Enabled = true ;
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            Label1.Visible = false;
            Label2.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            Label1.Visible = true;
            Label2.Visible = true;

            DropDownList1.ClearSelection();
            DropDownList1.SelectedItem.Text = "1908";
            DropDownList2.ClearSelection();
            DropDownList2.SelectedItem.Text = "Janvary";

            Calendar1.VisibleDate = Convert.ToDateTime("January" + 1908);
        
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int year = Convert.ToInt16(DropDownList1.SelectedValue);
        int month = Convert.ToInt16(DropDownList2.SelectedValue);

        Calendar1.VisibleDate = new DateTime(year, month, 1);
        Calendar1.SelectedDate = new DateTime(year, month, 1);
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        int year = Convert.ToInt16(DropDownList1.SelectedValue);
        int month = Convert.ToInt16(DropDownList2.SelectedValue);

        Calendar1.VisibleDate = new DateTime(year, month, 1);
        Calendar1.SelectedDate = new DateTime(year, month, 1);
    }
    protected void btncal_Click(object sender, EventArgs e)
    {
        if (txtbasic.Text == " ")
        {
            //MessageBox.Show("enter basic amount");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Basic Salary Amount!!!')</script>");
        }
        else
        {

            double da, hra, pf;
            da = Convert.ToDouble(txtbasic.Text) * (65.0 / 100);
            hra = Convert.ToDouble(txtbasic.Text) * (20.0 / 100);
            pf = Convert.ToDouble(txtbasic.Text) * (15.0 / 100);
            txtda.Text = Convert.ToString(da);
            txthra.Text = Convert.ToString(hra);
            txtpf.Text = Convert.ToString(pf);
        }
    }


}
