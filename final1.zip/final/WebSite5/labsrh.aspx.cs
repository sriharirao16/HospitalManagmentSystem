using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class labsrh : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Patient Id!!!')</script>");
            //MessageBox.Show("plz ....enter patient ID");
            GridView1.Visible = false;
            Panel2.Visible = false;
        }
        else
        {


            try
            {

                c = new connect();
                c.cmd.CommandText = "select * from labdetails where pid='" + TextBox1.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "edit");
                if (ds.Tables["edit"].Rows.Count > 0)
                {
                    Panel2.Visible = true;
                    GridView1.Visible = true;
                    for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                    {
                        DateTime dt = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[1]);
                        Labeld.Text = dt.ToShortDateString();
                        Labelt.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[2]);
                        Labeln.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                        Labels.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);
                        Labela.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[6]);
                        Labelm.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);
                       

                    }
                    //c.cmd.CommandText = "select pid,test,charge from labdetails where pid='"+TextBox1 .Text+"'" ;
                    //adp.SelectCommand = c.cmd;
                    //ds = new DataSet();
                    //adp.Fill(ds, "edit");
                    //if (ds.Tables["edit"].Rows.Count > 0)
                    //{
                    //    GridView1.DataSource = ds.Tables["edit"];
                    //    GridView1.DataBind();
                    //}

                }
                else
                {
                    Panel2.Visible = false;
                    GridView1.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                    //MessageBox.Show("record not found");
                    TextBox1.Text = "";

                }
            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }
}
