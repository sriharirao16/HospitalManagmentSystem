using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class changepass : System.Web.UI.Page
{
    connect c;
    DataSet ds1;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.Visible = false;
    }
    protected void btnverfy_Click(object sender, EventArgs e)
    {
        if (txtold.Text == "")

            //MessageBox.Show("enter password");
            
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Password!!!')</script>");
        else
        {

            c = new connect();
            c.cmd.CommandText = "select * from changepass where password='" + txtold.Text + "' ";

            ds1 = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds1, "adm");
            if (ds1.Tables["adm"].Rows.Count > 0)
            {

                String s = Convert.ToString(ds1.Tables["adm"].Rows[0].ItemArray[1]);

                //MessageBox.Show("verified");

                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Verfied!!!')</script>");
                Panel1.Visible = true;
                txtold.Enabled = true;
                txtold.Text = s;

                txtnew.Enabled = true;
                txtconfim.Enabled = true;
                btnsub.Enabled = true;
                btnclear.Enabled = true;
                btnverfy.Enabled = false;


            }
            else
            {
                //MessageBox.Show("enter correct password");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Correct Password!!!')</script>");
                txtold.Text = "";
            }
        }
    }
    protected void btnsub_Click(object sender, EventArgs e)
    {
        if (txtold.Text == "" || txtnew.Text == "" || txtconfim.Text == "")
        {
            //MessageBox.Show("Enter all fields");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All the Password!!!')</script>");
        Panel1.Visible = true;
            //txtnew .Text ="";
        }
        else
        {
            if (txtnew.Text == txtconfim.Text)
            {
                try
                {

                    c = new connect();
                    c.cmd.CommandText = "insert into changepass values(@username,@passowrd,@npassword,@cpassword)";
                    c.cmd.Parameters.Add("@username", SqlDbType.NVarChar).Value = txtuser.Text;
                    c.cmd.Parameters.Add("@password", SqlDbType.NVarChar).Value = txtold.Text;
                    c.cmd.Parameters.Add("@npassword", SqlDbType.NVarChar).Value = txtnew.Text;
                    c.cmd.Parameters.Add("@cpassword", SqlDbType.NVarChar).Value = txtconfim.Text;
                    c.cmd.CommandText = "update changepass set password='" + txtconfim.Text + "'" + " where username='" + txtuser.Text + "'";
                    c.cmd.ExecuteNonQuery();
                    //MessageBox.Show("sucessfully changed");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Password Sucefukky Changed!!!')</script>");
                    Response.Redirect("~/logadmin.aspx");
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }
            else
            {


                //MessageBox.Show("password should be same");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Password Should Be Same!!!')</script>");
                txtnew .Text = "";
                
            }

        }
    }

    protected void btnclear_Click(object sender, EventArgs e)
    {
        txtnew.Text = "";
        txtconfim.Text = "";
    }

}
