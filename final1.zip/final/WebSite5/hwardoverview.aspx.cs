using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class hwardoverview : System.Web.UI.Page
{
    connect c;
    protected void Page_Load(object sender, EventArgs e)
    {
        c = new connect();
        c.cmd.CommandText = "select count(wardtype)from ward where wardtype='General'";
        int gt = Convert.ToInt16(c.cmd.ExecuteScalar());
        lblgt.Text = gt.ToString();
        //MessageBox.Show("total ward " + gt.ToString());
        c.cmd.CommandText = "select count(wardtype)from ward where status1='book' and wardtype='General'";
        int go = Convert.ToInt16(c.cmd.ExecuteScalar());
        lblgo.Text = go.ToString();
        //MessageBox.Show("total book " + go.ToString());
        double gper = (go * 100.0) / gt ;
        //MessageBox.Show(Convert.ToString(gper));
        Int64 g = Convert.ToUInt32(gper);
        //MessageBox.Show(g.ToString());
        lblgp .Text  = g.ToString() + "%";

        //SemiSpecial Ward
        c = new connect();
        c.cmd.CommandText = "select count(wardtype)from ward where wardtype='SemiSpecial Ward'";
        int sst = Convert.ToInt16(c.cmd.ExecuteScalar());
        lblsst.Text = sst.ToString();
        c.cmd.CommandText = "select count(wardtype)from ward where status1='book' and wardtype='SemiSpecial Ward'";
        int sso = Convert.ToInt16(c.cmd.ExecuteScalar());
        lblsso.Text = sso.ToString();
        double ssper = (sso * 100.0) / sst;
        Int64 ss = Convert.ToUInt32(ssper);
        lblssp.Text = ss.ToString() + "%";

        //Special Ward
        c = new connect();
        c.cmd.CommandText = "select count(wardtype)from ward where wardtype='SpecialWard'";
        int st = Convert.ToInt16(c.cmd.ExecuteScalar());
        lblst.Text = st.ToString();
        c.cmd.CommandText = "select count(wardtype)from ward where status1='book' and wardtype='SpecialWard'";
        int so = Convert.ToInt16(c.cmd.ExecuteScalar());
        lblso.Text = so.ToString();
        double sper = (so * 100.0) / st;
        Int64 s = Convert.ToUInt32(sper);
        lblsp.Text  = s.ToString() + "%";


        double tot,totp;
        tot = sper + ssper + gper;
        totp = (tot * 100) / 300;
        Int64 t = Convert.ToUInt32(totp);
        lbltot.Text = t.ToString()+ "% (Filled)";
    


    }
}
