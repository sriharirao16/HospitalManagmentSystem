using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
public partial class _Default : System.Web.UI.Page 
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/changepass.aspx");
    }
    protected void btnsub_Click(object sender, EventArgs e)
    {
        if (txtpassword.Text == "")
            //MessageBox.Show("Enter Password");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Password!!!')</script>");
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select username,password from changepass where username='" + txtuser.Text + "'" + "and password='" + txtpassword.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "ad");
                if (ds.Tables["ad"].Rows.Count > 0)
                {
                    //MessageBox.Show("Welcome....You are succesfully logged in..");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Welcome....You are Sucefully Logged in!!!')</script>");
                    Response.Redirect("~/admmodule.aspx");
                }
                else
                {
                    //MessageBox.Show("incorrect password");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Incorrec Password!!!')</script>");
                    txtpassword.Text = "";
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
    }
}
