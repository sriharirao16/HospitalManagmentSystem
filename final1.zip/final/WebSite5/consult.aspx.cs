using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
public partial class consult : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    DateTime opd;
    protected void Page_Load(object sender, EventArgs e)
    {
        DateTime today = DateTime.Now;
        txtdate.Text = today.ToString("d");

        txtslno.Enabled = true ;
        txtpname.Enabled = false  ;
        txtpid.Enabled = true ;
        txtfees.Enabled = false  ;
        txtdoc.Enabled = false  ;
        txtdept.Enabled = false  ;
        txtdate.Enabled = true ;
        txtcharges.Enabled =false  ;
        txtaddress.Enabled = false  ;
       
        if (!IsPostBack)
        {
            GenerateAutoID();
        }


    }
    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(slno)from concharges ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        txtslno .Text  =i.ToString();


    }





    protected void btnpaid_Click1(object sender, EventArgs e)
    { 
        c =new connect ();
        c.cmd.CommandText = "select * from concharges where pid='" + txtpid.Text + "' and date='"+txtdate .Text +"'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "con");
                if (ds.Tables["con"].Rows.Count > 0)
                {
                    //MessageBox.Show("record already exist");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already Exist!!!')</script>");
                    txtpid.Text = "";
                    txtslno.Text = "";
                    txtaddress.Text = "";
                    txtcharges.Text = "";
                    txtdate.Text = "";
                    txtpid.Text = "";
                    txtpname.Text = "";
                    txtslno.Text = "";
                    txtfees.Text = "";
                    txtdept.Text = "";
                    txtdoc.Text = "";
                }
                else
                {
                    //MessageBox.Show("record doesnot exist");
                    txtslno.Enabled = false;
                    txtpname.Enabled = false;
                    txtpid.Enabled = false;
                    txtfees.Enabled = false;
                    txtdoc.Enabled = false;
                    txtdept.Enabled = false;
                    txtdate.Enabled = false;
                    txtcharges.Enabled = false;
                    txtaddress.Enabled = false;
                    txtfees.Enabled = false;


                    try
            {
                c = new connect();
                c.cmd.CommandText = "insert into concharges values(@slno,@date,@pid,@name,@address,@dept,@docter,@charge,@admfees)";
                c.cmd.Parameters.Clear();
                c.cmd.Parameters.Add("@slno", SqlDbType.Decimal ).Value = Convert .ToDecimal (txtslno .Text );
                c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = txtdate.Text;
                c.cmd.Parameters.Add("@pid", SqlDbType.NVarChar ).Value = txtpid .Text ;
                c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtpname .Text ;
                c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress .Text ;
                c.cmd.Parameters.Add("@dept", SqlDbType.NVarChar).Value = txtdept.Text;
                c.cmd.Parameters.Add("@docter", SqlDbType.NVarChar).Value = txtdoc .Text ;
                c.cmd.Parameters.Add("@charge", SqlDbType.Decimal ).Value =Convert .ToDecimal ( txtcharges .Text) ;
                c.cmd.Parameters.Add("@admfees", SqlDbType.Decimal ).Value = Convert .ToDecimal (txtfees .Text );                              
                c.cmd.ExecuteNonQuery();
                //MessageBox.Show("Saved");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

                }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        if (txtpid.Text == "")
        {
            //MessageBox.Show("enter op no.first");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Op Number First!!!')</script>");
        }
        else
        {
            try
            {
                string dept;
                DateTime da;
                c = new connect();
                int ch, f;
                ch = 250;
                f = 50;
                c.cmd.CommandText = "select * from opreg where opno='" + txtpid.Text + "'";

                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "con");
                if (ds.Tables["con"].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables["con"].Rows.Count - 1; i++)
                    {
                        txtaddress.Text = Convert.ToString(ds.Tables["con"].Rows[i].ItemArray[7]);
                        da = Convert.ToDateTime(ds.Tables["con"].Rows[i].ItemArray[1]);
                        txtpname.Text = Convert.ToString(ds.Tables["con"].Rows[i].ItemArray[4]);
                        txtdept.Text = Convert.ToString(ds.Tables["con"].Rows[i].ItemArray[18]);
                        dept = Convert.ToString(ds.Tables["con"].Rows[i].ItemArray[18]);
                        
                        txtdoc.Text = Convert.ToString(ds.Tables["con"].Rows[i].ItemArray[17]);

                        txtcharges.Text = ch.ToString ();
                        txtfees.Text = f.ToString();
                    }
                }
                else
                   // MessageBox.Show("record not found");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }
    protected void btnnew_Click1(object sender, EventArgs e)
    {

        txtaddress.Text = "";
        txtcharges.Text = "";
        txtdate.Text = "";
        txtpid.Text = "";
        txtpname.Text = "";
        txtslno.Text = "";
        txtfees.Text = "";
        txtdept.Text = "";
        txtdoc.Text = "";
        GenerateAutoID();
    }

}
