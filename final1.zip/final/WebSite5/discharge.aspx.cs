using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class discharge : System.Web.UI.Page

{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    DateTime dt;
    decimal bcharge, total;

    protected void Page_Load(object sender, EventArgs e)
    {
        txtaddress.Enabled = false;
        txtage.Enabled = false;
        txtpname.Enabled = false;
        txtsex.Enabled = false;
        txtdoa.Enabled = false;
        txtdod.Enabled = false;
        txtopno.Enabled = false;
        txtdate.Enabled = false;
        if (!IsPostBack)
        {
            GenerateAutoID();
        }
       
        

    }
    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(slno)from discharge ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        txtslno.Text=  i.ToString();
    }
 


    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        if (txtipno.Text == "" ||txtslno .Text =="")
        {
            //MessageBox.Show("enter ImPatient Id ....check slno");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter IP Id.... & Check Slno!!!')</script>");
            txtipno.Focus();
        }
        else
        {
              c = new connect();
                c.cmd.CommandText = "select * from ipdoc where ipno='" + txtipno.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "dis");
                if (ds.Tables["dis"].Rows.Count > 0)
                {


                    try
                    {
                        c = new connect();
                        c.cmd.CommandText = "select * from ipreg where ipno='" + txtipno.Text + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "dis");
                        if (ds.Tables["dis"].Rows.Count > 0)
                        {
                            for (int i = 0; i <= ds.Tables["dis"].Rows.Count - 1; i++)
                            {
                                txtipno.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[1]);
                                txtpname.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[5]);
                                dt = Convert.ToDateTime(ds.Tables["dis"].Rows[i].ItemArray[2]);
                                txtdoa.Text = dt.ToString("d");
                                txtopno.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[0]);
                                txtaddress.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[8]);
                                //txtdod .Text =
                                //txtdate .Text =
                                txtage.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[18]);
                                txtsex.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[17]);
                                txtdoc.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[22]);
                                DateTime today = DateTime.Now;
                                txtdate.Text = today.ToString("d");
                                txtdod.Text = today.ToString("d");
                            }
                        }
                        else
                        {
                            //MessageBox.Show("does not Exist");
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter REcord Does Not Exist!!!')</script>");
                            txtipno.Text = "";
                        }

                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
                else
                {
                    //MessageBox.Show("first fill doctor consult  charge");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('First Fill The Doctor Consult Charge!!!')</script>");
                }

        }
    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        txtaddress.Text = "";
        txtage.Text = "";
        txtcor.Text = "";
        txtda.Text = "";
        txtdaod.Text = "";
        txtdate.Text = "";
        txtdoa.Text = "";
        txtdoc.Text = "";
        txtdod.Text = "";
        txtfaod.Text = "";
        txtfdia.Text = "";
        txtipno.Text = "";
        txtopno.Text = "";
        txtpasthis.Text = "";
        txtpname.Text = "";
        txtsex.Text = "";
        txtslno.Text = "";
      
        
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
          try
            {
                c = new connect();
                c.cmd.CommandText = "select * from discharge where ipno='" + txtipno.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "dis");
                if (ds.Tables["dis"].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables["dis"].Rows.Count - 1; i++)
                    {
                        txtslno .Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[0]);
                        txtipno.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[1]);
                        txtpname.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[2]);
                        dt = Convert.ToDateTime(ds.Tables["dis"].Rows[i].ItemArray[3]);
                        txtdoa.Text = dt.ToString("d");
                        txtopno.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[4]);
                        txtaddress.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[5]);
                        //txtdod .Text =
                        //txtdate .Text =
                        txtage.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[8]);
                        txtsex.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[9]);
                        txtfdia .Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[10]);
                        txtcor.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[11]);
                        txtpasthis.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[12]);
                        txtdaod.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[13]);
                        txtfaod.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[14]);
                        txtda.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[15]);
                        txtdoc.Text = Convert.ToString(ds.Tables["dis"].Rows[i].ItemArray[16]);

                    }
                }
                else
                    //MessageBox.Show("enter im Patient Id");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Ip ID!!!')</script>");
            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (txtfdia .Text  == "" || txtcor .Text  == "" || txtpasthis .Text  == "" || txtdaod .Text  == "" || txtfaod .Text  == "" || txtda .Text  == "" || txtdoc .Text  == "" ||txtslno .Text =="") 
        {
            //MessageBox.Show("enter all fields");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter The All The Fields!!!')</script>");
        }
        else
        {
                c = new connect();
                c.cmd.CommandText = "select * from discharge where ipno='" + txtipno.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "dis");
                if (ds.Tables["dis"].Rows.Count > 0)
                {
                    //MessageBox.Show("record already used");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already Done!!!')</script>");
                    txtopno.Text = "";
                    txtipno.Text = "";
                    txtslno.Text = "";
                    txtpname.Text = "";
                    txtdoa.Text = "";
                    txtaddress.Text = "";
                    txtdod.Text = "";
                    txtdate.Text = "";
                    txtage.Text = "";
                    txtsex.Text = "";
                    txtfdia.Text = "";
                    txtcor.Text = "";
                    txtpasthis.Text = "";
                    txtdaod.Text = "";
                    txtfaod.Text = "";
                    txtda.Text = "";
                    txtdoc.Text = "";
                }
                else
                {
                    try
                    {

                        c = new connect();
                        c.cmd.CommandText = "insert into discharge values(@slno,@ipno,@name,@doadm,@opno,@address,@dateofd,@date,@age,@sex,@fd,@cor,@ph,@daod,@faod,@da,@doc)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@slno", SqlDbType.Decimal).Value = Convert.ToDecimal(txtslno.Text);
                        c.cmd.Parameters.Add("@ipno", SqlDbType.NVarChar).Value = txtipno.Text;
                        c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtpname.Text;
                        c.cmd.Parameters.Add("@doadm", SqlDbType.DateTime).Value = txtdoa.Text;
                        c.cmd.Parameters.Add("@opno", SqlDbType.NVarChar).Value = txtopno.Text;
                        c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                        c.cmd.Parameters.Add("@dateofd", SqlDbType.DateTime).Value = txtdod.Text;
                        c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = txtdate.Text;
                        c.cmd.Parameters.Add("@age", SqlDbType.Decimal).Value = Convert.ToDecimal(txtage.Text);
                        c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = txtsex.Text;
                        c.cmd.Parameters.Add("@fd", SqlDbType.NVarChar).Value = txtfdia.Text;
                        c.cmd.Parameters.Add("@cor", SqlDbType.NVarChar).Value = txtcor.Text;
                        c.cmd.Parameters.Add("@ph", SqlDbType.NVarChar).Value = txtpasthis.Text;
                        c.cmd.Parameters.Add("@daod", SqlDbType.NVarChar).Value = txtdaod.Text;
                        c.cmd.Parameters.Add("@faod", SqlDbType.NVarChar).Value = txtfaod.Text;
                        c.cmd.Parameters.Add("@da", SqlDbType.NVarChar).Value = txtda.Text;
                        c.cmd.Parameters.Add("@doc", SqlDbType.NVarChar).Value = txtdoc.Text;
                        c.cmd.ExecuteNonQuery();
                        //MessageBox.Show("Saved");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Record Saved!!!')</script>");










                         c = new connect();
                        c.cmd.CommandText = "select * from bedshift where ipno='" + txtipno.Text + "'";
                        ds = new DataSet();
                        adp.SelectCommand = c.cmd;
                        adp.Fill(ds, "bed");
                        if (ds.Tables["bed"].Rows.Count > 0)
                        {
                           
                            for (int i = 0; i <= ds.Tables["bed"].Rows.Count - 1; i++)
                            {

                                Session["bedno"] = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[4]);
                                Session["adm"] = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[6]);
                                Session["bedc"] = Convert.ToString(ds.Tables["bed"].Rows[i].ItemArray[5]);
                            }
                            c = new connect();
                            c.cmd.CommandText = "update bedshift set edate=@edate,totdays=@totdays,tot=@tot where ipno='" + txtipno.Text + "'";
                            c.cmd.Parameters.Clear();
                            
                            DateTime dic=DateTime .Now ;
                            c.cmd.Parameters.Add("@edate", SqlDbType.DateTime).Value = dic ;
                            DateTime admit = new DateTime();
                            admit = Convert.ToDateTime((String)Session["adm"]); 
                            DateTime disch = DateTime.Now;
                            TimeSpan tspan = disch - admit;
                            double dayss = tspan.TotalDays;
                            c.cmd.Parameters.Add("@totdays", SqlDbType.Decimal).Value = Convert .ToDecimal (dayss ) ;
                            decimal day = Convert.ToDecimal(dayss.ToString("0"));
                            bcharge = Convert.ToDecimal((String)Session["bedc"]);
                            total = bcharge * day;
                            c.cmd.Parameters.Add("@tot", SqlDbType.Decimal).Value =Convert.ToDecimal(total);
                            c.cmd.ExecuteNonQuery();
                            c.cmd.CommandText = "update ward set status1=@status1 where bedno='" + (String)Session["bedno"] + "'";
                            c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "Open";

                            c.cmd.ExecuteNonQuery();
                            //MessageBox.Show("inserted");
                        }

                        
        















                        txtopno.Text = "";
                        txtipno.Text = "";
                        txtslno.Text = "";
                        txtpname.Text = "";
                        txtdoa.Text = "";
                        txtaddress.Text = "";
                        txtdod.Text = "";
                        txtdate.Text = "";
                        txtage.Text = "";
                        txtsex.Text = "";
                        txtfdia.Text = "";
                        txtcor.Text = "";
                        txtpasthis.Text = "";
                        txtdaod.Text = "";
                        txtfaod.Text = "";
                        txtda.Text = "";
                        txtdoc.Text = "";

                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }
         }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        GenerateAutoID();
    }
}
