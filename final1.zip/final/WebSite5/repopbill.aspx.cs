using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class repopbill : System.Web.UI.Page
{ 
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        txtmbl.Text = "";
        txtage.Text = "";
        txtbill.Text = "";
        txtdate.Text = "";
        txtname.Text = "";
        txtopno.Text = "";
        txtsex.Text = "";
        txtopno.Focus();

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
            c = new connect();
            c.cmd.CommandText = "select opno,name,date,mbl,age,sex,total from labopb where opno='" + txtopno .Text  + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "print");
            if (ds.Tables["print"].Rows.Count > 0)
            {
                for (int i = 0; i <= ds.Tables["print"].Rows.Count - 1; i++)
                {
                    txtname.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[1]);
                    DateTime dt = Convert.ToDateTime(ds.Tables["print"].Rows[i].ItemArray[2]);
                    txtdate.Text = dt.ToShortDateString();
                    txtmbl.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[3]);
                    txtage.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[4]);
                    txtsex.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[5]);
                    txtbill.Text = Convert.ToString(ds.Tables["print"].Rows[i].ItemArray[6]);
                }
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Id Does Not Exist!!!')</script>");
                txtopno.Text = "";
                txtopno.Focus();
            }
             
    }
   
}
