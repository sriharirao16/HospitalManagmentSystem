using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
public partial class stafflogin : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    static int attemptcount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            String pass = txtpass.Text ;
            txtpass.Attributes.Add("value", pass);
        }
    }
    protected void btnsign_Click(object sender, EventArgs e)
    {
        
         if (txtuser.Text  == "" || txtpass.Text  == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter User Id & Password For Login!!!')</script>");
            //MessageBox.Show("Enter userid and password to login");
            txtpass.Text  = "";
            txtuser.Text  = "";
        }
        else
        {
            try
                {
                    c = new connect();
                    c.cmd.CommandText = "select * from userlog where empid='" + txtuser.Text  + "'and status1='active'";
                        
                ds = new DataSet();
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "user");


                   String uname, pass, status;
                   if (ds.Tables["user"].Rows.Count > 0)
                   {
                       uname = ds.Tables["user"].Rows[0].ItemArray[0].ToString();
                       pass = ds.Tables["user"].Rows[0].ItemArray[1].ToString();
                       status = ds.Tables["user"].Rows[0].ItemArray[2].ToString();
                       if (status == "active")
                       {
                           if (uname == txtuser.Text && pass == txtpass.Text)
                           {

                               //c = new connect();
                               //c.cmd.CommandText = "update userlog set newpass=@newpass where empid='" + txtuserid.Text + "'";
                               //c.cmd.Parameters.Clear();
                               //c.cmd.Parameters.Add("@new", SqlDbType.NVarChar).Value = "lock";
                               //c.cmd.ExecuteNonQuery();
                


                               Session["usern"] = uname;
                               attemptcount = 0;
                               Response.Redirect("~/Default2.aspx");
                           }
                           else
                           {
                               //int n = 2 - attemptcount;
                               //Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Invalid Username or Password - Relogin with Correct Username Password- No. of Attemps Remaining !!! & n' )</script>");
                               MessageBox.Show("Invalid Username or Password - Relogin with Correct Username Password- No. of Attemps Remaining : " + (2 - attemptcount)); 
                            
                            //   MessageBox.Show("Invalid Username or Password - Relogin with Correct Username Password- No. of Attemps Remaining : "+(2 - attemptcount));
                               attemptcount = attemptcount + 1;

                           }
                       }
                       else
                       {
                           //MessageBox.Show("Your Account Locked Already : Contact Administrator");
                           Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Your Account Already Locked : Contact Hr !!!')</script>");
                       }
                       if (attemptcount == 3)
                       {
                           Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Your Account Has Been Locked Due to Three Invalid Attempts - Contact Administrator!!!')</script>");
                           //MessageBox.Show("Your Account Has Been Locked Due to Three Invalid Attempts - Contact Administrator");
                          //setlockstatus(txtuserid . Text);


                          
                           attemptcount = 0;

                           try
            {

                  c = new connect();
                  c.cmd.CommandText = "update userlog set status1=@status1 where empid='" + txtuser.Text   + "'";
                  c.cmd.Parameters.Clear();
                c.cmd.Parameters.Add("@status1", SqlDbType.NVarChar).Value = "lock" ;
                c.cmd.ExecuteNonQuery();
                //MessageBox.Show("lock");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Lock!!!')</script>");

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
            
   }
  }
                   else
      Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('User Id Does Not Exist!!!')</script>");
                       //MessageBox.Show("user id does not exist");

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    c.cnn.Close();
                }
            }

        }

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        
        if (CheckBox1.Checked == false)
            txtpass.TextMode = TextBoxMode.Password;
        if (CheckBox1.Checked == true)
            txtpass.TextMode = TextBoxMode.SingleLine; 
    }
    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/first.aspx");
    }
}

