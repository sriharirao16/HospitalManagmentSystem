using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class recenq : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false; 
        txtage.Text = "";
        txtbedno.Text = "";
        txtcare.Text = "";
        txtdept.Text = "";
        txtdoc.Text = "";
        txtipid.Text = "";
        txtname.Text = "";
        txtsex.Text = "";
        txtward.Text = "";
        txtwardno.Text = "";
        txtname.Text = "";
        txtname.Focus();
        DropDownList2.Items.Clear();
        DropDownList2.Items.Add("select");
        txtadrs.Text = "";
        txtname.Text = "";
        txtname.Focus();
       
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtname.Text == "" || DropDownList2.SelectedItem.Text == "select")
        {
            //MessageBox.Show("Enter Name First and select ip");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter Name first & Select Ip!!!')</script>");
        }
        else
        {
            c = new connect();
            c.cmd.CommandText = "select * from ipbill where ipno='" + DropDownList2 .SelectedItem .Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "ip");
            if (ds.Tables["ip"].Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Bill already Paid!!!')</script>");
                //MessageBox.Show("Bill Already Paid");
                txtage.Text = "";
                txtbedno.Text = "";
                txtcare.Text = "";
                txtdept.Text = "";
                txtdoc.Text = "";
                txtipid.Text = "";
                txtname.Text = "";
                txtsex.Text = "";
                txtward.Text = "";
                txtwardno.Text = "";
                txtname.Text = "";
                DropDownList2.Items.Clear();
                DropDownList2.Items.Add("select");
                txtadrs.Text = "";
                Panel1.Visible = false;
                txtname.Focus();
            }

            else
            {
                c = new connect();
                c.cmd.CommandText = "select * from ipreg where ipname='" + txtname.Text + "' and ipno='" + DropDownList2.SelectedItem.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;

                adp.Fill(ds, "ip");
                if (ds.Tables["ip"].Rows.Count > 0)
                {
                    Panel1.Visible = true;

                    for (int i = 0; i <= ds.Tables["ip"].Rows.Count - 1; i++)
                    {

                        txtipid.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[1]);
                        txtcare.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[7]);
                        txtadrs.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[8]);
                        txtsex.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[17]);
                        txtage.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[18]);
                        txtward.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[23]);
                        txtwardno.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[24]);
                        txtbedno.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[25]);
                        txtdoc.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[22]);
                        txtdept.Text = Convert.ToString(ds.Tables["ip"].Rows[i].ItemArray[19]);
                    }


                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Name Does Not Exist!!!')</script>");
                    //MessageBox.Show("Name Does Not Exist");
                   
                }

            }

            
        }

        
    }
    protected void btndis_Click(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string dd;
        c = new connect();
        c.cmd.CommandText = "select * from ipreg where ipname='" + txtname.Text + "'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;

        adp.Fill(ds, "doc");
        if (ds.Tables["doc"].Rows.Count > 0)
        {

            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("select");

            for (int i = 0; i <= ds.Tables["doc"].Rows.Count - 1; i++)
            {
                dd = Convert.ToString(ds.Tables["doc"].Rows[i].ItemArray[1]);

                DropDownList2.Items.Add(dd);


            }
        }

    }
}
