using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class payslip : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    string payslp = "PAYID10";
    protected void Page_Load(object sender, EventArgs e)
    {

        // Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('!!!')</script>");
           

        if (!IsPostBack)
        {
            GenerateAutoID();
        }

    }
    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(payslipid)from payslip";
        int i = Convert.ToInt16(c.cmd.ExecuteScalar());
        i++;
        Label1.Text = payslp + i.ToString();


    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        c = new connect();
        c.cmd.CommandText = "select * from attendence where empid='" + TextBox1.Text + "'and month(date)='" + DateTime.Now.Month.ToString() + "' and year(date)='" + DateTime.Now.Year.ToString() + "'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;
        adp.Fill(ds, "e");
        if (ds.Tables["e"].Rows.Count > 0)
        {
            LinkButton1.Visible = false;
            GenerateAutoID();
            Panel1.Visible = true;
            GridView1.Visible = false;
            Button1.Enabled = true;

            try
            {
                c = new connect();
                c.cmd.CommandText = "select * from empreg where empid='" + TextBox1.Text + "'and status='active'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "emp");
                if (ds.Tables["emp"].Rows.Count > 0)
                {

                    LinkButton1.Visible = false;

                    Label2.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[3]);
                    Label3.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[0]);
                    Label5.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[23]);
                    Label4.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[17]);
                    Label6.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[6]);
                    Label15.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[24]);
                    Label16.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[26]);
                    Label17.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[27]);
                    Label18.Text = Convert.ToString(ds.Tables["emp"].Rows[0].ItemArray[28]);

                    c.cmd.CommandText = "select * from attendence where empid='" + TextBox1.Text + "'";
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "e");
                    if (ds.Tables["e"].Rows.Count > 0)
                    {
                        Label10.Text = DateTime.Today.ToShortDateString();
                        Label8.Text = Convert.ToString(ds.Tables["e"].Rows[0].ItemArray[4]);
                        Label14.Text = Convert.ToString(ds.Tables["e"].Rows[0].ItemArray[9]);
                        Label12.Text = Convert.ToString(ds.Tables["e"].Rows[0].ItemArray[7]);
                        Label13.Text = Convert.ToString(ds.Tables["e"].Rows[0].ItemArray[8]);
                        Label11.Text = Convert.ToString(ds.Tables["e"].Rows[0].ItemArray[5]);
                        Label7.Text = Convert.ToString(ds.Tables["e"].Rows[0].ItemArray[3]);

                    }

                    long totsal, da, hra, pf, lt, xleave, deduct = 0, days, fsal, n = 0, tl = 0, tlt = 0, wd;
                    lt = Convert.ToInt64(Label12.Text);
                    wd = Convert.ToInt64(Label14.Text);
                    xleave = Convert.ToInt64(Label13.Text);
                    da = Convert.ToInt64(Label16.Text);
                    hra = Convert.ToInt64(Label17.Text);
                    pf = Convert.ToInt64(Label18.Text);
                    days = Convert.ToInt64(Label11.Text);
                    totsal = Convert.ToInt64(Label15.Text) + da + hra - pf;
                    n = totsal / days;
                    fsal = n * wd;
                    //deduct = xleave * n;
                    //tl = (lt - xleave) ;
                    //tlt = (4 - tl ) * n;                            
                    //fsal = totsal - deduct;
                    Label9.Text = Convert.ToString(fsal);

                }

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }

        }
        else
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
            //MessageBox.Show("record Not FounD");
            TextBox1.Text = "";
            Label1.Text = "";
            Label2.Text = "";
            Label3.Text = "";
            Label4.Text = "";
            Label5.Text = "";
            Label6.Text = "";
            Label7.Text = "";
            Label8.Text = "";
            Label9.Text = "";
            Label10.Text = "";
            Label11.Text = "";
            Label12.Text = "";
            Label13.Text = "";
            Label14.Text = "";
            Label15.Text = "";
            Label16.Text = "";
            Label17.Text = "";
            Label18.Text = "";


            TextBox1.Focus();
            Panel1.Visible = false;
            Button1.Enabled = true;
            LinkButton1.Visible = true;
            GridView1.Visible = false;


        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        LinkButton1.Visible = true;
        TextBox1.Text = "";
        Label1.Text = "-";
        Label2.Text = "-";
        Label3.Text = "-";
        Label4.Text = "-";
        Label5.Text = "-";
        Label6.Text = "-";
        Label7.Text = "-";
        Label8.Text = "-";
        Label9.Text = "-";
        Label10.Text = "-";
        Label11.Text = "-";
        Label12.Text = "-";
        Label13.Text = "-";
        Label14.Text = "-";
        Label15.Text = "-";
        Label16.Text = "-";
        Label17.Text = "-";
        Label18.Text = "-";
        LinkButton1.Visible = true;
        Button1.Enabled = true;
        Panel1.Visible = false;
        GridView1.Visible = false;


    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        c = new connect();
        c.cmd.CommandText = "select * from payslip where empid='" + TextBox1.Text + "'and  year='" + Label8.Text + "' and month(date)='" + DateTime.Now.Month.ToString() + "'";
        ds = new DataSet();
        adp.SelectCommand = c.cmd;
        adp.Fill(ds, "p");
        if (ds.Tables["p"].Rows.Count > 0)
        {
            //MessageBox.Show("Payslip already is given");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Payslip Already Given!!!')</script>");
            TextBox1.Text = "";
            Label1.Text = "-";
            Label2.Text = "-";
            Label3.Text = "-";
            Label4.Text = "-";
            Label5.Text = "-";
            Label6.Text = "-";
            Label7.Text = "-";
            Label8.Text = "-";
            Label9.Text = "-";
            Label10.Text = "-";
            Label11.Text = "-";
            Label12.Text = "-";
            Label13.Text = "-";
            Label14.Text = "-";
            Label15.Text = "-";
            Label16.Text = "-";
            Label17.Text = "-";
            Label18.Text = "-";
            TextBox1.Focus();
            Panel1.Visible = false;
            Button1.Enabled = true;
            LinkButton1.Visible = true;
            GridView1.Visible = false;
           

        }
        else
        {

            try
            {

                c.cmd.CommandText = "insert into payslip values(@payslipid,@empid,@name,@desig,@phone,@email,@address,@leavetaken,@date,@month,@year,@basic,@da,@hra,@pf,@totalsalary)";
                c.cmd.Parameters.Add("@payslipid", SqlDbType.NVarChar).Value = Label1.Text;
                c.cmd.Parameters.Add("@empid", SqlDbType.NVarChar).Value = TextBox1.Text;
                c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = Label2.Text;
                c.cmd.Parameters.Add("@desig", SqlDbType.NVarChar).Value = Label3.Text;
                c.cmd.Parameters.Add("@phone", SqlDbType.Decimal).Value = Convert.ToDecimal(Label4.Text);
                c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = Label5.Text;
                c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = Label6.Text;
                c.cmd.Parameters.Add("@leavetaken", SqlDbType.NVarChar).Value = Label12.Text;
                c.cmd.Parameters.Add("@date", SqlDbType.DateTime).Value = Label10.Text;
                c.cmd.Parameters.Add("@month", SqlDbType.NVarChar).Value = Label7.Text;
                c.cmd.Parameters.Add("@year", SqlDbType.NVarChar).Value = Label8.Text;
                c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(Label15.Text);
                c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(Label16.Text);
                c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(Label17.Text);
                c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(Label18.Text);
                c.cmd.Parameters.Add("@totalsalary", SqlDbType.Decimal).Value = Convert.ToDecimal(Label9.Text);
                c.cmd.ExecuteNonQuery();
                //MessageBox.Show("Employ payslip generated");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Employee Payslip Generated!!!')</script>");
                c.cmd.CommandText = "select empid,name,desig,month,year,totalsalary from payslip where empid='" + TextBox1.Text + "'and date='" + Label10.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "p");
                if (ds.Tables["p"].Rows.Count > 0)
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = ds.Tables["p"];
                    GridView1.DataBind();
                }
                Button1.Enabled = false;
                LinkButton1.Visible = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }


    }

}
