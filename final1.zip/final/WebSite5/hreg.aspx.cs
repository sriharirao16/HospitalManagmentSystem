using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class hreg : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    String hrno = "hr";

    DateTime today = DateTime.Now;
    protected void Page_Load(object sender, EventArgs e)
    {
        ImageButton1.Visible = false;
        MaintainScrollPositionOnPostBack = true;
        txtage.Enabled = false;
        txtdob.Enabled = false;
        txtdoj.Enabled = false;

        labeldate . Text = today.ToString("d");
        lbltime.Text = today.ToString("t");
        if (!IsPostBack)
        {
            GenerateAutoID();
        }

        if (!IsPostBack)
        {
            Calendar1.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            Label1.Visible = false;
            Label2.Visible = false;

            LoadYears();
            LoadMonths();
        }

    }

    private void LoadMonths()
    {

        DataSet dsMonths = new DataSet();
        dsMonths.ReadXml(Server.MapPath("~/Month.xml"));

        DropDownList2.DataTextField = "Name";
        DropDownList2.DataValueField = "Number";


        DropDownList2.DataSource = dsMonths;
        DropDownList2.DataBind();

    }


    private void LoadYears()
    {

        DataSet dsYears = new DataSet();
        dsYears.ReadXml(Server.MapPath("~/Years.xml"));

        DropDownList1.DataTextField = "Number";
        DropDownList1.DataValueField = "Number";


        DropDownList1.DataSource = dsYears;
        DropDownList1.DataBind();
    }

    private void GenerateAutoID()
    {

        c = new connect();

        c.cmd.CommandText = "select count(hrid)from hrreg ";


        int i = Convert.ToInt32(c.cmd.ExecuteScalar());
        c.cnn.Close();
        i++;
        Session["no"] = i.ToString();
        lblhrid . Text  = hrno + (String)Session["no"];


    }
    protected void btnnew_Click1(object sender, EventArgs e)
    {
        txtaddress.Text = "";
        txtadhar.Text = "";
        txtage.Text = "";
        txtbasic.Text = "";
        txtcareof.Text = "";
        txtcity.Text = "";
        txtcountry.Text = "";
        txtda.Text = "";
        txtdist.Text = "";
        txtdob.Text = "";
        txtdoj.Text = "";
        txtemail.Text = "";
        lblhrid.Text = "-";
        txthra.Text = "";
        txtmob.Text = "";
        txtname.Text = "";
        txtpf.Text = "";
        txtpin.Text = "";
        txtquli.Text = "";
        txtreli.Text = "";
        txtstate.Text = "";
        ddlcare.ClearSelection();
        ddlcare.SelectedItem.Text = "select";
        ddlname.ClearSelection();
        ddlname.SelectedItem.Text = "select";
        ddlms.ClearSelection();
        ddlms.SelectedItem.Text = "select";
        ddlbg.ClearSelection();
        ddlbg.SelectedItem.Text = "select";
        ddlbg.ClearSelection();
        ddlbg.SelectedItem.Text = "select";
        radiofemale.Checked = false;
        Radiomale.Checked = false;
        altrnumber.Text = "";
        hrid2.Text = "";
        hrid1.Text = "";
        GenerateAutoID(); 
        txtname.Enabled = true;
        ddlname.Enabled = true;
        ImageButton2.Enabled = true;
        Panel3.Enabled = true;
        txtquli.Enabled = true;
        txtcountry.Enabled = true;
        txtadhar.Enabled = true;
        ddlbg.Enabled = true;
        txtreli.Enabled = true;
        btncal.Visible = true;
        btncal.Enabled = true;
        btnupdate.Visible = false ;
        btnedit.Visible = true ;
        hrid1.Enabled = true ;
        hrid2.Visible = true;
        btnsearch.Visible = true ;

        Panel4.Visible = true ;
        Panel1.Enabled = true ;
        btnsave.Visible = true ;

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        string gen;
        if (ddlname.SelectedItem.Text == "select" || txtname.Text == "" || ddlcare.SelectedItem.Text == "select" || txtcareof.Text == "" || txtaddress.Text == "" || txtdob.Text == "" || txtcity.Text == "" || txtstate.Text == "" || ddlbg.SelectedItem.Text == "select" || txtreli.Text == "" || radiofemale.Checked == false && Radiomale.Checked == false  || ddlms.SelectedItem.Text == "select" || txtpin.Text == "" || txtmob.Text == "" || txtadhar.Text == "" || txtdoj.Text == "" || txtquli.Text == "" || txtcountry.Text == "" || txtbasic.Text == "" || txtdist.Text == "")

        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter All The Fields!!!')</script>");
            //MessageBox.Show("enter all fields");
        }
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "insert into hrreg values(@hrid,@hrndrp,@name,@hrcdrp,@care,@address,@dob,@age,@city,@country,@state,@bloodgrp,@relig,@sex,@ms,@pin,@mob,@adhar,@doj,@quali,@altmob,@email,@basic,@status,@da,@hra,@pf,@dist)";
                c.cmd.Parameters.Clear();
                c.cmd.Parameters.Add("@hrid", SqlDbType.NVarChar).Value = lblhrid .Text ;
                c.cmd.Parameters.Add("@hrndrp", SqlDbType.NVarChar).Value = ddlname.SelectedItem.Text;
                c.cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
                c.cmd.Parameters.Add("@hrcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                c.cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdob.Text);
                c.cmd.Parameters.Add("@age", SqlDbType.SmallInt).Value = Convert.ToInt32(txtage.Text);
                c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                c.cmd.Parameters.Add("@country", SqlDbType.NVarChar).Value = txtcountry.Text;
                c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                c.cmd.Parameters.Add("@bloodgrp", SqlDbType.NVarChar).Value = ddlbg.SelectedItem.Text;
                c.cmd.Parameters.Add("@relig", SqlDbType.NVarChar).Value = txtreli.Text;

                if (Radiomale.Checked == true)
                    gen = Radiomale.Text;
                else
                    gen = radiofemale.Text;

                c.cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = gen;
                c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                c.cmd.Parameters.Add("@adhar", SqlDbType.Decimal).Value = Convert.ToDecimal(txtadhar.Text);
                c.cmd.Parameters.Add("@doj", SqlDbType.DateTime).Value = Convert.ToDateTime(txtdoj.Text);
                c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = "active";
                c.cmd.Parameters.Add("@da", SqlDbType.Decimal).Value = Convert.ToDecimal(txtda.Text);
                c.cmd.Parameters.Add("@hra", SqlDbType.Decimal).Value = Convert.ToDecimal(txthra.Text);
                c.cmd.Parameters.Add("@pf", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpf.Text);
                c.cmd.Parameters.Add("@dist", SqlDbType.NVarChar).Value = txtdist.Text;

                c.cmd.ExecuteNonQuery();
                Session["id"] = lblhrid.Text;
                //MessageBox.Show("Saved");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
               Response.Redirect("~/c_hrlog.aspx");

               txtaddress.Text = "";
               txtadhar.Text = "";
               txtage.Text = "";
               txtbasic.Text = "";
               txtcareof.Text = "";
               txtcity.Text = "";
               txtcountry.Text = "";
               txtda.Text = "";
               txtdist.Text = "";
               txtdob.Text = "";
               txtdoj.Text = "";
               txtemail.Text = "";
               lblhrid.Text = "-";
               txthra.Text = "";
               txtmob.Text = "";
               txtname.Text = "";
               txtpf.Text = "";
               txtpin.Text = "";
               txtquli.Text = "";
               txtreli.Text = "";
               txtstate.Text = "";
               ddlcare.ClearSelection();
               ddlcare.SelectedItem.Text = "select";
               ddlname.ClearSelection();
               ddlname.SelectedItem.Text = "select";
               ddlms.ClearSelection();
               ddlms.SelectedItem.Text = "select";
               ddlbg.ClearSelection();
               ddlbg.SelectedItem.Text = "select";
               ddlbg.ClearSelection();
               ddlbg.SelectedItem.Text = "select";
               radiofemale.Checked = false;
               Radiomale.Checked = false;
               altrnumber.Text = "";
               hrid1.Text = "";
               hrid2.Text = "";

               btnupdate.Visible = false;

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }

    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            Label1.Visible = false;
            Label2.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            Label1.Visible = true;
            Label2.Visible = true;

            DropDownList1.ClearSelection();
            DropDownList1.SelectedItem.Text = "1908";
            DropDownList2.ClearSelection();
            DropDownList2.SelectedItem.Text = "Janvary";

            Calendar1.VisibleDate = Convert.ToDateTime("January" + 1908);
        
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtdob.Text = Calendar1.SelectedDate.ToString("d");

        DateTime dob = new DateTime();
        dob = Convert.ToDateTime(txtdob.Text);
        DateTime age = DateTime.Now;
        TimeSpan tspan = age - dob;
        double dayss = tspan.TotalDays;

        double ag = dayss / 365;
        if (ag < 18 || ag >80)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Age Should Be Between 18 -80!!!')</script>");
            //MessageBox.Show(" age should be between 18 to 80");
            txtdob.Text = "";
            txtage.Text = "";
            txtdoj.Text = "";


        }

        TimeSpan tspan1 = age - dob;
        double days = tspan.TotalDays;
        double age1 = days / 365;

        txtage.Text = age1.ToString("0");
        txtdoj.Text = today.ToString("d");




        Calendar1.Visible = false;
        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        Label1.Visible = false;
        Label2.Visible = false;
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int year = Convert.ToInt16(DropDownList1.SelectedValue);
        int month = Convert.ToInt16(DropDownList2.SelectedValue);

        Calendar1.VisibleDate = new DateTime(year, month, 1);
        Calendar1.SelectedDate = new DateTime(year, month, 1);
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        int year = Convert.ToInt16(DropDownList1.SelectedValue);
        int month = Convert.ToInt16(DropDownList2.SelectedValue);

        Calendar1.VisibleDate = new DateTime(year, month, 1);
        Calendar1.SelectedDate = new DateTime(year, month, 1);
    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
    
        try
        {
            string gen;
            DateTime da, db;
            c = new connect();
            c.cmd.CommandText = "select * from hrreg where hrid='" + hrid1 .Text  + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "edit");
            if (ds.Tables["edit"].Rows.Count > 0)
            {
                for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                {
                    lblhrid .Text  = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);

                    ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[1]);
                    txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[2]);
                    ddlcare.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                    txtcareof.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                    txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);

                    da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[6]);
                    txtdob.Text = da.ToString("d");
                    txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);
                    txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                    txtcountry.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                    txtstate.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);
                    ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[11]);
                    txtreli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);

                    gen = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[13]);

                    if (gen == "male")
                    {
                        Radiomale.Checked = true;
                    }

                    else
                    {
                        radiofemale.Checked = true;
                    }

                    ddlms.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                    txtpin.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                    txtmob.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);
                    txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                    db = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[18]);
                    txtdoj.Text = db.ToString("d");
                    txtquli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[19]);
                    altrnumber.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                    txtemail.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                    txtbasic.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[22]);
                    txtda.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                    txthra.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]);
                    txtpf.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);
                    txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[27]);
                }
                txtname.Enabled = false;
                ddlname.Enabled = false;
                ImageButton2.Enabled = false;
                Panel3.Enabled = false;
                txtquli.Enabled = false;
                txtcountry.Enabled = false;
                txtadhar.Enabled = false;
                ddlbg.Enabled = false;
                txtreli.Enabled = false;


                btnupdate.Visible = true;
                btnedit.Visible = false;
                hrid1.Enabled = false;
                hrid2.Visible = false ;
                btnsearch.Visible = false;
                btnsave.Visible = false;
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                //MessageBox.Show("record not found");
                hrid1.Text = "";
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
    protected void btnupdate_Click1(object sender, EventArgs e)
    {
        if (ddlname.SelectedItem.Text == "select" || txtname.Text == "" || ddlcare.SelectedItem.Text == "select" || txtcareof.Text == "" || txtaddress.Text == "" || txtdob.Text == "" || txtcity.Text == "" || txtstate.Text == "" || ddlbg.SelectedItem.Text == "select" || txtreli.Text == "" || radiofemale.Checked == false && Radiomale.Checked == false  || ddlms.SelectedItem.Text == "select" || txtpin.Text == "" || txtmob.Text == "" || txtadhar.Text == "" || txtdoj.Text == "" || txtquli.Text == "" || txtcountry.Text == "" || txtbasic.Text == "" || txtdist.Text == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Enter The All The Fields!!!')</script>");
            //MessageBox.Show("enter all fields");
        }
        else
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "update hrreg set hrcdrp=@hrcdrp,care=@care,address=@address,city=@city,pin=@pin,state=@state,mob=@mob,ms=@ms,quali=@quali,altmob=@altmob,email=@email,basic=@basic where hrid='" + lblhrid .Text  + "'";
                c.cmd.Parameters.Clear();
                c.cmd.Parameters.Add("@hrcdrp", SqlDbType.NVarChar).Value = ddlcare.SelectedItem.Text;
                c.cmd.Parameters.Add("@care", SqlDbType.NVarChar).Value = txtcareof.Text;
                c.cmd.Parameters.Add("@address", SqlDbType.NVarChar).Value = txtaddress.Text;
                c.cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = txtcity.Text;
                c.cmd.Parameters.Add("@pin", SqlDbType.Decimal).Value = Convert.ToDecimal(txtpin.Text);
                c.cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = txtstate.Text;
                c.cmd.Parameters.Add("@mob", SqlDbType.Decimal).Value = Convert.ToDecimal(txtmob.Text);
                c.cmd.Parameters.Add("@ms", SqlDbType.NVarChar).Value = ddlms.SelectedItem.Text;
                c.cmd.Parameters.Add("@quali", SqlDbType.NVarChar).Value = txtquli.Text;
                c.cmd.Parameters.Add("@altmob", SqlDbType.Decimal).Value = Convert.ToDecimal(altrnumber.Text);
                c.cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
                c.cmd.Parameters.Add("@basic", SqlDbType.Decimal).Value = Convert.ToDecimal(txtbasic.Text);
                c.cmd.ExecuteNonQuery();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Updated!!!')</script>");
                //MessageBox.Show("record updated");
                txtaddress.Text = "";
                txtadhar.Text = "";
                txtage.Text = "";
                txtbasic.Text = "";
                txtcareof.Text = "";
                txtcity.Text = "";
                txtcountry.Text = "";
                txtda.Text = "";
                txtdist.Text = "";
                txtdob.Text = "";
                txtdoj.Text = "";
                txtemail.Text = "";
                lblhrid.Text = "-";
                txthra.Text = "";
                txtmob.Text = "";
                txtname.Text = "";
                txtpf.Text = "";
                txtpin.Text = "";
                txtquli.Text = "";
                txtreli.Text = "";
                txtstate.Text = "";
                ddlcare.ClearSelection();
                ddlcare.SelectedItem.Text = "select";
                ddlname.ClearSelection();
                ddlname.SelectedItem.Text = "select";
                ddlms.ClearSelection();
                ddlms.SelectedItem.Text = "select";
                ddlbg.ClearSelection();
                ddlbg.SelectedItem.Text = "select";
                ddlbg.ClearSelection();
                ddlbg.SelectedItem.Text = "select";
                radiofemale.Checked = false;
                Radiomale.Checked = false;
                altrnumber.Text = "";
                hrid2.Text = "";
                hrid1.Text = "";
                GenerateAutoID();
                txtname.Enabled = true ;
                ddlname.Enabled = true;
                ImageButton2.Enabled = true;
                Panel3.Enabled = true;
                txtquli.Enabled = true;
                txtcountry.Enabled = true;
                txtadhar.Enabled = true;
                ddlbg.Enabled = true;
                txtreli.Enabled = true;
                btnsave.Visible = true;
                btnupdate.Visible = false;
                btnedit.Visible = true;
                hrid1.Enabled = true;
                hrid2.Visible = true;
                btnsearch.Visible = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                c.cnn.Close();
            }
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            string gen;
            DateTime da, db;
            c = new connect();
            c.cmd.CommandText = "select * from hrreg where hrid='" + hrid2 .Text  + "'";

            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "edit");
            if (ds.Tables["edit"].Rows.Count > 0)
            {
                for (int i = 0; i <= ds.Tables["edit"].Rows.Count - 1; i++)
                {
                    lblhrid .Text  = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[0]);

                    ddlname.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[1]);
                    txtname.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[2]);
                    ddlcare.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[3]);
                    txtcareof.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[4]);
                    txtaddress.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[5]);

                    da = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[6]);
                    txtdob.Text = da.ToString("d");
                    txtage.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[7]);
                    txtcity.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[8]);
                    txtcountry.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[9]);
                    txtstate.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[10]);
                    ddlbg.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[11]);
                    txtreli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[12]);

                    gen = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[13]);

                    if (gen == "male")
                    {
                        Radiomale.Checked = true;
                    }

                    else
                    {
                        radiofemale.Checked = true;
                    }

                    ddlms.SelectedItem.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[14]);
                    txtpin.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[15]);
                    txtmob.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[16]);
                    txtadhar.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[17]);
                    db = Convert.ToDateTime(ds.Tables["edit"].Rows[i].ItemArray[18]);
                    txtdoj.Text = db.ToString("d");
                    txtquli.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[19]);
                    altrnumber.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[20]);
                    txtemail.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[21]);
                    txtbasic.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[22]);
                    txtda.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[24]);
                    txthra.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[25]);
                    txtpf.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[26]);
                    txtdist.Text = Convert.ToString(ds.Tables["edit"].Rows[i].ItemArray[27]);

                }
                Panel4.Visible = false;
               
                Panel1.Enabled = false;
                btnsave.Visible = false;
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Not Found!!!')</script>");
                //MessageBox.Show("record not found");
                hrid2.Text = "";
            }
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            c.cnn.Close();
        }
    }
    protected void btncal_Click(object sender, EventArgs e)
    {
        double da, hra, pf;
        da = Convert.ToDouble(txtbasic.Text) * (65.0 / 100);
        hra = Convert.ToDouble(txtbasic.Text) * (20.0 / 100);
        pf = Convert.ToDouble(txtbasic.Text) * (15.0 / 100);
        txtda.Text = Convert.ToString(da);
        txthra.Text = Convert.ToString(hra);
        txtpf.Text = Convert.ToString(pf);
    }



}
