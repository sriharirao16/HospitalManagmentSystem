using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class hrward : System.Web.UI.Page
{
    connect c;
    DataSet ds;
    SqlDataAdapter adp = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
                c = new connect();
                c.cmd.CommandText = "select * from ward where bedno='"+txtbedno .Text +"'";
                adp.SelectCommand = c.cmd;
                ds = new DataSet();
                adp.Fill(ds, "ward");

                if (ds.Tables["ward"].Rows.Count >= 0)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Already There!!!')</script>");
                    //MessageBox.Show("record already there");
                    txtbedcharges.Text = "";
                    txtbedno.Text = "";
                    txtwrdno.Text = "";
                    txtwrdtype.Text = "";
                    
                }
                else
                {

                    try
                    {
                        c = new connect();
                        c.cmd.CommandText = "insert into ward values(@wardtype,@wardno,@bedno,@bedcharges,@status)";
                        c.cmd.Parameters.Clear();
                        c.cmd.Parameters.Add("@wardtype", SqlDbType.NVarChar).Value = txtwrdtype.Text;
                        c.cmd.Parameters.Add("@wardno", SqlDbType.NVarChar).Value = txtwrdno.Text;
                        c.cmd.Parameters.Add("@bedno", SqlDbType.NVarChar).Value = txtbedno.Text;
                        c.cmd.Parameters.Add("@bedcharges", SqlDbType.NVarChar).Value = txtbedcharges.Text;
                        c.cmd.Parameters.Add("@status", SqlDbType.NVarChar).Value = Label1.Text;
                        c.cmd.ExecuteNonQuery();
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "msgbox", "<script>alert('Record Saved!!!')</script>");
                        //MessageBox.Show("Saved");
                        txtbedcharges.Text = "";
                        txtbedno.Text = "";
                        txtwrdno.Text = "";
                        txtwrdtype.Text = "";
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        c.cnn.Close();
                    }
                }

    }

}
